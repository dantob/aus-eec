//---------------------------------------------------------------------------
#ifndef DistestH
#define DistestH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Menus.hpp>
#include <Dialogs.hpp>
#include <Printers.hpp>
#include <Clipbrd.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------

class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TOpenDialog *FOpen1;
    TMainMenu *MainMenu1;
    TMenuItem *File1;
        TMenuItem *Disass1;
    TMenuItem *Open1;
    TMenuItem *Exit1;
    TMenuItem *About1;
    TMenuItem *ViewListfile1;
    TProgressBar *ProgressBar1;
    TMenuItem *ViewDirFile1;
    TMenuItem *ViewWarnfile1;
    TMenuItem *ViewCommentsFile1;
    TImage *Image1;
    TMenuItem *About2;
    TMenuItem *About3;
    TLabel *Label1;
    TLabel *Label2;
    TButton *Button1;
    TMenuItem *View1;

        TMenuItem *Tools1;
        TMenuItem *DD1;
        TMenuItem *Properties1;
        TMenuItem *Dblist1;
        TMenuItem *dbmsgs1;
    void __fastcall tttclick(TObject *Sender);
    void __fastcall OpenD(TObject *Sender);
    void __fastcall Exit1Click(TObject *Sender);
    void __fastcall VLclick(TObject *Sender);
    void __fastcall Button1Click(TObject *Sender);
    void __fastcall About1Click(TObject *Sender);
    void __fastcall ViewDirFile1Click(TObject *Sender);
    void __fastcall ViewCommentsFile1Click(TObject *Sender);
    void __fastcall ViewWarnfile1Click(TObject *Sender);

        
    void __fastcall keypr(TObject *Sender, char &Key);
        
        void __fastcall PropClick(TObject *Sender);
        void __fastcall Dblist1Click(TObject *Sender);
        void __fastcall dbmsgs1Click(TObject *Sender);
private:	// User declarations

public:		// User declarations
         __fastcall TForm1(TComponent* Owner);
    void __fastcall show_progb(long ofst, short p, long pcend);
    void __fastcall testexit(char * msg);
    void __fastcall ErrorWin(char *s, char *t);
    void __fastcall Testfiles(void); 
   };
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;


#endif

  