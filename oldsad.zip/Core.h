
/*******************************************************************
common declarations for 'core' code modules (disassemble and signature)
change all to offset as an experiment ?
**********************************************************************/

#include  <stdio.h>
#include  <stdlib.h>
#include  <ctype.h>

#include <fcntl.h>
#include <io.h>
#include <dir.h>
#include <sys/stat.h>

#include  <stdarg.h>
#include  <string.h>
#include  <math.h>
#include <dos.h>              // time testing


#ifdef __unix__
#define strncmpi strncasecmp
#endif


typedef unsigned char  uchar;
typedef unsigned short ushort;
typedef unsigned long  ulong;

#define NC(x)  sizeof(x)/sizeof(x[0])

#define PCORG  0x2000     // standard offset for EEC bins

// define letters as bitmask of a 'long'

#define A  0x1
#define B  0x2
#define C  0x4
#define D  0x8
#define E  0x10
#define F  0x20
#define G  0x40
#define H  0x80
#define I  0x100
#define J  0x200
#define K  0x400
#define L  0x800
#define M  0x1000
#define N  0x2000
#define O  0x4000
#define P  0x8000
#define Q  0x10000
#define R  0x20000
#define S  0x40000
#define T  0x80000
#define U  0x100000
#define V  0x200000
#define W  0x400000
#define X  0x800000
#define Y  0x1000000
#define Z  0x2000000

#define PSSRC     (cmdopts & C)      // source code
#define P8065     (cmdopts & H)      // 8065 codeset
#define PLABEL    (cmdopts & L)      // auto label names (lab)
#define PMANL     (cmdopts & M)      // full manual mode
#define PINTF     (cmdopts & N)      // auto int func naming
#define PPROC     (cmdopts & P)      // auto proc names (xfunc, vfunc, intfunc)
#define PSIG      (cmdopts & S)      // auto Lookup Signature subroutine detect
#define PHEX      (cmdopts & X)      // print variables in hex (decimal otherwise)
#define PLCOD     (cmdopts & Y)      // list code during early passes
#define PDBGM     (cmdopts & Z)      // debug messages

#define PDEFLT      (P|N|X|S|C)      // default setup , procnames,intnames,hex,sigs, src
#define PDBG         (Y|Z)           // debug options

#define MAXLEVS   16                 // max command (CADT) levels
#define ANLPRT     3                 // define the print phase of anlpass


typedef struct    // malloced block tracker
{
void *blk;
size_t size;
} BL;

/*
typedef struct    // malloced block tracker with type  (debug)
{
void *blk;
size_t size;
short type;
} BT;
*/

/******************************************
* Additional command structs - chained
**********************************************/

typedef struct cadt {   // size = 12  this for cmnd chain
struct cadt *next;
long  divisor;         // store as 100 or 1000 times for poor man's float ? (this is also bitno)
union
{
long flags;
struct {
ushort sign   : 1 ;    // signed if set
ushort esize  : 2 ;    // 1, 2 or 4 bytes (1,2,3)
ushort pfw    : 3 ;    // print min fieldwidth 1-8 (0-7)
ushort hex    : 1 ;    // print format - hex or dec
ushort vect   : 1 ;    // value is a vect to a subr
ushort name   : 1 ;    // ptr can be checked for symbol name
ushort dp     : 1 ;    // divisor is set (100 times true value)
ushort cnt    : 5 ;    // repeat count 32 max
ushort enc    : 3 ;    // encoded data type  1-7
ushort foff   : 1 ;    // fixed offset (using divisor)
ushort nods   : 1 ;    // no display and no level in commands
// dflt    for defaulted table/funcs ??
//ushort volt   : 1 ;  // value is A to D voltage (effectively x/128000)
//ushort mask   : 1 ;  // this is a mask pair (like timerlist)

} f;
};
} CADT;

typedef struct {          // size 16 - this for scans ONLY
struct lbk *tnext;        // temp chain for subroutine etc scans
struct lbk *tprev;        // added direct to end of lbk block
ushort from;              // from and bank (for subroutine tracking)
ushort fbank;
short tabaddr;
short funcaddr;
short fsize;
} LSCN ;

#define ADSZ  20       // bigger of LSCN or CADT *


typedef struct
{     // like a class with subrs
short type;        // process type
short num;         // no of (used) elements;
short pnum;        // no of pointers in array.
short asize;       // allocation size for pointer blocks (50 default)
uchar size;        // entry size

uchar rem  : 1;    // remote  pointers, no data at ALL (e.g. 2nd jump tab)
uchar pre  : 1;    // prealloced pointers...don't free entries
short last;        // last accessed
void **ptrs;       // ptr to array of pointers
}  CHAIN;

// for scans, addnl points to a different scan structure....

/*
typedef union
{
struct
{
 ushort bank;              // which bank
 ushort pc;
}s;
ulong ofst;
} ADDR;
  */


// to do true offsets, need a 0x2000 buffer for RAM symbols etc.....

typedef struct bks
 {
 long start;        // file offsets, start fixed at 0x2000
 long end;          // end bank offset (PC = 0xffff)
 long tend;         // where fill block starts (true end of bank)
 char bank;         // bank id
 uchar cmd : 1;     // set by cmd
 uchar used : 2;    // mrk if used, temp hold for answer of jump search
 } BKS;

#define C_DFLT   0     // command offsets
#define C_BYTE   1
#define C_WORD   2
#define C_TXT    3     // MUST MATCH declaration in core.cpp
#define C_XCODE  4
#define C_CODE   5     // mergeable to here (0-5)

#define C_VECT   6     // non merge but override (6-8)
#define C_TABLE  7     // 6-8 can override 1-2
#define C_FUNC   8
#define C_SCAN   9
// #define C_OPTS   10
// #define C_RBASE  11
#define C_STCT   12
// #define C_SYM    13
#define C_SUBR   14
#define C_ARGS   15
// #define C_TIMR   16
// #define C_bank   17

/************************
operand tracking for printouts and anlysis
OPS has 2 sets of 4 entries (up to 3 op with indexed)
***************************/

typedef struct        // operand storage, each instruction
{
 ushort xpc;          // address
 ushort bank;         // bank
 char *name;          // symbol name if exists
 union {
 struct {
 ushort indx    : 1;  // indexed
 ushort autoinc : 1;  // autoinc
 ushort imd     : 1;  // immediate
 ushort indr    : 1;  // indirect
 ushort reg     : 1;  // register
 ushort bit     : 1;  // bit
 ushort ign     : 1;  // ignore for source
// ushort and     : 1;  // AND bitwise operator
// ushort or      : 1;  // OR  bitwise operator
// ushort flg     : 1;  // flags word (all bits)
 ushort byte    : 1;  // byte offset if set, otherwise word
 ushort hex     : 1;  // hex print in source if set, otherwise decimal
 ushort uns     : 1;  // unsigned print in source if set
 ushort bnk     : 1;   // this is a BANK change instruction
 ushort wrt     : 1;   // this is written to (for sym name)
 } f;
 ushort flags;
 };
} OPS;


typedef struct lbk {      // command header structure     size = 28
ushort start;             // start pc
ushort bank;              // which bank
void *addnl;              // additional structs (chained)  cast to CADT
ushort end;               // end pc
uchar size1 ;             // CPARS and struct (subr or data) sizes
uchar size2 ;              // set if split printout

uchar  fcom  : 5 ;        // command index  - only 13 commands so far...
uchar  scanned  ; // : 1;      // scan complete temp make char for no of scans
uchar  term  : 2;         // data command has single terminating byte(s)
uchar  cmd   : 1;         // added by user command, guess otherwise
//uchar  err   : 1;         // error in this block, rescan...
 } LBK ;


// subroutine structure
// see sign for ptypes

// FIRST 3 PARAMS MUST MATCH LBK STRUCTURE

typedef struct sxt
{
 ushort pc;               // pc and bank
 ushort bank;
 CADT   *addnl;

 short  size;         // total size (bytes) of params (= addnl )
 uchar ptype ;         // subr type
 uchar cmd   : 1;      // set by command, no mods allowed  - guess otherwise
 uchar scanned : 1;    // if subr code scanned
 uchar levels : 3;       // up to 7 levels backwards (grandcaller stack tricks)
 short szreg;          // size of table (cols) index   -ve allowed for fixed size
 short adreg;          // address of structure index
} SXT;


/********************************
 * RBASE list structure
 * map register to fixed address
 ********************************/

typedef struct rbt
{
  ushort   reg;         // register (= address)
  ushort   bank;        // dummy at present (=8)
  ushort   addr;        // value
} RBT;


 /********************************
 *   symbol table structure
 * -1 for whole word or byte   size 16
 ********************************/

typedef struct syt
{
 ushort  pc;
 ushort  bank;
 char   *symnam;
 union
  {
   struct {
    short   bitno : 6 ;    // -1 to 31 , signed
    ushort  used  : 1 ;    // add a 'used' marker here for better control of names ?
    ushort  prtd  : 1 ;    // printed by subr command
    ushort  flags : 1 ;    // this is a byte (word) of bits
    ushort  size  : 5 ;    // char size 31 max
    } f;
   short flgs;
  };
} SYT;

/********************************
 *   Jump list structure
 ********************************/

typedef struct jlt
{
  ushort  from;
  ushort  fbank;
  ushort  to;
  ushort  tbank;

  union
  {
  struct {
  ushort  cnt  : 2;   // jump size (bytes)
  ushort  uncl : 1;   // not clean (has jumps inside)
  ushort  cond : 1;   // conditional, otherwise static
  ushort  subr : 1;   // subroutine call (for param tracing)
  ushort  mult : 1;   // Multiple end points
  ushort  back : 1;   // Backwards jump
  ushort  used : 1;   // used - for brackets
  ushort  reti : 1;   // 'ret' jump
  ushort  retn : 1;   // jump to true ret
  ushort  adj  : 1;   // adjacent, for 'ELSE'
  } f;
  short flags;
  };

 } JLT;

// signature defs

typedef struct // sign
{
 uchar  val;			// actual value
 uchar  indx;			// index or zero if not variable - or bit mask, 0-16 index (4), type (4)
} SIGN ;

typedef struct
 {
 uchar mtype  : 1 ;     // 0 = sub  1 = master
 uchar smatch : 1 ;     // subroutine link
 uchar jmatch : 1 ;     // jump link
 uchar ematch : 1 ;     // end link
 uchar dat    : 1 ;     // data sig only
 uchar subr   : 1 ;     // sub required
 uchar O61P   : 1 ;     // 1 = 8061 pattern, and processed marker
 uchar O65    : 1 ;     // 1 = 8065 pattern
 uchar ptype ;           // pattern type [NO - bottom 6 bits (63 max)]
 } SFLG;

typedef struct xsig
{

 ulong ofst;            // ABSOLUTE start address
 ulong end;             // end address
 ulong jump;            // jump dest
 ulong subr;            // subr call
 struct xsig *master;   // master sig for this sig
 SFLG f;
 char  name[16];        // use actual string as it's easier to release
 uchar v[16];           // register values
} SIG;

// top 2 bits of type in funcs is signed in, signed out

typedef struct pat
{
 SIGN *sig;             // actual sig
 char *name;            // name (can be null)
 ushort size;            // no of instructions in sign
 SFLG f;
} PAT;


// end of header
