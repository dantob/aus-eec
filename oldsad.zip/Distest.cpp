//---------------------------------------------------------------------------
#include <vcl.h>
#include <vcl/dstring.h>;
#pragma hdrstop

#include "Distest.h"
#include <stdio.h>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

#include <dir.h>
#include <shellapi.h>
#include "core.h";                 // mainly for extra debug opts....

extern char* filedets(void);
extern short openfiles(void);
extern short dissas (void);
extern void  tidy_exit (void);
extern short init_structs(void);
extern short readbin(void);
extern long xcn;
extern long progmkr;
extern short phmarker;
extern long screenopts;

char FNin[64],FNout[64],FNwrn[64],FNdir[64], FNcmt[64];
TForm1 *Form1;

char fstr[128];
char *t;
short fiddlecount = 0;

//-----------------------------------------------------------






//------ START OF CBUILD SPECIFIC STUFF --------------------------------


void show_prog(long pc, short phase, long pcend)
{
 Form1->show_progb (pc, phase, pcend) ;
}


void calcfiles (AnsiString fname)
{
  char *str;

  str = fname.c_str();
  strncpy(fstr, str, 32);
  t = strrchr(fstr, '.');

  strcpy (FNin,fstr);
  *t = '\0';    /* ditch extension */
  strcpy(t,"_lst.txt");
  strcpy(FNout,fstr);

  strcpy(t,"_msg.txt");
  strcpy(FNwrn,fstr);

  strcpy(t,"_dir.txt");
  strcpy(FNdir,fstr);

  strcpy(t,"_cmt.txt");
  strcpy(FNcmt,fstr);

}


void __fastcall TForm1::Testfiles(void)
{
  ViewListfile1->Enabled     = FileExists(FNout);
  ViewDirFile1->Enabled      = FileExists(FNdir);
  ViewCommentsFile1->Enabled = FileExists(FNcmt);
  ViewWarnfile1->Enabled     = FileExists(FNwrn);
}

void __fastcall TForm1::tttclick(TObject *Sender)
{
// This is dissassemble menu choice
  short ans;

  Panel1->Visible = true;
  ProgressBar1->Position = 0;
  Panel1->Update();
  Label1->Caption = "Opening Files" ;
  if (openfiles()) return;

  ans = dissas();
  if (ans)
    {
     ProgressBar1->Position = 100;
     Label1->Caption = "Disassembly Complete";
    }
  else
     Label1->Caption = "Disassembly Failed";
  Label1->Visible = true;
  Label2->Layout = tlBottom;
  Label2->Caption = "View Warnings file for problems and issues";
  Label2->Visible = true;
  Button1->Visible = true;
  Testfiles();
  }
//---------------------------------------------------------------------------


void __fastcall TForm1::OpenD(TObject *Sender)
{
 // t = GetCommandLine();   for argc argv type stuff

 if (FOpen1->Execute())
  {
   calcfiles(ExtractFileName(FOpen1->FileName));
   Form1->Caption = "Ford EEC Disassembler              " + (AnsiString) FNin;
   Disass1->Enabled = true;
   Properties1->Enabled = true;
   Testfiles();
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Exit1Click(TObject *Sender)
{
  Close();    // this closes main form and whole application
}

//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
 Image1->BringToFront();
 Label1->Font->Name = "MS Sans Serif";
 Panel1->Visible = false;
 Label1->Visible = false;
 Label1->Height = 65;       // default size
 Label2->Visible = false;
 Button1->Visible = false;
 ProgressBar1->Visible = false;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::About1Click(TObject *Sender)
{
 Panel1->Visible = true;
 Label1->Caption = "Ford EEC Disassembler\nFor single or multibank 8061/8065 binaries\nVersion 0.2";
 Label1->Visible = true;

 Label2->Layout = tlBottom;
 Label2->Caption = "Absolutely no warranty or liability\nFor educational purposes only";
 Label2->Visible = true;
 Button1->Visible = true;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::ViewDirFile1Click(TObject *Sender)
{
  ShellExecute(NULL, 0, "wordpad.exe", FNdir, 0, SW_NORMAL);
}

void __fastcall TForm1::VLclick(TObject *Sender)
{
  ShellExecute(NULL, "open", FNout, 0, 0, SW_NORMAL);
}

void __fastcall TForm1::ViewCommentsFile1Click(TObject *Sender)
{
  ShellExecute(NULL, 0, "wordpad.exe", FNcmt, 0, SW_NORMAL);
}

void __fastcall TForm1::ViewWarnfile1Click(TObject *Sender)
{
  ShellExecute(NULL, "open", FNwrn, 0, 0, SW_NORMAL);
}

//---------------------------------------------------------------------------

 void __fastcall TForm1::show_progb (long ofst, short p, long fillen)
{
   long where;
    where =  (ofst*100)/fillen;

    if (p != phmarker)
     {
      phmarker = p;
       if (p == 1 ) Label1->Caption = "1 Processing Commands" ;
       if (p == 2 ) Label1->Caption = "2 Analysing Binary" ;
       if (p == 3 ) Label1->Caption = "3 Producing Listing" ;
       if (p == 4 ) Label1->Caption = "4 Checking Binary" ;
      }


    if (where != progmkr)
    {
     xcn++;
     progmkr = where;
     ProgressBar1->Visible = true;
     ProgressBar1->Position = progmkr;
     Label1->Visible = 1;
     Label1->Update();
     Panel1->Update();
    }
}



void __fastcall TForm1::ErrorWin(char *s, char *x)
{
 //Panel1->Height = 50;

 ProgressBar1->Visible = false;
 Panel1->Visible = true;
 Label1->Caption = s;

 Label1->Visible = true;

 t = fstr;   /* whereever string is... */
 if (x)
  {
   strcpy(fstr,"Check that file '");
   t = fstr+strlen(fstr);
   strcpy(t,x);
   t = fstr+strlen(fstr);
   strcpy(t," ' is not locked\nand has correct permissions");
   Label2->Layout = tlBottom;
   Label2->Caption = fstr;
   Label2->Visible = true;
   Button1->Visible = true;
  }
}


//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
 getcwd(fstr,128);             // winXP sets "my docs" by default...
 FOpen1->InitialDir = fstr;

}


//---------------------------------------------------------------------------


void __fastcall TForm1::keypr(TObject *Sender, char &Key)
{
 if (Key == 'x' && !(fiddlecount&1)) fiddlecount++;
 if (Key == 'y' && (fiddlecount&1)) fiddlecount++;    // 'xyxy' as a test
 if (fiddlecount > 3)
  {
   DD1->Visible = true;
   DD1->Enabled = true;
   //fiddlecount = 0;
  }


}
//---------------------------------------------------------------------------


void __fastcall TForm1::PropClick(TObject *Sender)
{

 Label1->Height = 137;
 Label1->Font->Name = "Courier New";
 Label1->Caption = filedets();
 Panel1->Visible = true;
 Label1->Visible = true;
 Button1->Visible = true;
}

//---------------------------------------------------------------------------

void __fastcall TForm1::Dblist1Click(TObject *Sender)
{
if (Dblist1->Checked)
  {
   screenopts &= (~Y);          //(~PPDBG);
   Dblist1->Checked = false;
  }
  else
  {
   screenopts |= Y;           //PPDBG;
   Dblist1->Checked = true;
  }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::dbmsgs1Click(TObject *Sender)
{
 if (dbmsgs1->Checked)
  {
   screenopts &= (~Z);          //FFDBG);
   dbmsgs1->Checked = false;
  }
  else
  {
   screenopts |= Z;              //FFDBG;
   dbmsgs1->Checked = true;
  }

}
//---------------------------------------------------------------------------

