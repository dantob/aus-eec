
/******************************************************
 *  8065 advanced disassembler for EEC-IV
 *
 * This program is for private use only.
 * No liability of any kind accepted or offered.
 *
 * with code analysis
 *
 * AJP    07/10/2012
 *******************************************************
 * organisation - bit 7 MS bit 0 LS
 *******************************************************


 ******************************************************
 *  Declarations and includes
 *******************************************************/

#include  "core.h"

extern char FNin[64];
extern char FNout[64];
extern char FNwrn[64];
extern char FNdir[64];
extern char FNcmt[64];

extern void  scan_init (void);
extern void  process_sigs(LBK*, long);
extern void  do_subr(LBK *, ushort, ushort, ushort, short *);
extern void  prt_sigs(CHAIN *, short);
extern short scan_start (long*);
extern SIG*  do_sig (PAT *, long);
extern PAT   ign;  

extern void show_prog(long, short,long );         /* links out to graphic modules */

#define TXTSZE    256            // text array sizes
#define INSTART   incols[0]	   // col where mnemonic/command starts
#define MNSTART   incols[1]	   // col where code or data starts
#define OPSSTART  incols[2]        // col where pseudo code starts
#define CDOSTART  incols[3]	   // col where comment starts
// CDDSTART  for data items ?
// maxwidth as well ?
/**********************
 * command definitions
 **********************/

/****************
 types for commands and comments
1 - delimiter
2 - option level
3 - name delim - ignore if trailing
4 - comment
5 - newline (cmnt)
6 - symbol  with pad (cmnt)
7 - symbol  (cmnt)
8 - end of string (newline)
9 - newline with pad for comments
*******************/


struct
  {
  char value;		/* char to check */
  char action;		/* action index */
  } chkch[] =
   {
     {'\n', 8}, {' ', 1}, {',', 1}, {':', 2}, {'"', 3}, {'\'', 3},
     {'#', 4},  {'|', 5}, {'@', 6}, {'$', 7}, {'^', 9}
   };


typedef struct    // word split holder
  {
   char *st;     // string
   uchar lv;     // cmd level
   uchar no;     // word index within level
  } WDS;


typedef struct     //master command split structure size
  {
  uchar clv;       // current lev
  uchar cwd;       // current wd
  uchar slv;       // split level
  uchar twds;      // total wds
  uchar nptrs;     // no of alloced pointers
  WDS   *wds;      // wds structs
  } SPW;


typedef struct         // command holder
{ long  start;
  long  end;
  long  cmdflgs;
  short bank;
  uchar fcom;
  uchar levels;
  char  *symname;
  short csize;
  short type ;
  short slev;
  short colreg;
  short addreg;
  CADT  cmad[MAXLEVS];
  } CPS;







ushort pp_dft   (long *, LBK *);
ushort pp_data  (long *, LBK *);
ushort pp_text  (long *, LBK *);
ushort pp_vect  (long *, LBK *);
ushort pp_code  (long *, LBK *);
ushort pp_stct  (long *, LBK *);
ushort pp_timer (long *, LBK *);

void set_vect (CPS*);
void set_code (CPS*);
void set_scan (CPS*);
void set_cdih (CPS*);
void set_prm  (CPS*);
void set_opts (CPS*);
void set_rbas (CPS*);
void set_sym  (CPS*);
void set_subr (CPS*);
void set_bnk  (CPS*);
void set_time (CPS*);

typedef struct drs                    // command definition
{ char   *com;
  void   (*setz) (CPS*);
  ushort (*prtz) (long *, LBK*);
  uchar  minc   : 3 ;         // min chars for match

  uchar  maxlv  : 5 ;         // max CADT levels
  uchar  namee  : 1 ;         // name expected
  uchar  flgs   : 1 ;         // uses flag chars (opts)
  uchar  word   : 1 ;         // word sized
 // uchar  ovrt   : 1 ;         // can be overridden for tabs etc
//  uchar  ovrs   : 1 ;         // can override ovrt commands
//  uchar  mrge   : 1 ;         // can be merged
  char*  opts;
} DIRS;


/* Command Option letters are -

      as opts           in cmd
 A
 B
 C
 D                      Fixed offset for param (like rbase) (word or byte) 2nd BANK   (vect)
 E                      ENCODED  type, rbase
 F                      special func type  - type, addr, cols
 G
 H    8065
 I
 J
 K
 L    label names       Long
 M    Manual only       mask ?(byte or word pair) and flags for syms ?
 N    Int proc names    Name lookup
 O                      Count (cols etc)
 P    proc names        Print fieldwidth
 Q                      Quit Byte (or Word)
 R                      Indirect (vect)
 S    sig detect        Signed    (unsigned otherwise)
 T                      Bit (with symbol)
 U
 V                      Divisor (Scaler) - 2 pt Float (stored as *100)
 W                      Word
 X    Hex print         Hex print
 Y    dbg print         Byte
 Z    Listing dbg prt


 Possible new options/comands -

 1. allow for +/- signed decimal,   @ = register (hex)  $ = abs value  & = param value
 2. FLAGS (byte) to mark for always bits
 3. DONE -  need a read / write option for naming (Watchdog etc) ... need to add to sym command ?
 4. DONE - line feed in middle of structure def ?   - split count for this  DONE, works
 5. Timerlist structures - part done
 6. DONE - Bank visible
 7. Long Numbers like 25,000,000, 16666666  s are significant !!
 8. Key IO multipliers (i.e. X * 2.4 for times) and no of cyls etc...
 9. options for C source code (C), display of indirects [x+y] or x[y] (I), columns (O)
 9. show only named bits/all bits (B)

 program stuff
 1. STRUCT for bank+PC (union long ?) used in binary chops

-----------------------------------------------------------------------------------*/


// lower case option indicates following number(s) expected 1 if no digit, 2 or 3
// byte and word guesses can be overriden by code,structs and vects.

//     minc, maxlev, namex, flags, word, optchars
// fill, byte, text, word, code, xcode can be merged, so are lowest in list
//add layout commands ? more options ?


DIRS dirs[] = {
"fill"   , set_prm,  pp_dft,   2, 0,  0, 0, 0, ""   ,        // fill - default -> MUST be zero element
"byte"   , set_prm,  pp_data,  2, 2,  1, 0, 0, "pSXv" ,      // pfw, signed, hex, divisor
"word"   , set_prm,  pp_data,  2, 2,  1, 0, 1, "LpSXv" ,     // + Long
"text"   , set_prm,  pp_text,  2, 0,  0, 0, 0, ""   ,
"xcode"  , set_cdih, pp_dft,   2, 0,  0, 0, 0, ""   ,
"code"   , set_code, pp_code,  2, 0,  0, 0, 0, ""   ,
"vect"   , set_vect, pp_vect,  2, 2,  1, 0, 1, "dQ"   ,       // bank, quit byte (always hex)
"table"  , set_prm,  pp_stct,  2, 2,  1, 0, 0, "opSvWXY"  ,
"func"   , set_prm,  pp_stct,  2, 3,  1, 0, 1, "LpSvWXY"  ,
"cscan"  , set_scan, pp_dft ,  2, 0,  0, 0, 0, ""   ,
"opts"   , set_opts, pp_dft,   2, 2,  0, 1, 0, "HLMNPSXYZ" ,
"rbase"  , set_rbas, pp_dft,   2, 0,  0, 0, 0, ""   ,
"struct" , set_prm,  pp_stct,  2, 16, 1, 0, 0, "dLMNopRSvWXYQ" ,
"symbol" , set_sym,  pp_dft,   2, 2,  1, 0, 0, "FtW"        ,   // flags,bit,write
"subr"   , set_subr, pp_dft,   2, 16, 1, 0, 0, "de2f3LNopSWXY" ,
"args"   , set_prm,  pp_dft,   2, 16, 0, 0, 0, "de2LNopSWXY" ,    // call address, not subr
"timel"  , set_time, pp_timer, 2, 2,  1, 0, 0, "YWNT",            // timer list
"bank"   , set_bnk  ,pp_dft,   2, 0,  0, 0, 0, ""                //  file map/offsets
};



/**********************
 *  opcode definition table
 **********************/

/*********************************************
jump swopovers......
'9'   => 'goto 1'   normally,
'9'   => '{' when swopped sense with jump
'8'   => 'if' normally
95 items with invalid for 8061, 99 for 8065

could consider offset for strings as 4 byte pointers are big....
also can crunch source code for all the spaces ?

**********************************************/

/* index for opcodes points into main opcode table - 0 is invalid */

uchar opcind[256] =
{
/* 0   1   2   3   4   5   6   7   8   9    a    b    c    d    e    f */
   1,  2,  3,  4,  0,  5,  6,  7,  8,  9,  10,   0,  11,  12,  13,  14,    /* 00 - 0f  */
  99, 15, 16, 17,  0, 18, 19, 20, 21, 22,  23,   0,   0,   0,   0,   0,    /* 10 - 1f  */
  24, 24, 24, 24, 24, 24, 24, 24, 25, 25,  25,  25,  25,  25,  25,  25,    /* 20 - 2f  */
  26, 26, 26, 26, 26, 26, 26, 26, 27, 27,  27,  27,  27,  27,  27,  27,    /* 30 - 3f  */
  28, 28, 28, 28, 29, 29, 29, 29, 30, 30,  30,  30,  31,  31,  31,  31,    /* 40 - 4f  */
  32, 32, 32, 32, 33, 33, 33, 33, 34, 34,  34,  34,  35,  35,  35,  35,    /* 50 - 5f */
  36, 36, 36, 36, 37, 37, 37, 37, 38, 38,  38,  38,  39,  39,  39,  39,    /* 60 - 6f */
  40, 40, 40, 40, 41, 41, 41, 41, 42, 42,  42,  42,  43,  43,  43,  43,    /* 70 - 7f */
  44, 44, 44, 44, 45, 45, 45, 45, 46, 46,  46,  46,  47,  47,  47,  47,    /* 80 - 8f */
  48, 48, 48, 48, 49, 49, 49, 49, 50, 50,  50,  50,  51,  51,  51,  51,    /* 90 - 9f */
  52, 52, 52, 52, 53, 53, 53, 53, 54, 54,  54,  54,  55,  55,  55,  55,    /* a0 - af */
  56, 56, 56, 56, 57, 57, 57, 57, 58, 58,  58,  58,  59,  59,  59,  59,    /* b0 - bf */
  60,  0, 60, 60, 61,  0, 61, 61, 62, 62,  62,  62,  63,   0,  63,  63,    /* c0 - cf */
  64, 65, 66, 67, 68, 69, 70, 71, 72, 73,  74,  75,  76,  77,  78,  79,    /* d0 - df */
  80,  0,  0,  0,  0,  0,  0, 81,  0,  0,   0,   0,   0,   0,   0,  82,    /* e0 - ef */
  83, 84, 85, 86, 95, 96, 97, 87, 88, 89,  90,  91,  92,  98,  93,  94     /* f0 - ff */

};
 

typedef struct
{
  uchar ppx;      // prefix opcode - signed etc
  uchar rpx;      // reverse opcode - for jumps, bit sets, etc
  uchar numops;   // bottom nibble numops, top nibble is write op for sym names
  ulong opt ;     // types first two bits are numops
  char  *name;    // opcode name
  char  *sce;     // high level code

} OPC;

/* instruction types - letters DEFINEd in core.h

A     bitwise AND
B     byte aligned,  short jump with J
C     conditional jump (with J)
D     DJNZ instruction (with J)
E     end code block/scan at this opcode
H     8065 opcode only
J     jumps & subr calls, long by default short with B
K     SKIP instruction (with J)
L     don't save last op's operands
M     multimode opcode, word or byte
N     don't replace params in sce code
O     bitwise OR   XOR with X
P     pushw
R     bank swop
S     shift
T     bit jump, djnz (with J)
X     Subroutine call with J   XOR with O  long shift with S
Z     don't print [read] operand if zero

*/


OPC opctbl[] = {
  0 , 0x0,     0, N|E       ,"!INV!"  , "" ,              // zero entry is for invalid opcode

  0 , 0x0,     0, N|J|K     ,"skip"  ,  "\x9" ,           // skip = sjmp [pc+2]
  0 , 0x0,  0x11, 0         ,"clrw"  ,  "\x1 \xa\x30;"  ,
  0 , 0x0,  0x11, 0         ,"cplw"  ,  "\x1 \xa~\x1;"  ,
  0 , 0x0,  0x11, 0         ,"negw"  ,  "\x1 \xa-\x1;" ,
  0 , 0x0,  0x11, 0         ,"decw"  ,  "\x1--;"  ,
  0 , 0x0,  0x11, 0         ,"sexw"  ,  "\x1L \xa(long)\x1;" ,
  0 , 0x0,  0x11, 0         ,"incw"  ,  "\x1++;"  ,
  0 , 0x9c, 0x22, S         ,"shrw"  ,  "\x2 \xa\x2 >> \x1;" ,
  0 , 0x7c, 0x22, S         ,"shlw"  ,  "\x2 \xa\x2 << \x1;" ,
  0 , 0x9c, 0x22, S         ,"asrw"  ,  "\x2 \xa\x2 >> \x1; (arith)" ,

  0 , 0x8c, 0x22, S|X       ,"shrdw" ,  "\x2L \xa\x2L >> \x1;" ,            // 11
  0 , 0x6c, 0x22, S|X       ,"shldw" ,  "\x2L \xa\x2L << \x1;" ,
  0 , 0x8c, 0x22, S|X       ,"asrdw" ,  "\x2L \xa\x2L >> \x1; (arith)" ,
  0 , 0x0,  0x12, B         ,"norm"  ,  "\x1 \xanrml(\x2L);",
  0 , 0x0,  0x11, B         ,"clrb"  ,  "\x1 \xa\x30;" ,
  0 , 0x0,  0x11, B         ,"cplb"  ,  "\x1 \xa~\x1;" ,
  0 , 0x0,  0x11, B         ,"negb"  ,  "\x1 \xa-\x1;" ,
  0 , 0x0,  0x11, B         ,"decb"  ,  "\x1--;" ,
  0 , 0x0,  0x11, 0         ,"sexb"  ,  "\x1W \xa(int)\x1\B;" ,
  0 , 0x0,  0x11, B         ,"incb"  ,  "\x1++;"  ,

  0 , 0x9c, 0x22, S|B       ,"shrb"  ,  "\x2 \xa\x2 >> \x1;" ,       // 21
  0 , 0x7c, 0x22, S|B       ,"shlb"  ,  "\x2 \xa\x2 << \x1;" ,
  0 , 0x9c, 0x22, S|B       ,"asrb"  ,  "\x2 \xa\x2 >> \x1 (arith)" ,
  0 , 0x0,     1, J|B|E|N   ,"sjmp"  ,  "\x9",
 108, 0x0,     1, J|B|X     ,"scall" ,  "\x1\xc",
  0 , 0x38,    2, J|T|N     ,"jnb"   ,  "\x8!\x3\x2) \x9",
  0 , 0x30,    2, J|T|N     ,"jb"    ,  "\x8\x3\x2) \x9",
  0 , 0xa0, 0x33, M|A       ,"an3w"  ,  "\x3 \xa\x2 & \x1;" ,
  0 , 0xa0, 0x33, M|Z       ,"ad3w"  ,  "\x3 \xa\x2 + \x1;" ,
  0 , 0x0,  0x33, M         ,"sb3w"  ,  "\x3 \xa\x2 - \x1;" ,

 100, 0x0,  0x33, M         ,"ml3w"  ,  "\x3L \xa\x2 * \x1;",      // 31
  0 , 0x0,  0x33, M|B|A     ,"an3b"  ,  "\x3 \xa\x2 & \x1;" ,
  0 , 0x0,  0x33, M|B|Z     ,"ad3b"  ,  "\x3 \xa\x2 + \x1;" ,
  0 , 0x0,  0x33, M|B       ,"sb3b"  ,  "\x3 \xa\x2 - \x1;",
 101, 0x0,  0x33, M|B       ,"ml3b"  ,  "\x3W \xa\x2\B * \x1\B;" ,
  0 , 0x0,  0x22, M|A       ,"an2w"  ,  "\x2 &\xa\x1;" ,
  0 , 0x0,  0x22, M         ,"ad2w"  ,  "\x2 +\xa\x1;" ,
  0 , 0x0,  0x22, M         ,"sb2w"  ,  "\x2 -\xa\x1;" ,
 102, 0x0,  0x22, M         ,"ml2w"  ,  "\x2L *\xa\x1;",
  0 , 0x0,  0x22, M|B|A     ,"an2b"  ,  "\x2 &\xa\x1;" ,

  0 , 0x0,  0x22, M|B       ,"ad2b"  ,  "\x2 +\xa\x1;" ,      //41
  0 , 0x0,  0x22, M|B       ,"sb2b"  ,  "\x2 -\xa\x1;" ,
 103, 0x0,  0x22, M|B       ,"ml2b"  ,  "\x2 *\xa\x1;",
  0 , 0x0,  0x22, M|O       ,"orw"   ,  "\x2 |\xa\x1;" ,
  0 , 0x0,  0x22, M|O|X     ,"xrw"   ,  "\x2 ^\xa\x1;" ,
  0 , 0x0,     2, M|L       ,"cmpw"  ,  "",                    // "\x2 <\xa\xa> \x1" ,
 104, 0x0,  0x22, M         ,"divw"  ,  "\x2 \xa\x2L / \x1;",
  0 , 0x0,  0x22, M|B|O     ,"orb"   ,  "\x2 |\xa\x1;" ,
  0 , 0x0,  0x22, M|B|O|X   ,"xorb"  ,  "\x2 \xa\x2 ^ \x1;" ,
  0 , 0x0,  0x22, M|B|L     ,"cmpb"  ,  "",                   // \x2 <\xa\xa> \x1 ,

 105, 0x0,  0x22, M|B       ,"divb"  ,  "\x2 \xa\x2 / \x1;",          // 51
  0 , 0x0,  0x22, M         ,"ldw"   ,  "\x2 \xa\x1;" ,              // C
  0 , 0x0,  0x22, M|Z       ,"adcw"  ,  "\x2 +\xa\x1 + Cyflag;" ,
  0 , 0x0,  0x22, M         ,"sbbw"  ,  "\x2 -\xa\x1 - Cyflag;" ,
  0 , 0x0,  0x22, M|B       ,"ldzbw" ,  "\x2 \xa(uns)\x1;" ,         // C
  0 , 0x0,  0x22, M|B       ,"ldb"   ,  "\x2 \xa\x1;" ,               // C
  0 , 0x0,  0x22, M|B|Z     ,"adcb"  ,  "\x2 +\xa\x1 + Cyflag;" ,
  0 , 0x0,  0x22, M|Z       ,"sbbb"  ,  "\x2 -\xa\x1 - Cyflag;" ,
  0 , 0x0,  0x22, M|B       ,"ldsbw" ,  "\x2 \xa(int)\x1;" ,         // C
  0 , 0x0,  0x12, M         ,"stw"   ,  "\x1 \xa\x2;",

  0 , 0x0,  0x12, M|B       ,"stb"   ,  "\x1 \xa\x2;" ,          // 61
 106, 0x0,     1, M|P       ,"push"  ,  "push(\x1);" ,
 107, 0x0,  0x11, M         ,"pop"   ,  "\x1 \xapop();" ,
  0 , 0xd8,    1, J|C|N     ,"jnst"  ,  "\x8!Sflag) \x9" ,
  0 , 0xd9,    1, J|C|N     ,"jleu"  ,  "\x8(uns) \x6 <\xa\x5) \x9" ,
  0 , 0xda,    1, J|C|N     ,"jgt"   ,  "\x8\x6 > \x5) \x9" ,
  0 , 0xdb,    1, J|C|N     ,"jnc"   ,  "\x8!(uns) \x6 < \x5) \x9" , //Cyflag) \x9",
  0 , 0xdc,    1, J|C|N     ,"jnvt"  ,  "\x8!ovtflag \x9" ,
  0 , 0xdd,    1, J|C|N     ,"jnv"   ,  "\x8!ovflag) \x9" ,
  0 , 0xde,    1, J|C|N     ,"jge"   ,  "\x8\x6 >\xa\x5) \x9" ,

  0 , 0xdf,    1, J|C|N     ,"jne"   ,  "\x8\x6 !\xa\x5) \x9" ,    // 71
  0 , 0xd0,    1, J|C|N     ,"jst"   ,  "\x8Sflag) \x9",
  0 , 0xd1,    1, J|C|N     ,"jgtu"  ,  "\x8(uns) \x6 > \x5 ) \x9" ,
  0 , 0xd2,    1, J|C|N     ,"jle"   ,  "\x8\x6 <\xa\x5) \x9" ,
  0 , 0xd3,    1, J|C|N     ,"jc"    ,  "\x8(uns) \x6 >\xa\x5) \x9" ,  // \Cyflag) \x9"
  0 , 0xd4,    1, J|C|N     ,"jvt"   ,  "\x8ovtflag \x9" ,
  0 , 0xd5,    1, J|C|N     ,"jv"    ,  "\x8ovflag) \x9" ,
  0 , 0xd6,    1, J|C|N     ,"jlt"   ,  "\x8\x6 < \x5) \x9" ,
  0 , 0xd7,    1, J|C|N     ,"je"    ,  "\x8\x6 == \x5) \x9" ,
  0 , 0x0,  0x22, J|D       ,"djnz"  ,  "\x2--;\xb\x8\x2 !\xa 0) \x9" ,

  0 , 0x0,     2, J|E       ,"jump"  ,  "\x9",                // 81
 109, 0x0,     2, J|X       ,"call"  ,  "\x1\xc" ,
 110, 0x0,     0, E         ,"ret"   ,  "return;" ,
 111, 0x0,     0, E         ,"reti"  ,  "return;" ,
 112, 0x0,     0, N         ,"pushp" ,  "push(flags);" ,
 113, 0x0,     0, N         ,"popp"  ,  "pop(flags);" ,
  0 , 0x0,     0, N         ,"trap"  ,  "set_sw_trap" ,
  0 , 0x0,     0, N         ,"clc"   ,  "Cyflag \xa\x30;" ,
  0 , 0x0,     0, N         ,"stc"   ,  "Cyflag \xa\x31;" ,
  0 , 0x0,     0, N         ,"di"    ,  "disable ints;" ,

  0 , 0x0,     0, N         ,"ei"    ,  "enable ints;" ,      // 91
  0 , 0x0,     0, N         ,"clrvt" ,  "ovtflag \xa\x30" ,
  0 , 0x0,     0, N         ,"smul"  ,  "" ,                     // prefix op
  0 , 0x0,     0, N         ,"nop"   ,  "" ,
  0 , 0x0,     0, N|R|H     ,"bnk0"  ,  "" ,
  0 , 0x0,     0, N|R|H     ,"bnk1"  ,  "" ,
  0 , 0x0,     0, N|R|H     ,"bnk2"  ,  "" ,
  0 , 0x0,     0, N|R|H     ,"bnk3"  ,  "" ,
  0 , 0x0,     1, R|B|H     ,"rbnk"  ,  "" ,       //ROMbank = \x1;"   // 99

  // 100 onwards is for opcodes with prefix marker

  0 , 0x0,  0x33, M         ,"sml3w"  ,  "\x3L \xa\x2 * \x1;",      // 100
  0 , 0x0,  0x33, M|B       ,"sml3b"  ,  "\x3W \xa\x2\B * \x1\B;" ,
  0 , 0x0,  0x22, M         ,"sml2w"  ,  "\x2L *\xa\x1;",
  0 , 0x0,  0x22, M|B       ,"sml2b"  ,  "\x2 *\xa\x1;",
  0 , 0x0,  0x22, M         ,"sdivw"  ,  "\x2 \xa\x2L / \x1;",
  0 , 0x0,  0x22, M|B       ,"sdivb"  ,  "\x2 \xa\x2 / \x1;",
  0 , 0x0,     1, M|P|H     ,"pusha" ,   "pushalt(\x1);" ,
  0 , 0x0,  0x11, M|H       ,"popa"  ,   "\x1 \xapopalt();" ,
  0 , 0x0,     1, J|B|X|H   ,"scalla" ,  "\x1\xc",
  0 , 0x0,     2, J|X|H     ,"calla"  ,  "\x1\xc" ,

  0 , 0x0,     0, E|H       ,"reta"   ,  "return;" ,             //110
  0 , 0x0,     0, E|H       ,"retia"  ,  "return;" ,
  0 , 0x0,     0, N|H       ,"pushpa" ,  "pushalt(flags);" ,
  0 , 0x0,     0, N|H       ,"poppa"  ,  "popalt(flags);"
  };


/* cmp subtracts sce from dest. if borrow (if sce > dest) then carry
   cleared else set */
 

// interrupt function names in array for auto naming

typedef struct
{ char start;
  char end;
  char *name;
} NAMES;


NAMES inames1[] = {
 8, 8, "IPT_Ignore" ,
 0, 0, "IPT_HSO_2",            // 2010
 1, 1, "IPT_Timer_OVF",
 2, 2, "IPT_AD_Rdy",
 3, 3, "IPT_HSI_Data",
 4, 4, "IPT_External",
 5, 5, "IPT_HSO_1",
 6, 6, "IPT_HSI_1",
 7, 7, "IPT_HSI_0"            // 201f
 };

NAMES inames5[] = {
  40, 40, "IPT_Ignore" ,
  0,  15, "IPT_HSO_\1",          // 2010-201f
  16, 16, "IPT_HSI_FIFO",
  17, 17, "IPT_External",
  18, 18, "IPT_HSI_0",
  19, 19, "IPT_HSI_Data",
  20, 20, "IPT_HSI_1",
  21, 21, "IPT_AD_Imm_Rdy",
  22, 22, "IPT_AD_Timed_Rdy",
  23, 23, "IPT_ATimer_OVF",
  24, 24, "IPT_AD_Timed_Start",
  25, 25, "IPT_ATimer_reset",
  26, 29, "IPT_Counter_\1",
  30, 39, "IPT_Software_\1"    //204-205f
};


struct           // for function inspect and extend
{
long start;
long end[2];
} tvals[] = {
{0xff,0,0},        // unsigned
{0x7f,0x80,0x8000} // signed
};


typedef struct
{
 short nval;
 char nsize;
 char *name;
}  AUTON;

AUTON anames [] = {
1, 3, "Sub",
1, 3, "Lab",
1, 4, "Func",
1, 5, "Table",
1, 5, "Timer"

 };


   /***** default symbols *******/

typedef struct
{
 char * symn;
 short  addr;
 short  bit1;
 uchar O65;        // 1 - 8061, 2 - 8065, 3 both
} DFSYM;

DFSYM defrsyms [] = {               // read and general symbols
 "ZERO"       ,   0, -1, 3,
 "ZERO"       ,   1, -1, 3,
 "CPU_OK"     ,   2,  6, 3,         // both  8061 and 8065
 "LSO_PORT"   ,   2, -1, 3,
 "LIO_PORT"   ,   3, -1, 3,
 "AD_LO"      ,   4, -1, 3,
 "AD_HI"      ,   5, -1, 3,
 "IO_TIMER"   ,   6, -1, 3,
 "AD_TMD_LO"  ,   7, -1, 2,
 "INT_MASK"   ,   8, -1, 3,
 "INT_PEND"   ,   9, -1, 3,
 "HSO_OVF"       ,  0xA , 0, 3,
 "HSI_OVF"       ,  0xA , 1, 3,
 "HSI_RDY"       ,  0xA , 2, 3,
 "AD_RDY"        ,  0xA , 3, 3,
 "INT_SVC"       ,  0xA , 4, 1,   // 8061
 "INT_PRIO"      ,  0xA , 5, 1,
 "MEM_EXP_ON"    ,  0xA , 4, 2,   // 8065
 "HSO_PCNT_OVF"  ,  0xA , 5, 2,
 "AD_TMD_RDY"    ,  0xA , 6, 2,
 "HSO_PORT_OVF"  ,  0xA , 7, 2,
 "IO_STATUS"     ,  0xA , -1, 3,
 "HSI_SAMPLE"    ,  0xB , -1, 3,
 "HSI_MASK"      ,  0xC , -1, 3,
 "HSI_DATA"      ,  0xD , -1, 3,
 "HSI_TIME"      ,  0xE , -1, 3,
 "HSI_TIME_HI"   ,  0xF , -1, 1,
 "AD_TMD_HI"     ,  0xF , -1, 2,

 "STACK"         ,  0x10, -1, 1,   // 8061 only
 "HSO_IPEND1"    ,  0x10, -1, 2,        // 8065 only
 "BANK_SEL"      ,  0x11, -1, 2,
 "HSO_IMASK1"    ,  0x12, -1, 2,
 "IO_TIMER_HI"   ,  0x13, -1, 2,
 "HSO_IPEND2"    ,  0x14, -1, 2,
 "LSSI_A"        ,  0x15, -1, 2,
 "HSO_IMASK2"    ,  0x16, -1, 2,
 "LSSI_B"        ,  0x17, -1, 2,
 "HSO_STATE"     ,  0x18, -1, 2,
 "LSSI_C"        ,  0x19, -1, 2,
 "HSI_MODE"      ,  0x1A, -1, 2,
 "HSO_UCNT"      ,  0x1B, -1, 2,
 "HSO_TIMEC"     ,  0x1C, -1, 2,
 "LSSI_D"        ,  0x1D, -1, 2,
 "HSO_LSLOT"     ,  0x1E, -1, 2,
 "HSO_SLOTSEL"   ,  0x1F, -1, 2,
 "STACK"         ,  0x20, -1, 2,
 "ALTSTACK"      ,  0x22, -1, 2
};

DFSYM defwsyms [] = {               // WRITE symbols

 "AD_CMD"        , 4   , -1, 3,
 "WD_TIMER"      , 5   , -1, 3,
 "AD_TMD_CMD"  ,   7   , -1, 2,
 "HSO_CMD"       , 0xd , -1, 3,
 "HSO_TIME"      , 0xe , -1, 3,
 "HSO_TIMEH"     , 0xf , -1, 3,
 "LSSO_A"        , 0x15, -1, 2,
 "LSSO_B"        , 0x17, -1, 2,
 "LSSO_C"        , 0x19, -1, 2,
 "LSSO_D"        , 0x1D, -1, 2
};

/***********************************************************************/

FILE *fin, *fwrn, *fout, *fdir, *fcmt;

BKS banks[5];            // index 4 for swopping banks around...
short phmarker = 0;
long progmkr = 0;          // for progress bar
long xcn = 0;
long mcalls = 0;
long mrels = 0;
long pcalls = 0;
long ocalls = 0;
long maxalloc   = 0;       //  TEMP for malloc tracing    DON'T use size_t;
long curalloc   = 0;


//short dbg        = 0;       // set for extra debug info
short anlpass    = 1;	    // number of passes done so far
long  cmdopts    = 0;       // command options
long  screenopts = 0;
short incols[] = {24,30,45,76};	 // layout columns
long fillen;               // file size
long hwend   = 0x3ffff;	   // hardware end of ROM value
long ckend   = hwend;	   // checksum zero point
short numbanks;            // number of 8065 banks

short gcol;                // where print is at (no of chars = colno)
char flbuf[TXTSZE+2];	   // for directives and comment file reads
char nm [25];              // for name construction

ushort cmntpc;    	   // last read pc for comment
ushort cmbank;
char *cmtt;                // last comment text

ushort datbank;            // currently selected data bank - always 8 if single bank
ushort codbank;            // from last rbnk or pop ?
short depth;               // for subroutine stacking
short jdepth;              // for jump stacking
short stklev[30];          // pushw/popw balance within this code...and indexed by depth
short rpopped[30];         // which reg(s) are popped ?
short snam[32];            // bit names holder
OPS   savop[3][8];            // three sets of 8 - current (0-3) and last (4-7) operands

//#define opstab optab[jdepth]   // temp fiddle for multidim op table

OPS opstab[8];

SPW  spl;                  // command words container

short tabreg;
short funcreg;
short sizereg;             // for tracking over jumps (tables & funcs)

/// chained items here - which use common find and insert mechanisms..
// type,num entries, num ptrs, allocsize, entry size (bytes), rem, pre, last used, ptr array

// rem,pre = remote ptrs, preallocate buffers

CHAIN  mblocks = {0, 0,0, 50,sizeof(BL) ,0, 1,-1,0};          // malloced blocks table for chains
CHAIN  jpftab  = {1, 0,0,400,sizeof(JLT),0, 1,-1,0};          // jump table (from)
CHAIN  jpttab  = {2, 0,0,400,sizeof(JLT),1, 0,-1,0};          // jump table (to)  REMOTE ptrs
CHAIN  symtab  = {3, 0,0,200,sizeof(SYT),0, 1,-1,0};          // symbol table (main)
CHAIN  subtab  = {4, 0,0,100,sizeof(SXT),0, 1,-1,0};          // subr   table
CHAIN  rbase   = {5, 0,0, 25,sizeof(RBT),0, 0,-1,0};          // rbase  table
CHAIN  sigtab = {6, 0,0, 50,sizeof(SIG),0, 1,-1,0};           // signature  table
CHAIN  tsigtab = {7, 0,0, 25,sizeof(SIG),0, 1,-1,0};          // aux sig table
CHAIN  inhb    = {8, 0,0, 25,sizeof(LBK),0, 0,-1,0};          // inhibit code & scan command chain
CHAIN  cmdch   = {9, 0,0,100,sizeof(LBK),0, 1,-1,0};          // command chain
CHAIN  scanch  = {10,0,0,200,sizeof(LBK)+ADSZ,0, 1,-1,0};     // scan chain, keep LBK for now
CHAIN  symwtab = {11, 0,0,50,sizeof(SYT),0, 1,-1,0};          // WRITE symbol table


// MALLOCED pointers from here

uchar *ibuf;		   // input buffer (file) pointer
short *opst;		   // bit array of start ops
ushort *watch;             // 30*256 = 7680 WORDS. Register watch values for each depth

//short nall;
//BT z[12000];               // DEBUG

struct time ptm;             // debug timing





/************************
 * chaining and admin stuff
 **************************/

void wprt (char *fmt, ...)   // warning file prt
{
  va_list args;
  if (!fmt) return;
  va_start (args, fmt);
  vfprintf (fwrn, fmt, args);
  va_end (args);
}

void dprt (char *fmt, ...) // debug warning file prt
{
  va_list args;
  if (PDBGM && fmt)               //dbg && fmt)
    {
    va_start (args, fmt);
    vfprintf (fwrn, fmt, args);
    va_end (args);
    }
}

void pbk(LBK *b, LBK *v, char* join, char *fmt, ...)       // debug print warn blk
{
 va_list args;
  if (PDBGM && fmt)               //dbg && fmt)
    {
    va_start (args, fmt);
    vfprintf (fwrn, fmt, args);
    va_end (args);
    }
 if (b) dprt (" blk %d|%lx %lx %s",    b->bank, b->start, b->end, dirs[b->fcom].com);

 if (v)
     {
     dprt (" %s",join);
     dprt (" blk %d|%lx %lx %s", v->bank, v->start, v->end, dirs[v->fcom].com);
     }
 dprt("\n");
}


void rprt (char *fmt, ...)   // output file print with return
{
  va_list args;
  if (fmt)
   {
    va_start (args, fmt);
    vfprintf (fout, fmt, args);
    va_end (args);
   }
  fprintf(fout, "\n");   // always add return and reset colno
  gcol = 0;
}

void ptime(short x)
 {
  gettime(&ptm);
  wprt("TIME %d ::%02d:%02d.%02d\n", x,ptm.ti_min, ptm.ti_sec, ptm.ti_hund);
 } 

/****************************************************************
* appends new string to output file
* was carried out as an append instead of a new string.
* uses gnxt as a count offset
* gstr is allocated TXTSIZE+10 as a safety space.
****************************************************************/

void pstr (char *fmt, ...)
{
  va_list argptr;

  if (!fmt) return;
  va_start (argptr, fmt);
  gcol += vfprintf (fout, fmt, argptr);
  va_end (argptr);
}


/******************************************************************
 Std malloc wrapper with totals and zero
 ************************************************/

/*
void logfree(void *addr, size_t size)
  {
  short i;
  if (addr)
   {
    for (i =0; i < nall; i++)
     {
      if (z[i].blk == addr)
       {
        z[i].blk = NULL;
        break;
       }
   }

  if (i==nall)  wprt ("invalid pointer %lx!!\n", addr);
  dprt("!! free\t%lx\t-%ld\t%ld\n", addr, size, curalloc);

   }
}

void logm(void *ptr, size_t size)
 {
  short i;
  if (ptr)
   {
     dprt("!! alloc\t%lx\t%ld\n", ptr, size);

     for (i = 0; i < nall; i++)
     {
      if (z[i].blk == NULL)
       {
        z[i].blk = ptr;
        z[i].size = size;
        break;
       }
     }

    if (i == nall && i < 12000)
       {
       z[nall].blk = ptr;
       z[nall++].size = size;
       }
    if (nall >= 12000)
     {
      dprt ("ouch!");
     }
   }
 }
*/

void mfree(void *addr, size_t size)
 {
  curalloc -= size  ;    /*keep track of mallocs */
  free (addr);
  mrels++;
 // logfree(addr,size);
 }

void* mem(void *ptr, size_t osize, size_t nsize)
{                // alloc or realloc
  void *ans;

  if (nsize < 1) dprt ("Invalid malloc size\n");
 // logfree(ptr,osize);

  if (ptr)  curalloc -= osize;
  mcalls++;
  curalloc += nsize;
  if (curalloc > maxalloc) maxalloc = curalloc;
  ans = realloc(ptr, nsize);
  if (!ans) wprt ("Run out of malloc space\n");
//  logm(ans,nsize);
  return ans;
}

void* cmem(CHAIN *x)
 {
  if (x->pre) return x->ptrs[x->num];  // next free entry
  if (x->rem) return NULL;             // can't have memory on remote chain...
  return mem (0,0,x->size);            // OK, allocate some
}

/************************
 * master exit and cleanup routines
  **************************/

void closefiles(void)
{
  if (fin)  fclose (fin);
  fin = NULL;
  if (fcmt)  fclose (fcmt);
  fcmt = NULL;
  // flush o/p files first
  if (fout)
    {
     fflush (fout);
     fclose (fout);
     fout = NULL;
    }
  if (fdir)
     {
      fflush (fdir);
      fclose (fdir);
      fdir = NULL;
     }
  if (fwrn)
     {
      fflush (fwrn);
      fclose (fwrn);
      fwrn = NULL;
     }
 
}

void freecadt(CADT *x)
 {
  short safe;
  CADT *n;

  safe = 0;
  while (x && safe < 50 ) {
    n =  x->next;
    if (n == x)
        {
         dprt("looped CADT\n");
         n = 0;
         }
    mfree (x, ADSZ);
    x = n;
    safe++;
   }
 }

void freeaddl (LBK *z)
{
  LBK *b;
  b = (LBK*) z;
  freecadt((CADT*) b->addnl);
  b->addnl = NULL;
}

void cfree(CHAIN *x, void *blk)
 {           // return 0 no free, 1 freed
 SXT *t;
 SYT *s;

 if (!blk) return;
 if (x->rem) return;   // no action at all from remote chain

 switch (x->type)
   {
     case 3:
     case 11:
       s = (SYT*) blk;
       mfree (s->symnam, s->f.size);  // symbol string
       break;

     case 4:
     case 9:
       t = (SXT *) blk;
       freecadt (t->addnl);         // addnl command(s)
       break;

     default:
       break;
   }

 if (!x->pre) mfree (blk,x->size);

}


void clearch(CHAIN *x)
{             // clear pointer list contents only
 short i;

 for (i = 0; i < x->num; i++)
    {
     cfree(x,x->ptrs[i]);
     if (!x->pre) x->ptrs[i] = NULL;
    }

 x->num = 0;
 x->last = -1;
 }


void freepreblks(void)
{             // clear pointer list contents only
 short i;
 BL *b;

 // do in reverse order because mblocks logs its own blocks
 for (i = mblocks.num-1; i >=0; i--)
   {
    b = (BL*) mblocks.ptrs[i];
    //  dprt("Release %ld size %ld\n", b->blk,b->size);
    mfree(b->blk,b->size);
    mblocks.ptrs[i] = NULL;
   }
 mblocks.num = 0;
 mblocks.last = -1;
 }

void freeptrs(CHAIN *x)
{                    // free chain pointers
 if (x->pnum)
   {
    mfree(x->ptrs, x->pnum * sizeof(void*));
    x->ptrs = NULL;
    x->pnum =0;
   }
}

void freechain(CHAIN *x)
{
  clearch(x);
  freeptrs(x);
}


void  tidy_exit (short msg)
{
 //void *x;
 //short i;

  freechain(&sigtab);
  freechain(&tsigtab);
  freechain(&cmdch);
  freechain(&scanch);
  freechain(&inhb);
  freechain(&rbase);
  freechain(&jpftab);
  freechain(&jpttab);  
  freechain(&symtab);
  freechain(&symwtab);
  freechain(&subtab);

  freepreblks();
  freeptrs(&mblocks);

  mfree(ibuf,fillen);
  ibuf = NULL;
  mfree(opst,fillen/8);
  opst = NULL;
  mfree(watch,7680*2);
  watch = NULL;
  mfree(spl.wds, sizeof(WDS)*spl.nptrs);
  spl.wds = NULL;

  if (msg)
     {
      dprt ("max alloc = %ld\n", maxalloc);
      dprt ("cur alloc = %ld\n", curalloc);
      dprt ("mcalls = %ld\n", mcalls);
      dprt ("mrels  = %ld\n", mrels);
      dprt ("pcalls = %ld\n", pcalls);
      dprt ("ocalls = %ld\n", ocalls);
      dprt ("xcalls = %ld\n", xcn);

  //    dprt("\n\n!! mallocs left \n");
  //    for (i =0; i < nall; i++)
  //     {
  //      if (z[i].blk != NULL) dprt(" [%d] addr = %lx, size %d\n", i, z[i].blk, z[i].size);
  //      free(z[i].blk);  // test if real....
  //     }
  //    x = malloc(2000);
  //    free(x);                // test

  //    dprt ("END\n");
      wprt( "\n\n------ END Disassembly run ------\n");
     } 
  maxalloc = 0;
  curalloc = 0;
  closefiles();
}


short spchar(char *s)
 {
 short i,j;

 j = 0;
 for (i =0; i < NC(chkch); i++)
     {
     if (*s == chkch[i].value)
        {
         j = chkch[i].action;
         break;
        }
     }
 return j;
}

// can't do this if bank order changes

short findbank(short bnk)
{           //  -1 for invalid bank
 //short ans,i;
 short i;
 //ans = -1;
 if (bnk & 0xfff6) return -1; // only 0,1,8,9

 for (i = 0; i < numbanks; i++)
   if (banks[i].bank == bnk) return i;
 return -1;
 }

 /*switch (numbanks)
  {
   case 1:
    if (bnk == 8) ans = 0;
    break;

   case 2:
    if (bnk == 1) ans = 0;
    if (bnk == 8) ans = 1;
    break;

   case 4:
    ans = ((bnk & 8) /4) + (bnk & 1);
    break;

   default:
    break;
  }
 return ans;
}  */


ulong addr(ushort pc,ushort bank)
{
return (bank << 16) | pc;
}



ushort pcof(long ofst, ushort *bnk)
{
  short i;
  BKS *b;
  pcalls++;
  //if (ofst < 0) ofst = 0;
  for (i = 0; i < numbanks;  i++)     // NC(banks); i++)
   {
    b = banks+i;
    if (ofst <= b->end && ofst >= b->start)   // less comparisons this way round
      {
       if (bnk && b->used) *bnk = b->bank;
       ofst = ofst - b->start + PCORG;
       return ofst & 0xffff;
      }
   }
 if (bnk) dprt ("Invalid Address (ofst->pc)%lx\n", ofst);
 return ofst;
}

long ofpc(ushort pc, ushort bnk)
{
short i;
BKS *b;
   ocalls++;
  i = findbank(bnk);
  b = banks+i;
  if (b->used && b->bank == bnk)
    return b->start + pc - PCORG;

 dprt ("Invalid Address (pc, bk -> ofst) %x, %d\n", pc, bnk);
 return 0;

}

long obend(short bnk)
{             // ofst check for bank end, use real offset.
short i;
i = findbank(bnk);
if (i < 0) return 0;

return banks[i].end;
}

ushort pcbend(short bnk)
{             // PC check for bank, relative 0x2000 - 0xdfff max
short i;
long x;
i = findbank(bnk);
if (i < 0) return 0;
x = banks[i].end-banks[i].start+PCORG;
if (x > 0xdfff) return 0xffff;
return x;
}

//----------------------------------------------------------


ushort wbnk(ushort x)
 {            // return val unless overridden with RBNK (as last instruction)
 if (opstab[5].f.bnk)               // = lastops[1].f.bnk
  {
   if (findbank(opstab[5].xpc) >= 0) return opstab[5].xpc;
   else
     {
     if (anlpass < ANLPRT) dprt("Invalid bank %d - ignored\n", opstab[5].xpc);
     opstab[5].f.bnk = 0;        // clear bank flag
     }
  }
  return x;
 }

ushort dbank(short x)
 {
  if (!x) return datbank;
  return wbnk(datbank);     // return databank
 }

ushort cbank(void)
 {
  return wbnk(codbank);     // return codebank
 }

short iaddr(ushort pc, ushort bnk)
 {        // 1 if invalid 0 if valid   code addresses within bank
 ushort lim;
 lim = pcbend(bnk);
 if (lim < PCORG) return 1;   // bank invalid
 if (pc >= PCORG && pc <= lim) return 0;   // within pcorg to bank end, OK
 return 1;
 }

short invcaddr(ushort pc)
{        // 1 if invalid 0 if valid   code addresses within bank
 return iaddr(pc,cbank());

}

short invdaddr(ushort pc, short x)
{        // 1 if invalid 0 if valid   data addresses within bank
 return iaddr(pc,dbank(x));
}
//---------------------------------------------------------------------------------------

// malloc block management for preallocated buffers of CHAINs




void *pre_buffs(CHAIN *x)    // add preallocated space and log it
  {
  short i;
  size_t msz;
  char *z;
  z = NULL;
  if (x->pre)
      {
       // preallocate the entries too
       msz = x->size*x->asize;
       z =  (char *) mem(0,0,msz);  // null check reqd
      //   dprt("prebuff\t%lx\t%lx\t\n", z, msz);
       if (!z)
        {
        wprt("ERROR ");
        }
       for (i= x->pnum-x->asize;  i < x->pnum; i++)
           {
            x->ptrs[i] = z;
            z += x->size;
           }
       }
     else
     for (i= x->pnum -1; i >= x->pnum - x->asize; i--) x->ptrs[i] = NULL;
     return z;
   }

void adpch(CHAIN *x) ;

void logblk(CHAIN *x, void *blk, size_t size)
{
 BL *b;

 if (!blk) return;

 adpch(&mblocks);

 // special check here for mblocks so that it doesn't crap on its own logging....
 if (!x->type && x->pre && !x->num)
   {       // first log ever, which is of mblocks prealloc itself.....
     x->ptrs[0] = blk;
   }

 if (mblocks.pre) b = (BL*) mblocks.ptrs[mblocks.num];
 else b = (BL*) cmem(&mblocks);
 b->blk = blk;
 b->size = size;
// b->type = x->type;
 mblocks.num ++;
}

void adpch(CHAIN *x)      // add pointers for malloced entries
 {
 long old, nw, msz;
 short i;
 char *z;

 if (x->num >= x->pnum-1)
   {                          // grow pointer array
    old = x->pnum;
    x->pnum += x->asize;
    nw = x->pnum;            // new size
    x->ptrs = (void**) mem(x->ptrs, old*sizeof(void*), nw*sizeof(void*));

    if (x->pre)
      {
       // preallocate the entries too
       z = NULL;
       msz = x->size*x->asize;
       z =  (char *) mem(0,0,msz);  // null check reqd
      //   dprt("prebuff\t%lx\t%lx\t\n", z, msz);
       if (!z)
        {
         wprt("ERROR ");
        }
       logblk(x, z, msz);
       for (i = old;  i < nw; i++)
         {
            x->ptrs[i] = z;
            z += x->size;
         }
      }
     else
     for (i= old; i < nw; i++) x->ptrs[i] = NULL;
     }
 }




void initch(CHAIN *x)     //, short t)
 {                        // initalise chain structure
  x->num  = 0;
  x->last = -1;          // last entry
  x->pnum = 0;
  x->ptrs = NULL;
  adpch(x);             // to add initial  pointers
 }



//-----------------------------------------------------------------

 bool lt(CHAIN *x, short ix, ulong pc, ushort bank, va_list z)
 {
  /* CAREFUL !!  long here is fiddled to overlay to structs for fast comparisons
   DONT fiddle with structures !
   NB.   type 8 and 9 (LBK) use END addresses
  */

  bool ans;
  ulong *sadd;
  ulong add, end;
  short par1;         //, par2;

  if (ix >= x->num) return 0;   // safety

  ans = 0;
  sadd = (ulong*) x->ptrs[ix];  //overlay bank and pc for default structs
  add = addr(pc,bank);

  switch(x->type)
    {
     SYT *s;
     LBK *b;

     case 2:                         // TO jumps
       sadd+=1;                      // equiv to second long address
       if (*sadd < add) ans = 1;
       break;

      case 3:     // bit checking required
      case 11:
        if (*sadd < add) ans = 1;
        if (*sadd == add)
         {
          s = (SYT*) x->ptrs[ix];
          par1 = va_arg(z,short);
          if (s->f.bitno < par1) ans = 1;
         }
        break;

     case 6:         // signatures
     case 7:
       if (*sadd < pc) ans = 1;
       break;

     case 8:
     case 9:   // LBK structs, check END address, not start
       b = (LBK*) x->ptrs[ix];
       end = addr(b->end,b->bank);
       if (end < add) ans = 1;
     break;

     default:
         if (*sadd < add) ans = 1;
     }

  return ans;
}


short bfindix(CHAIN *x, ulong pc, ushort bank, ...)
{

  short mid, min, max, g;
  va_list v;
  va_start(v,bank);

  min = 0;
  max = x->num;


  while (min < max)
    {
      mid = min + ((max - min) / 2);  // safe way to do midpoint (imin, imax);
      g = lt(x, mid,pc, bank,v);     // TEMP keep flag value  (1 is less than)
      if (g) min = mid + 1; else  max = mid;
    }

  x->last = min;         // for easy tracking
  va_end(v);
  return min;
}

// eq is equals for FIND operations

bool eq(CHAIN *x, short ix, ulong pc, ushort bank, ...)
 {
  bool ans;
  ulong *sadd;
  ulong add;
  short par1;

  va_list z;
  va_start(z,bank);

  if (ix >= x->num) return 0;   // safety

  ans = 0;
  sadd = (ulong*) x->ptrs[ix];
  add = addr(pc,bank);

  switch (x->type)
   {
    SYT *s;
    LBK *b;


    case 2:
       sadd+=1;                      // equiv to second long address (to)
       if (*sadd == add) ans = 1;
       break;


    case 3:          //symbol - extra par is bitno
    case 11:
      va_start(z,bank);
      par1 = va_arg(z,short);
      va_end(z);
      s = (SYT*) x->ptrs[ix];
      if (*sadd == add && s->f.bitno == par1) ans = 1;
      break;

     case 6:         // signatures
     case 7:
       if (*sadd == pc) ans = 1;
       break;

    case 8:     // inhb - check for overlap
      b = (LBK*) x->ptrs[ix];
      if (b->bank == bank && b->start <= (ushort)pc && b->end >= (ushort)pc) ans = 1;
      break;

    case 9:     // cmdch - check for overlap and optional command
      b = (LBK*) x->ptrs[ix];
      if (b->bank == bank && b->start <= (ushort)pc && b->end >= (ushort)pc)
        {
         va_start(z,bank);
         par1 = va_arg(z,short);
         va_end(z);
         if (!par1 || par1 == b->fcom) ans = 1;
        }
      break;

    default:
      if (*sadd == add) ans = 1;
      }
  return ans;
 }

void release(CHAIN *x, short ix, short shuffle)
{
 short i;
 void *d;

 if (ix < 0 || ix >= x->num) return;

 cfree(x,x->ptrs[ix]);
 if (!x->pre) x->ptrs[ix] = NULL;

 // move entries up if required
 if (!shuffle) return;
 i = ix;
 d = x->ptrs[ix];   // save pointer
 while (i < x->num)
  {
   x->ptrs[i] = x->ptrs[i+1];
   i++;
  }
 x->ptrs[x->num] = d;  // restore pointer to freed space
 x->num--;
}


short mchk(LBK *l, LBK *h)
{

  /* check that merge blocks is OK  l is lower block, h is higher
  * answers
  * -2  reject (exact match)
  * -1  reject  (default)
  *  0  no overlap (OK)
  *  1  adjacent or overlap merge OK
  *  2  Lower  override merge
  *  3  Higher override merge
  *  4  Lower part override
  *  5  Higher part override
  */

  if (!l || !h) return 0;   // safety
  if (l->bank != h->bank) return 0;   // no overlap, OK to insert

  if (l->fcom == h->fcom)
    {
      if (l->end == h->end && l->start == h->start) return -2;        // exact match

      // adjacent or overlap check - fill, byte, text, word, code, xcode can be merged (0-5)

      if (l->fcom < C_VECT && l->end >= h->start-1 && l->cmd == h->cmd) return 1;
    }

  if (l->end < h->start) return 0;   // No overlap or adjacent

  if (l->fcom != h->fcom)           // && f->end >= g->start from above
     {
      // byte,word (1 -2) can be overridden by code, vect,table,func (5-8).

      if (l->fcom <= C_WORD && l->fcom >= C_BYTE && !l->cmd  &&
          h->fcom >= C_CODE && h->fcom <= C_FUNC )
           {
           // h overrides l - partly override 5, full overide 3
            if (l->start < h->start && l->end < h->end ) return 5;
            else return 3;
           }

      if (h->fcom <= C_WORD && h->fcom >= C_BYTE && !h->cmd &&
          l->fcom >= C_CODE && l->fcom <= C_FUNC )
          {
           // l overrides h - partly override 4, full overide 2
           if (l->start < h->start && l->end < h->end ) return 4;
           else return 2;
          }
     }

  return -1;           // reject by default

 }


void split(LBK *l, LBK *h, short merge)
{

 if (merge)
  {
   if (l->end >= h->start && l->start < h->start && !h->cmd)
     {
      pbk(l, h,"from","ADD cmd - split higher");
      h->start = l->end+1;  //split entry and insert is OK
      if (dirs[h->fcom].word && !(h->end & 1)) h->end--;   // make word correct end
     }
  }
 else
  {
   if (l->end >= h->start && l->start < h->start && !l->cmd)
      {
       pbk(l, h,"from","ADD cmd - split lower");
       l->end = h->start -1;  //split entry and insert is OK
       if (dirs[l->fcom].word && !(l->end & 1)) l->end--;   // make word correct end
      }
  }
}


void merge(LBK *t, LBK *s)
 {
  pbk(s, t,"with", "ADD cmd - merge");
  if (s->start < t->start) t->start = s->start;
  if (s->end   > t->end)   t->end = s->end;
  t->fcom = s->fcom;
//  freeaddl(t);
 }

/*
void pxx(CHAIN *x, short ix)       // debug print warn blk
{
 LBK *b;
 b = 0;
 if (ix > 0) {b = (LBK*) x->ptrs[ix-1];
  dprt ("*** ix-1 %d|%lx %lx %s",    b->bank, b->start, b->end, dirs[b->fcom].com);}
 b = (LBK*) x->ptrs[ix];
  dprt (" ix %d|%lx %lx %s",    b->bank, b->start, b->end, dirs[b->fcom].com);
 if (ix < x->num -1)  {
 b = (LBK*) x->ptrs[ix+1];
  dprt (" ix+1 %d|%lx %lx %s",    b->bank, b->start, b->end, dirs[b->fcom].com);
  }
 dprt("\n");
} */

bool cmdeq(CHAIN *x, short *ix, void *blk)
 {
   /* check if new block can be inserted and do merges as required
   * ordered by START address, so we know that
    l->start < b->start < n->start, and by implication l->end < n->start...
    need to check for merges AFTER block also*/

  LBK *l, *b, *n;       // last, block, next
  short lmg, nmg, z;    // last merge, next merge, check next

  b = (LBK *) blk;
  l = 0;
  n = 0;
  z = (*ix) -1;

  if (z >= 0)       l =  (LBK *) x->ptrs[z];
  if (++z < x->num) n =  (LBK *) x->ptrs[z];

  lmg = mchk(l,b);    // lmg must be 3 for b to override l
  nmg = mchk(b,n);    // nmg must be 2 for b to override n

  if (!lmg && !nmg) return 0;       //OK to insert




  if (nmg < 0 || nmg == 3)
     {
//      pbk(b, n," overlaps","ADD cmd - reject n(%d)", nmg);
      return 1;
     }

  if (lmg < 0 || lmg == 2 || lmg == 4)
     {
 //    pbk(b, l," overlaps", "ADD cmd - reject l(%d)", lmg);
     return 1;
     }

//  pxx(x,*ix);

 /*if (nmg > 1 || lmg > 1)
    {
     wprt(" Dummy");  // temp for debug
     } */

  if (lmg == 3)
    {
     split (l,b,0);
     lmg = 0;
     if (nmg <= 0) return nmg;
    }
  if (lmg == 5)
    {
     split(l,b,0);
     lmg = 0;
     if (nmg <= 0) return nmg;
    }


  if (lmg == 1)  merge (l,b);          //pbk(b, l,"ADD cmd - merge with prev");
  if (lmg)  nmg = 0;       // clear forward merge....

  if (nmg == 2)
   {
     release(x,*ix,1);             // release n and remap
     n =  (LBK *) x->ptrs[*ix];
     nmg = mchk(b,n);
     if (nmg <= 0) return nmg;
   }

  if (nmg == 1)  merge(n,b);



     // now check that merged block does not overlap next block
     //can now change to single pass for both cases....

  if (lmg || nmg)          // check for both 1 AND 2 !!
      {
      z = 1;
     while (*ix < x->num && z > 0)
       {
        z = mchk(l,n);
        switch (z)
         {
          case 0:
            break;
          case 1:               // merge cmds
            merge(l,n);
            // fall through
          case 2:              //  Lower overrides
            release(x,*ix,1);             // release n and remap
            n =  (LBK *) x->ptrs[*ix];
            break;

    /*      case 3:  //*  3 - Higher override merge
           break; */

          case 4:  // *  4 - Lower part override
            split(l,n,1);
            break;


          case 5:         //  Higher part overrides
            split(l,n,0);
           break;

         default:
          wprt("deflt");       // temp !!
         break;
         }
       }
     }
   return 1;
  }



bool bmatch(CHAIN *x,short *ix, void *blk)
 {                // for checking duplicates or overlaps with INSERT
   JLT *j, *z;
   SYT *s;
   RBT *r;
   SIG *g;
   LBK *b;
 //  LSCN *a;

   short ttt;
   if (*ix >= x->num) return 0;

   switch(x->type)
   {
    case 1:
    case 2:
      j = (JLT *) blk;
      z = (JLT *) x->ptrs[*ix];
      if (j->tbank == z->tbank && j->to == z->to &&
          j->fbank == z->fbank && j->from == z->from) return 1;   // duplicate jump
      break;

    case 5:
      r = (RBT *) blk;
      return eq(x,*ix,r->reg,r->bank);

     case 6:
     case 7:
       g = (SIG*) blk;
       return eq(x,*ix,g->ofst,0);

    case 8:   // inhb - check for OVERLAP or ADJACENT ...
    case 9:    // commands

    //  pxx(x,*ix);
          ttt = cmdeq(x, ix, blk);
     //     pxx(x,*ix);
          return ttt;
    case 10:       // scans
         b = (LBK*) blk;
    //     a = (LSCN*) b->addnl;
         ttt = eq(x,*ix, b->start,b->bank);   //,a->tabaddr,a->funcaddr);
         return ttt;

    //  break;

    default:
      s = (SYT*) blk;
      return eq(x,*ix, s->pc,s->bank,s->f.bitno);
    }
return 0;
}



void *find(CHAIN *x, ulong pc, ushort bank, short par)
 {
 short i;
 i = bfindix(x, pc,bank, par);
 if (eq(x,i,pc,bank,par)) return x->ptrs[i];
 return NULL;
 }


void insert(CHAIN *x, short ix, void *blk)
{
 short i;
 void *z;
 if (!blk) return;

 adpch(x);

 if (ix < x->num)
   {
    // move entries above ix to make a space, and reassign IX ptr (for preassigned space).
    i = x->num;
    z = x->ptrs[i];
    while (i > ix)  {
      x->ptrs[i] = x->ptrs[i-1];
      i--;
      }
      x->ptrs[i] = z;     // this IS the new block for preallocs
   }
 if (!x->pre) x->ptrs[ix]= blk;
 x->num ++;
}

void *chain(CHAIN *x, void *blk)
{                    // 0 if OK, dupl otherwise
 short ix;
 SYT *b;
 JLT *j;
 RBT *r;
 SIG *g;

 switch(x->type)
   {
    case 1:
      j = (JLT *) blk;
      ix = bfindix(x, j->from, j->fbank);
      break;

    case 2:
      j = (JLT *) blk;
      ix = bfindix(x, j->to, j->tbank);
      break;

    case 5:
      r = (RBT *) blk;
      ix = bfindix(x, r->reg, r->bank);
      break;

     case 6:
     case 7:
       g = (SIG*) blk;
       ix = bfindix(x, g->ofst, 0);
       break;

    default:
      b = (SYT*) blk;
      ix = bfindix(x, b->pc, b->bank, b->f.bitno);
      break;
    }
 if (bmatch(x,&ix,blk))
   {
    cfree(x,blk);
    return x->ptrs[ix];
   }
 insert(x, ix, blk);

 return 0;
 }


void strtch(CHAIN *x)
 {
  x->last = 0;
 }

void *gnxtch(CHAIN *x)
{

 void *ans;
 if (x->last < 0) x->last = 0;
 if (x->last >= x->num)
   {
   x->last = -1;
   return NULL;
   }
 ans = x->ptrs[x->last];
 x->last++;
 return ans;
}


//------------------------------------------------------------------------


void set_opxstart (long ofst)
{
  short bit;

  if (ofst< 0 || ofst > fillen)
  {
    dprt ("Invalid offset set opstart  %lx\n", ofst);
    return;
    }
  bit = ofst & 0xF;
  ofst = ofst / 16;
  opst[ofst] |= (1 << bit);
}

void set_opstart(ushort pc,ushort bank)
{
 set_opxstart(ofpc(pc,bank));
} 








short get_opxstart (long ofst)
{
  short bit;

  if (ofst<0 || ofst > fillen)
  {
    dprt ("Invalid offset get opstart  %lx\n", ofst);
    return 0;
    }

  bit = ofst & 0xF;
  ofst = ofst / 16;
  return opst[ofst] & (1 << bit);
}


void do_jumps (void)
{

/******* jumps checklist ***************
 check if small jump can be flipped to {} ?
 MUST check for multiple end points (if then else)
 and also more than just adjacent entries, and backwards jumps
 which can be while constructs...

 use opstart to decide if jumps are adjacent (AND, OR)
 and note that static jumps should not make overlapping
 conditional jumps into complex ones.....
 MUCH MORE to do yet.
 nned to exclude static jumps for now !!

 ALSO put bank pointer in here for speed of listing later with find_jumps

 MUST REORDER THIS TO MAKE IT QUICKER....

*****************************************/

 short ix, zx;     // have to use indexes here as interleaved

 JLT *f, *t;

 for (ix = 0; ix < jpftab.num; ix++)
    {
     f = (JLT*) jpftab.ptrs[ix];
    show_prog (f->from, anlpass, fillen);

    for (zx = 0; zx < jpftab.num; zx++)
     {
      t = (JLT*) jpftab.ptrs[zx];
      if (f == t) continue;
      if (f->fbank != t->fbank) continue;
      if (f->tbank != t->tbank) continue;

      if (t->f.reti && f->to   == t->from) f->f.retn = 1;
      if (t->f.reti && f->from == t->from) f->f.retn = 1;

       if (f->f.cond && t->f.cond)
         { // inside to outside
         if (t->from > f->from && t->from < f->to &&
            (t->to   < f->from || t->to   > f->to ))  f->f.uncl = 1;

          // outside to inside
         if (t->to > f->from && t->to < f->to  &&
            (t->from   < f->from || t->from < f->to )) f->f.uncl = 1;
         }
       if (f->to != t->to && f->from == t->from)  f->f.mult = 1;
       if (f->to == t->to && f->from != t->from)  f->f.mult = 1;  // multiple jumps to same place

       if (f->from+f->f.cnt == t->to && !f->f.reti && !t->f.reti) f->f.adj = 1;             // adjacent




    }
  }

}

void prt_ex(void *add, short com, SXT *xsub )
{

CADT *s;


short flg, levs;

if (com == C_VECT) return;   // no addnl params for vect

s = (CADT *) add;
levs = 0;

while (s && levs < MAXLEVS)
  {
 //  dprt("(addnl, size = %d)",s->f.esize);
   if (!s->f.nods) wprt(" :");
   if (s->f.sign)                         wprt("S ");
   if (s->f.esize == 1 && com != C_BYTE)  wprt("Y ");
   if (s->f.enc)                          wprt("E %d %x ", s->f.enc, s->divisor);
   else
   if (s->f.esize == 2 && com != C_WORD)  wprt("W ");
   if (s->f.esize == 4)                   wprt("L ");

   // only print fieldwidth if it's not standard

   switch(s->f.esize)
     {
     case 4:
       flg = 7;
       break;
     case 2:
       flg = 5;
       break;
     default :
       flg = 3;
       break;
     }
   if (s->f.sign) flg++;  // add space for sign

   if (s->f.pfw && s->f.pfw != flg)  wprt("P %x ",s->f.pfw);
   if (s->f.hex)                   wprt("X ");
   if (s->f.cnt > 1)               wprt("O %+d ", s->f.cnt);
   if (s->f.foff)                  wprt("D %x ", s->divisor);
   if (s->f.dp)                    wprt("V %+d ", s->divisor/100);
   if (s->f.vect)                  wprt("R ");
   if (s->f.name)                  wprt("N ");

   if (s == s->next) {wprt ("__LOOP__"); return;}         // safety
   s = s->next;
   levs++;
  }

 if (xsub && xsub->ptype)
       wprt (" : F %x %x %x ", xsub->ptype, xsub->adreg, xsub->szreg);

}

void prt_bnks(void)
{
short i;
for (i = 0; i < NC(banks); i++)
 {
  if (banks[i].used)
     {
     wprt ("bank %d  start %5lx  end %5lx\n",
      banks[i].bank, banks[i].start,banks[i].end);
     }
 }
}

void prtflgs(short z, long flgs)
{
 short i;
 if (!z) return;

 flgs &= ~PDBG;        // strip debug markers

 for (i = 0; i < 32; i++)
   {
    if (flgs & (1 << i)) wprt("%c ", i+'A');
   }
}

void prt_opts(short z)
{
// print opt flags and banks
 short i;
 if (!z) return;
 wprt("opts   :" );
 prtflgs(z,cmdopts);
 wprt("\n\n");
 for (i = 0; i < NC(banks); i++)
  if (banks[i].used) wprt("bank   %5lx %5lx %d \n" ,banks[i].start, banks[i].end, banks[i].bank);
}

void prt_commands (void)
{
  LBK *c;
  LSCN *a;

  wprt("\n\n----- Commands ------ \n");
  dprt("inhb = %d, scans = %d, cmds = %d\n", inhb.num,scanch.num, cmdch.num);
  prt_opts(1);

  strtch(&inhb);

  while (c = (LBK*) gnxtch(&inhb))
    {
     wprt("%-7s %4lx  %4lx", dirs[c->fcom].com, c->start, c->end);
     if (banks[1].used) wprt(" %d", c->bank);
     wprt("\n");
    }
  wprt("\n\n");

  strtch(&scanch);

  while (c = (LBK*) gnxtch(&scanch))
    {
    if  (PDBGM || c->cmd)                  // dbg || c->cmd)
     {
      wprt("%-7s %4lx ", dirs[c->fcom].com, c->start);
      if (banks[1].used) wprt(" %d ", c->bank);
      dprt ("   scans %d", c->scanned);
      if (c->cmd) dprt(" (cmd)");
      a = (LSCN*) c->addnl;
      dprt ("   tabaddr %hx, funcaddr %hx, fsize %hd" ,a->tabaddr, a->funcaddr,a->fsize);
      wprt("\n");
     }
    }

  wprt("\n\n");
  strtch(&cmdch);

  while (c = (LBK*) gnxtch(&cmdch))
    {
    wprt("%-7s %4lx  %4lx ", dirs[c->fcom].com, c->start, c->end);
    if (banks[1].used) wprt(" %d ", c->bank);
    prt_ex(c->addnl, c->fcom, NULL);
    if (c->cmd) dprt(" (cmd)");
    wprt("\n");
    }
    wprt("\n\n");
}

SYT* get_sym(CHAIN *c, ushort pc, ushort bank, short bit)
{
  SYT *x, *z;

  // separate chain structs for read and write syms

  if (pc < PCORG) bank = 8;   // temp fiddle for RAM, KAM regs

  if (bit >= 0) z = (SYT*) find(c,pc,bank,-1); else z = 0;
  x = (SYT*) find(c,pc,bank,bit);
  if (!x && bit > 7) x = (SYT*) find(c,pc+1,bank,bit-8);

  if (x)
     {
     x->f.used =1;
     return x;
     }

  if (z)
     {
      z->f.used = 1;
      return z;   // return 'whole' symbol if bits (byte and word) not found;
     }

  return 0;
}


char* get_sym_name(CHAIN *c,ushort pc, ushort bank, short bit)
  {
  SYT* x;
  x = get_sym(c,pc, bank, bit);
  if (x) return x->symnam;
  return NULL;
  }



void prt_subs (void)
{
  SXT *s;
  SYT *x;

  wprt("------------ Subroutine list \n");
  dprt("num subs = %d\n", subtab.num);
  strtch(&subtab);

  while (s = (SXT*) gnxtch(&subtab))
      {
       wprt("sub  %lx  " ,  s->pc);
       if (banks[1].used) wprt("%d  ", s->bank);
       x = get_sym(&symtab,s->pc,s->bank, -1);
       if (x)
          {
           wprt("%c%s%c  ", '\"', x->symnam, '\"');
           x->f.prtd = 1;        // printed as subr
           }
       prt_ex(s->addnl,C_SUBR,s);

       if (s->ptype)  dprt (" #ptype %x", s->ptype);
       if (s->szreg)  dprt (" #szr %x", s->szreg);
       if (s->adreg)  dprt (" #adr %x", s->adreg);
       if (s->size)   dprt (" #size %d", s->size);
       if (s->levels) dprt (" #levs %d", s->levels);
       wprt("\n");
      }
  }


void prt_syms (void)
{
 SYT *x;

 wprt ("\n------------ Symbol list \n");
 dprt("num syms = %d\n", symtab.num);
 strtch(&symtab);        // start of symbols
 while (x = (SYT*) gnxtch(&symtab))
   {
   if (!x->f.prtd)     // not printed as subr
     {
     wprt("SYM   %lx", x->pc);
     if (banks[1].used) wprt(" %d ",x->bank);
     wprt(" \"%s\"",x->symnam);


     if (x->f.bitno >= 0) wprt(" :T +%x" , x->f.bitno);
     if (!x->f.used) dprt ("      ##NOT USED");
     wprt("\n") ;
     }
   }
  // write syms - TEMP
 wprt ("\n------------ WRITE symbol list \n");
 dprt("num syms = %d\n", symwtab.num);
 strtch(&symwtab);        // start of symbols
 while (x = (SYT*) gnxtch(&symwtab))
   {
   if (!x->f.prtd)     // not printed as subr
     {
     wprt("SYM   %lx", x->pc);
     if (banks[1].used) wprt(" %d ",x->bank);
     wprt(" \"%s\"",x->symnam);


     if (x->f.bitno >= 0) wprt(" :T +%x" , x->f.bitno);
     if (!x->f.used) dprt ("      ## NOT USED");
     wprt("\n") ;
     }
   }

 }



void prt_rbt (void)
/* x can be rbase or watch */
{
  RBT *x ;
  strtch(&rbase);     //x = rbase;
  while (x = (RBT*) gnxtch(&rbase))
   {
    wprt("rbase %x %lx\n" , x->reg , x->addr);
   }
}


void prt_dirs(void)
{
/* print all directives */
wprt("\n---- Final command list (can copy&paste for new dir file) -------\n");
prt_commands();
prt_rbt();
prt_subs();
prt_syms();
}

void prt_jumps (CHAIN *x)
{
 JLT *j;

  if (!PDBGM) return;                   // dbg

  wprt ("------------ Jump list \n");
  dprt("num jumps = %d\n", x->num);
  strtch(x);             // start of list

  while(j = (JLT*) gnxtch(x))
    {
      wprt ("from %d|%lx (%lx) to %d|%lx , type %s%s%s%s%s%s%s%s",
	      j->fbank,j->from, j->from+j->f.cnt, j->tbank,j->to,
              j->f.subr ? "subr, " : "",
	      j->f.back ? "back, " : "",
	  //    j->f.stat ? "stat, " : "",
	      j->f.cond ? "cond, " : "stat,",
	      j->f.uncl ? "uncl, " : "",
              j->f.reti ? "reti, " : "",
              j->f.retn ? "retn, " : "",
              j->f.adj  ? "adjc, " : "",
	      j->f.mult ? "mult, " : "" );

      if (j->f.used) wprt(" (Used)");
      if (j->fbank != j->tbank) wprt("  -- BSWOP --" );
      wprt ("\n");
    }


}




LBK* chk_free (ushort pc, short bank)
{
  LBK *b;    // check addr is free for vect structures

  if (iaddr(pc, bank)) return NULL;

  b = (LBK *) find(&cmdch,pc,bank,0);
  if (!b) b = (LBK *) find(&scanch,pc,bank,0);
  if (b)
    {
     pbk(b, 0, NULL,"Found blk for pc %d:%lx", bank,pc);
     return b;
     }
  return NULL;
}


CADT* add_ext (void *b)
  {
  CADT *x;
  LBK *z;

  z = (LBK*) b;

  if (z && z->addnl) return (CADT*) z->addnl;
  x = (CADT *) mem (0,0,ADSZ);
  if (z)  z->addnl = x;
  x->divisor  = 0;
  x->next     = NULL;
  x->flags    = 0x402;     // cnt =1 and esize = 1 rest = 0
  return x;
  }


ushort get_watch(short depth,short reg)
{
  if (reg <= 1 || reg > 0xFF || depth > 29) return 0;

  depth *= 256;

  return watch[depth+reg];         //watch[(depth*256)+reg];
 }


void upd_watch(short depth, short reg, ushort pc)
{

  if (anlpass >= ANLPRT || reg <= 1 || reg > 255 || depth >= 30) return ;
  dprt("UPD REG (L%d) %x = %x\n" , depth, reg , pc);
  depth *=256;
  watch[depth+reg] = pc;


}


void inc_watch(short reg, short size, long from)
{
  if (anlpass >= ANLPRT || reg <= 1 || reg > 255 || depth >= 30) return ;
  watch[(depth*256)+reg] += 1 + size;
 // dprt("INC REG %x = %lx from %lx \n" , reg , watch[(depth*256)+reg], from);
}

LBK* add_scan (ushort pc, ushort bnk, ushort called, ushort cbnk)
{
  LBK *s;
  LSCN *a;
  char *z;
  short ix;

  if (anlpass >= ANLPRT)    return 0;
  if (iaddr(pc, bnk))
    {
      dprt ("IGNORE invalid scan address %d|%lx from %d|%lx\n", bnk, pc, cbnk,called);
      return 0;
    }

  if (find(&inhb,pc,bnk,0))
     {
     dprt("IGNORE scan %lx called from %lx (XCODE)\n", pc, called);
     return 0;
     }

  if (PMANL)
      {
       dprt("ignore scan %lx in manual mode\n", pc);
       return 0;
      }

  s = (LBK *) cmem(&scanch);
  s->start = pc;
  s->end = pc;
  s->bank  = bnk;
  s->size2 = 0;        //depth;
  s->fcom = C_SCAN;
  s->scanned = 0;
  s->cmd = 0;
 // s->err = 0;
  
  z = (char*) s;       // LSCN is now straight after LBK block
  z += sizeof(LBK);
  s->addnl = z;
  a = (LSCN*) s->addnl;

  a->tnext = 0;
  a->tprev = 0;
  if (!called)
   {
    a->tabaddr  = 0;
    a->funcaddr = 0;
    a->fsize    = 0;
    a->from     = 0;
    a->fbank    = 0;
   }
  else
   {
    a->tabaddr  = get_watch(depth,tabreg);
    a->funcaddr = get_watch(depth,funcreg);
    a->fsize    = get_watch(depth,sizereg);
    a->from     = called;
    a->fbank    = cbnk;
   }

  ix = bfindix(&scanch, s->start, s->bank,a->tabaddr,a->funcaddr,a->fsize);

  if (bmatch(&scanch,&ix, s) )
     {
   //   pbk (s,NULL,0,"dupl scan %d|%lx called=%d|%lx", bnk, pc, cbnk, called);
      cfree(&scanch,s);
      return 0;
     }


  insert(&scanch, ix, s);
  dprt ("add scan %d|%lx called=%d|%lx depth %d j %d\n", bnk, pc, cbnk, called, depth, jdepth);
  return (LBK*) scanch.ptrs[ix];

}


LBK* add_cmd (ushort pc, ushort bnk, ushort called, ushort cbnk, ushort end, char com, ushort cmd)
{
  LBK *n;
  CADT *a;
  short ix;

  a = NULL;
  if (anlpass >= ANLPRT)    return NULL;

  if (iaddr(pc, bnk))
    {
      dprt ("ignore invalid cmd address %d|%lx from %d|%lx\n", bnk, pc, cbnk,called);
      return 0;
    }
  if (end < pc) end = pc;

  if (com == C_SCAN) return add_scan (pc, bnk, called, cbnk);

  if (com == C_CODE && find(&inhb,pc,bnk,0))
     {
     dprt("IGNORE code (XCODE) %lx called from %lx\n", pc, called);
     return 0;
     }



  n = (LBK *) cmem(&cmdch);
  n->start = pc;
  n->end   = end;
  n->bank  = bnk;
  n->fcom  = com;
  n->addnl = 0;
  n->size1 = 0;              // CPARS and struct (subr or data) sizes
  n->size2 = 0;              // set if split printout
  n->scanned = 0; // : 1;      // scan complete temp make char for no of scans
  n->term  = 0;          // data command has single terminating byte(s)
  n->cmd = cmd;          // by command, or guess

  ix = bfindix(&cmdch, n->start, n->bank);

  if ( bmatch(&cmdch,&ix, n) )
     {

    //pblk (n,NULL,"dupl cmd %s %d|%lx-%lx called=%d|%lx",
    //      dirs[com].com, bnk, pc, end, cbnk, called);
   cfree(&cmdch,n);
   //if it's VECT over word can be accepted !!
   return (LBK*) cmdch.ptrs[ix];        // ALWAYS return a valid block ??
   }

  if (com == C_VECT)   // add defaults FIRST before chaining
    {
     a = add_ext(n);

     a->f.hex = 1;
     a->f.vect = 1;
     a->f.name = 1;
     a->f.esize = 2;
     }

  if (com == C_WORD || com == C_BYTE)
     {
     a = add_ext(n);
     a->f.nods = 1;
     if (com == C_WORD) a->f.esize = 2;
     }

  insert(&cmdch, ix, n);
  dprt ("add cmd %s %d|%lx-%lx called=%d|%lx\n",
          dirs[com].com, bnk, pc, end, cbnk, called);
  return (LBK*) cmdch.ptrs[ix];
}



void add_endblk (LBK *blk, ushort pc, short stop)
{
  if (anlpass >= ANLPRT || PMANL ) return;        // 0;


  //if(jdepth) return;



  if (jdepth || pc < PCORG || pc > pcbend(blk->bank) || pc < blk->start )
    {
      dprt ("Ignore end %lx to blk %d|(%lx %lx) dp %d jdp %d\n",
	      pc, blk->bank, blk->start, blk->end, depth, jdepth);
      return;  // 0;
    }

   if(!stop) return;     // 0;                // test !!


  dprt ("add end %d at %lx to blk %d|[%lx %lx] depth %d %d\n",
	  stop, pc, blk->bank, blk->start, blk->end, depth);

  if (pc > blk->end) blk->end = pc;  //temp end marker on scan block

  //DON'T add cmd if stopped in error (need extra value passed in)

  if (stop) add_cmd(blk->start,blk->bank,0,0, blk->end,C_CODE,1);

  //return 1;
}


void scan_blk(LBK* blk, ushort pc, ushort bank)
 {
 ushort cnt;
 long xofst;

 if (jdepth > 2)
  {
   dprt("Abandon Jump d>3 %d|%lx\n",bank,pc);
   return;  // safety
   }
   
// dprt ("Code scan SUB from %d:%lx, depth %d\n", blk->bank,blk->start,depth);

 xofst = ofpc(pc,bank);
 cnt = 1;
 while (cnt && xofst <= fillen)
  {
   process_sigs(blk, xofst);
   cnt = pp_code (&xofst, blk);
   if (xofst > obend(bank))
      {
       // pc looped around or offset over bank end
       dprt ("Hit BANK end - STOP\n");
       add_endblk (blk, pcbend(bank), 1);   // scan only
       cnt = 0;
      }
  }
}

void scan_code (LBK *blk)    //, short depth)
{
  LSCN *a;

  if (!blk ) return;

  //depth = blk->size2;        // restore depth - CAN'T do this for subroutines !!

  a = (LSCN*) blk->addnl;
  stklev[depth] = 0;   // reset stack balance for each run...

  show_prog (ofpc(blk->start, blk->bank), anlpass, fillen);

  upd_watch(depth,tabreg, a->tabaddr);
  upd_watch(depth,funcreg,a->funcaddr);
  upd_watch(depth,sizereg,a->fsize);        // restore regs for table tracking


  dprt ("Code scan at %d:%lx, d %d,j%d tab %x func %x, from %d|%lx\n",
        blk->bank,blk->start,depth,jdepth, a->tabaddr,a->funcaddr, a->fbank, a->from);
  //if (a->tprev) dprt(" prev %lx", a->tprev->start);
  //dprt("\n");

  scan_blk(blk,blk->start, blk->bank);

  dprt ("END Code scan %d:%lx to %lx, d %d j %d\n",
        blk->bank,blk->start,blk->end,depth, jdepth);

   if (!jdepth) blk->scanned ++;                       // jdepth set if jump call
   if (PLCOD) rprt ("## end of block ##");
}


/**********************************
Master get from buffer with range check.
ONLY safe access from read buffer
***********************************/

uchar get_byte (long ofst)
{
  if (ofst < 0 || ofst >= fillen)
    {
      dprt ("Get Ignored, ofst = %lx\n", ofst);
      return 0;
    }
  return ibuf[ofst];
}

short chk_data (long ofst)
 {
  // checks if probable data in code block
  short cnt;
  uchar val;
  if (anlpass >= ANLPRT) return 0;

  cnt = 1;

  val = get_byte(ofst++);   // first char;

  while(ofst > 0 && ofst < fillen )
    {
      if (get_byte (ofst++) != val) break;
      cnt++;
      if (val == 0 && cnt >=2) return 1;
      //if (val == 0xff && cnt >=10) return 1;
      if (cnt >=5) return 1;
    }
  return 0;
 }

/*************************************
Multiple scale general get value.
scale = num of bytes (1,2,4)
sign  = signed/unsigned.
Auto Negates value if sign bit set
***********************************/

long g_val (long ofst, short scale, short sign)
{
  long val, mask;

  val = 0;
  mask = 1L << (scale * 8 - 1);	/* where sign bit resides */

  for (scale = scale - 1; scale >= 0; scale--)
    val = (val << 8) | get_byte (ofst + scale);

  if (sign && (val & mask))
    {
      val |= ~(mask - 1);
    }

  return val;
}

long g_val (ushort pc, ushort bank, short scale, short sign)
 {
  long ofst;
  ofst = ofpc(pc,bank);
  return g_val(ofst,scale,sign);
 }


char *aname (short x)
 {
  sprintf(nm, anames[x].name);
  sprintf(nm+anames[x].nsize, "%d", anames[x].nval++);
return nm;
}

void undoanm(short x)
 {
  if (anames[x].nval > 1) anames[x].nval--;
 }


/************************************************
 *   add symbol
 * addr       address to assoc. with name
 * bitno      bit number PLUS 1  (0 is no bits)
 * fnam       name to add
 ************************************************/

SYT * new_sym (CHAIN *x, char *fnam, ushort addr, ushort bank, short bitno)
{
   SYT *xsym, *csym;
   short z;

   csym = get_sym(x,addr,bank, bitno);

   if (csym)
     {
   //  dprt (" ignore duplicate sym of %s @ %d|%lx",csym->symnam,bank,addr);
   //  if (bitno >=0 ) dprt (" bitno %d", bitno);
   //  dprt("\n");
     return 0;
    }

   xsym = (SYT *) cmem(x);                //&symtab);
   if (!xsym) return 0;
   xsym->pc = addr;
   xsym->bank = bank;
   xsym->flgs = 0;
   xsym->f.bitno = bitno;
   z = strlen (fnam) + 1;   // include null;
   if (z > 31) z = 31;    // max storage size
   xsym->f.size = z;

   xsym->symnam = (char *) mem (0,0,xsym->f.size);
   if (!xsym->symnam) return 0;
   strncpy (xsym->symnam, fnam,z);
   //xsym->symnam[31] = '\0';                  // safety
   csym = (SYT*) chain(x,xsym);
   dprt ("add sym %s at %d|%lx", fnam, bank,addr);
   if (bitno >=0) {dprt (" bit %d", bitno); }
   dprt("\n");
   return xsym;
}

SYT *add_sym (char *fnam, ushort addr, ushort bank, short bitno)
{
  if (anlpass >= ANLPRT) return 0;
  if (!fnam || *fnam == NULL) return 0;   /* safety */
  if (addr < PCORG) bank = 8;  // fix RAM KAM for now
  return new_sym(&symtab,fnam,addr,bank,bitno);
 }

SYT *add_wsym (char *fnam, ushort addr, ushort bank, short bitno)
{
  if (anlpass >= ANLPRT) return 0;
  if (!fnam || *fnam == NULL) return 0;   /* safety */
  if (addr < PCORG) bank = 8;  // fix RAM KAM for now
  return new_sym(&symwtab,fnam,addr,bank,bitno);
 }

SYT * add_symn (short ix, ushort addr, ushort bank, short bitno)
{
  SYT *xsym;
  char *fnam;
  if (anlpass >= ANLPRT) return 0;
  if (ix == 0 && !PPROC) return 0;
  if (ix == 1 && !PLABEL) return 0;

 fnam = aname(ix);
 xsym = new_sym(&symtab,fnam,addr,bank,bitno);
 if (!xsym) undoanm(ix);
 return xsym;
 }



void upd_sym (char *fnam, ushort addr, ushort bank, short bitno)
{
  SYT *xsym;
  short z;

  if (anlpass >= ANLPRT) return;

  xsym = get_sym(&symtab,addr,bank, bitno);
  if (!xsym) { add_sym (fnam, addr, bank, bitno); return; }
  z = strlen (fnam) + 1;
  if (z > 31) z = 31;    // max storage size
  if (z > xsym->f.size)
     {
      xsym->symnam = (char *) mem (xsym->symnam,xsym->f.size,z);
      if (!xsym->symnam) z = 0;
      xsym->f.size = z;
     }
  strncpy (xsym->symnam, fnam,z);
  dprt ("upd sym %s at %lx", fnam, addr);
  if (bitno >=0) {dprt (" bit %d", bitno); }
  dprt("\n");
}

void do_subname(SXT *sub)
{

 if (!sub) return;
 if (sub->cmd) return;  // can't change command name
 //if (get_sym(sub->pc, sub->bank, -1))  return; // already has name

 switch (sub->ptype & 0x3f)
   {
   default:
     if (get_sym(&symtab,sub->pc, sub->bank, -1))  return; // already has name
     add_symn(0,sub->pc,sub->bank, -1);    // auto subr name
     break;

   case 1:
     sprintf(nm, "%c" ,  (sub->ptype & 0x80) ? 'S': 'U');
     sprintf(nm+1, "%c" ,(sub->ptype & 0x40) ? 'S': 'U');
     sprintf(nm+2, "%s" , (sub->szreg == 2) ? "WordLU" : "ByteLU");
     upd_sym(nm,sub->pc, sub->bank, -1);
     break;

   case 2:
     sprintf(nm, "%c" , (sub->ptype & 0x80) ? 'S': 'U');
     sprintf(nm+1, "TabLU");
     upd_sym(nm,sub->pc, sub->bank, -1);
     break;
  }

}

/***********************************************
 *   get label name for pc and assign operand parameter
 *   returns:    str ptr if found     0 otherwise
      b only used for bit field....

 if sym is marked subroutine then check watch values for table or func ?
 ************************************************/

char *op_vnam (ushort pc, ushort bank, OPS *o, OPS *b)
{
  SYT *x;

  x = NULL;
  if (o)
    {
      o->name = NULL;
      o->xpc  = pc;
      o->bank = bank;
    }

   if (!pc || anlpass < ANLPRT) return NULL;                  // shortcut for zeroes and print

   if (o->f.wrt) x = get_sym (&symwtab,pc, bank, b ? b->xpc: -1);
   if (!x) x = get_sym (&symtab,pc, bank, b ? b->xpc: -1);
   if (x)
      {
       if (x->f.bitno < 0) b = 0;
     //  if (x->f.bits) o->f.flg = 1;
       if (o < 0) return x->symnam;
       if (b) b->f.ign = 1;   // ignore name if bit valid
       if (o->f.reg) o->name = x->symnam;
       if (pc >= 0x100) o->name = x->symnam;
       return x->symnam;
      }
  return NULL;
}

SXT* get_subr(ushort pc, ushort bank)
{
 return (SXT *) find(&subtab, pc,bank,-1);
}


SXT* add_subr (long called, ushort addr, ushort bank)
{
  SXT *x, *t;

  if (anlpass >= ANLPRT) return 0;
  if (find(&inhb,addr,bank,0))    // chk_inhb(addr, bank))
     {
      dprt ("XCODE stops add_subr, pc = %lx, from %lx\n",
        addr, called);
       return NULL;
      }

  t = get_subr(addr,bank);
  if (t)
   {
  //   dprt (" ignore duplicate subr %d|%lx\n",bank,addr);
     return t;
    }

  x = (SXT *) cmem(&subtab);
  x->pc = addr;
  x->bank = bank;
  x->addnl = NULL;
  x->size = 0;
  x->ptype = 0;
  x->cmd   = 0;
  x->scanned = 0;
  x->levels = 0;
  x->szreg = 0;
  x->adreg = 0;

  t = (SXT*) chain(&subtab,x);

  dprt( "add subr at %d:%x from %lx\n",bank, addr,called);
  
  return x;
  }


short copy_subr (SXT *tsub, SXT* ssub)
{
  // equiv to tsub attribs = ssub attrs
 CADT *tadd, *sadd;

 if (!tsub || !ssub || tsub == ssub) return 0;
 if (tsub->cmd) return 0;           // don't update if set by command

 dprt ("Copy SUBR attribs %lx to %lx\n", ssub->pc, tsub->pc);

 tadd = tsub->addnl;
 sadd = ssub->addnl;

 freecadt(tadd);           // always clear any target extensions
 tsub->addnl = NULL;
 tadd = NULL;
 if (sadd)
   {
    tsub->addnl =  add_ext(tsub);  // add first block if source subr has one
    tadd = tsub->addnl;
   }

 while (sadd)
    {
    *tadd = *sadd;         // copy block
    if (sadd->next) tadd->next = (CADT *) mem (0,0,ADSZ);
    sadd = sadd->next;
    tadd = tadd->next;
    }

 tsub->size = ssub->size;
 tsub->ptype = ssub->ptype;
 tsub->szreg = ssub->szreg;
 tsub->adreg = ssub->adreg;

 return 1;
 }


/**************************
For BAse + offset type addresses (A9L)
***************************/

long find_rbase (uchar rg)
{
  RBT *x;
  x = (RBT*) find(&rbase, rg,8,-1);
  if (x) return x->addr;
  return 0;
}


void add_dat (short idx, long called, short optype, short numops)
{
  ushort pc, bank;
  short i;        //,numops;

  // skip if prt phase or pushw instruction
  if (anlpass >= ANLPRT || PMANL ) return;

  i = (opstab[1].f.indx) ? 0 : numops-2 ;
  pc = find_rbase (opstab[i+1].xpc);   // is there an RBASE for this register ?

  if (pc)
    {	/* pc = base addr if found */
      pc += opstab[i].xpc;
      bank = opstab[i].bank;
      }
  else
    {
      pc = opstab[idx].xpc;
      bank = opstab[idx].bank;
    }

  if (!invdaddr(pc,1))    /* not register or RAM */
     {
   //   short c;
   //   c = C_WORD;
   //   if ((optype & B) || (pc & 1)) c = C_BYTE;
   //   b= add_cmd (pc, dbank(1), called, bank, pc, c, 1);  // with guess

      if ((optype & B) || (pc & 1))
         add_cmd (pc, dbank(1), called, bank, pc, C_BYTE, 0);  // with guess
      else
         add_cmd (pc,dbank(1), called, bank, pc + 1, C_WORD, 0);
      }

    upd_watch (depth,opstab[numops].xpc,pc);
}

/******************************************
attempt to decode vector or vector list from push word
****************************************/

void pushw (short ix, long called, short cbnk)
{
  OPS* opxtab;
  ushort pc, i, tpc;
  short go;

  if (anlpass >= ANLPRT || PMANL )    return;

  /* this is a pushw instruction */
  opxtab = opstab+ix;


  dprt ("pushw found at %lx\n", called);
  if (opxtab->f.imd)    // immediate - single direct address  - assume in cbank
    {
      depth++;    // these are subr calls....
      add_scan (opxtab->xpc, cbnk, called, cbnk);
      depth--;
      dprt ("pushw direct %d|%lx from %lx\n", cbnk, opxtab->xpc, called);
    }
  else
    {
      /* array of pointers - allow skip over first one */
      dprt ("push vect list ? %lx from %lx\n", opxtab->xpc, called);
      pc = opxtab->xpc;
      //bank = optab->bank;

      // assume vect iteself in data bank, but calls in current bank

      if ((opxtab->f.indr) && (opxtab->f.reg) )
        { // register pointer
          pc = get_watch(depth,opxtab->xpc);
          dprt ("R%x -> %d|%lx for vect list\n", opxtab->xpc,dbank(1),pc);
        }
      if (invdaddr(pc,1)) return;  // data address for list
	  // now try to scan down the vector list

      i = pc ;	/* vect list addr */
      go = 1;
      while (go)
        {
         tpc = g_val (i,dbank(1),2, 0);  // address pointed to from dbnk to cbnk

         if (invcaddr(tpc))      // CODE address
           {            //illegal pointer
            if (go == 1)
      	      {        // first entry might be skipped
	       dprt ("skip 1st vect entry (%lx) at %x\n",tpc,pc);
               pc+=2;
               i+=2;
               go++;
               continue;
              }
	    else  go = 0;
           }

         if (chk_free(i, dbank(1)) && go > 1 ) go = 0;   // address used for something else
         if (go)
	   {
            add_subr (i,tpc,cbnk);
            add_symn (0,tpc,cbnk,-1); // auto name
            depth++;    // these are subr calls....
            add_scan (tpc, cbnk, i, dbank(1));
            depth--;
            go++;
	   }
         else  dprt ("end vect list at %lx\n",  i);
	 i += 2;
	}
      if (i-3 > pc)  add_cmd (pc, dbank(1), called, cbnk, i-3, C_VECT,0);
    }
}

short find_fjump (ushort pc, ushort bnk)
{
  // find front jumps , for bracket sorting.
  // returns 2 for return, 1 for bracket

  JLT * j;

  if (anlpass < ANLPRT) return 0;

  j = (JLT*) find(&jpftab,pc,bnk,0);      // from

  if (j && j->f.cond && !j->f.back && !j->f.uncl)
     {
       j->f.used = 1;  	// conditional, forwards, clean.  Ok to use
       return 1;
     }

  if (j && j->f.retn) return 2;    // end of subr

  return 0;
}

void find_tjump (ushort pc, ushort bnk)
{
  // find trailing jump, for bracket sorting.
  // adds number of closing brackets

 JLT * j;
 short i;
 i = bfindix(&jpttab, pc,bnk, 0);

 while (i >=0 && i < jpttab.num)
  {
   j = (JLT*) jpttab.ptrs[i];
   if (pc == j->to && bnk == j->tbank)
   {
     if (j->f.used) pstr (" }");
     i++;
   }
   else i = -1;
  }
}

/*
  // nice idea, but STILL doesn't reliably work.....
void fix_subjmp(JLT *j, LBK *blk, short *cnt)
{
  // test jumps to subrs  - this logic seems to work.....
  SXT *s, *t;
  if (!j) return;
  if (j->f.cond) return;    //  !j->f.back && j->f.stat)
  // must be forwards ? and static

  t = get_subr(j->from, j->fbank);

  if (depth > 0 && t && j->from == blk->start && j->fbank == blk->bank)
    {
      s = get_subr(j->to, j->tbank);
      if (!s) do_subr(blk,j->from,j->tbank, j->to,cnt);
      if (!s) return;

     dprt ("POSSIBLE JUMP subr To SUBR\n");
   //  if (!t->size && !t->ptype) return;
     if (!s->size && !s->ptype) return;  // nothing to copy
     copy_subr(t, s);
    }
    return ;
}
  */

/*
void fix_subrjumps (LBK *blk, JLT* j)
{
  // see if there is a static jump to a subroutine from this scan block (A9L has these)
  // and if so copy any aditional params
  // Answers 0 - not found 1- found

  SXT  *tsub, *fsub;
  short tflg, fflg;

  if (anlpass > 3) return ;
   if (!j)  return;

  tsub = get_subr(j->to, j->tbank);       // target subr (jumps TO here)
  if (tsub)
    {

         tflg =0;
         if (tsub && tsub->size) tflg++;
         if (tsub && tsub->ptype) tflg++;

         fsub = get_subr(j->from,j->fbank);     // source subr  (jump FROM here)
         fflg =0;
         if (fsub && fsub->size) fflg++;
         if (fsub && fsub->ptype) fflg++;

         if (fsub && tflg)
              {
              dprt("JUMP from SUBR start %lx to SUBR START %lx \n",j->from, j->to);
              copy_subr(fsub, tsub);
              }
   }
    /*     if (!fsub && tflg)
              {
                 dprt("JUMP from NOT SUBR start %lx to SUBR START %lx \n",
                  j->from, j->to);
              }
         if (fflg && !tsub)
              {
                 dprt("JUMP from SUBR start %lx to NOT SUBR START %lx \n",j->from, j->to);
              }   



}
  */


JLT *add_jump (long from, short fbank, short cnt, long to, short tbank, ulong opt)
{
  JLT *j;


   if (anlpass >= ANLPRT) return NULL;

   if (iaddr(from, fbank))
    {
      dprt ("ignore invalid jump from %d|%lx\n", fbank, from);
      return NULL;
    }
   if (iaddr(to, tbank))
    {
      dprt ("ignore invalid jump to %d|%lx", tbank, to);
      return NULL;
    }

     j = (JLT *) cmem(&jpftab);
     j->from  = from;
     j->fbank = fbank;
     j->to    = to;
     j->tbank = tbank;
     j->flags = 0;
     j->f.cnt   = cnt;

     if (tbank < fbank) j->f.back = 1;
     if (tbank == fbank && from >= to) j->f.back = 1;        // mark backwards jump

     dprt ( "add ");
     if (j->f.back) dprt ( " (backw) ");
       if (opt & X)
        {
         j->f.subr = 1;
         dprt ( "Subr Call");
        }
     else
     if (opt & E)
        {
         if (opt & J)
           {
             dprt ("Static Jump");
           }
         else
           {
            j->f.reti = 1;          // not for dummy procs !!
            dprt ("Return Jump");
           }
        }
     else
        {
         j->f.cond = 1;
         dprt ("Cond Jump");
        }

    dprt (" depth %d from %d|%lx to %d|%lx\n", depth, j->fbank,j->from, j->tbank,j->to);

 // chain it in to BOTH tables, but jpttab is remote type, reuse J

  if (!chain(&jpftab,j)) chain(&jpttab,j);

  return j;

}


JLT* find_cjump (ushort pc, ushort bnk)
{
  JLT *j;

  if (anlpass >= ANLPRT) return 0;
  j = (JLT*) find(&jpftab,pc,bnk,0);
  if (j && j->f.cond && j->to == pc) return j;
  return 0;
}



void p_pad(short c)
{
// pad to required column number, add newline if no string

short i;

pstr(" ");     // always add 1 space...
for (i = gcol; i < c; i++) pstr (" ");
}

// print 'header' for each line (for 'cnt' bytes)
// ofst     offset to data value(s) to print
// cnt      no of bytes to print
// com      command title
// pad      optional 'pad to' value

void pp_hdrp (long ofst, char *com, short cnt, short pad)
{
 char *tt;
 ushort bank, pc;
 if (!cnt) return;
 if (PDBGM || anlpass >= ANLPRT)        // dbg
    {
    pc = pcof(ofst,&bank);
    if (gcol) rprt(0);
    tt = get_sym_name(&symtab,pc, bank, -1);       /* is there a symbol here ? */
    if (tt) rprt ("\n   %s:", tt);
    if (numbanks > 1) pstr ("%1d ", bank);
    pstr ("%4x: ", pc);

    }

  while (--cnt) pstr ("%02x,", get_byte (ofst++));
  pstr ("%02x", get_byte (ofst++));
  p_pad(pad ? pad : INSTART);
  pstr ("%s",com);
  p_pad(MNSTART);
}

void pp_hdr (long ofst, char *com, short cnt)
 {
  pp_hdrp (ofst, com, cnt, 0);
 }

/*************************************
get next comment line from file
**************************************/

bool getcmnt (ushort *pc, ushort *bank, char **cmnt)
{
  short ans;

  ans = 0;
  *cmnt = flbuf;

  if (fcmt == NULL || feof(fcmt))
   {
    *pc = 0xffff;
    **cmnt = '\0';
    return false;   // no file, nothing to do
   }

  while (ans < 1 && fgets (flbuf, TXTSZE, fcmt))
    {
     ans = sscanf (flbuf, "%hx %hx ", pc, bank);
    }

  switch (ans)
    {
     case 1:
       *bank = 8;  // drop through
     case 2:
       while (spchar(*cmnt) < 2) (*cmnt)++;    // skip numbers
       return true;
     default:
       **cmnt = '\0';
    }
 return false;
}

/* incorrectly stacked comments cause filled spaces (cos of print...) */

void pp_comment (long ofst)
{
  char *x, *c;
  long num;
  short bit,pbnk,type,i;
  ushort pc,bank;

  if (anlpass < ANLPRT) return;
  if (ofst < 0) ofst = 0;           // safety
  pc = pcof(ofst,&bank);        // get pc and bank

  while (cmntpc <= pc && cmbank <= bank)
    {
     c = cmtt;
     if (!c) break;        // safety
     if (spchar(c) != 5 ) p_pad(CDOSTART);      // '|' = newline
     while (*c)
      {
       type = spchar(c);
       switch(type)
        {
         case 6:    // '@' with padding, drop through
         case 7:    // '$' no padding
          num = 0;
          bit = -1;
          pbnk = 8;
          if (sscanf(++c,"%lx:%hx_%hx",&num,&bit,&pbnk))    // e.g. 321:4_8
           {
            nm[0] = '\0';
            while (isxdigit(*c) || *c == ':' || *c == '_' ) c++;
            c--;
            x = get_sym_name (&symtab,num, pbnk, bit);
            if (x) sprintf(nm, x);

            if (type == 6)
             {
              i = 0;
              while (i < TXTSZE && nm[i]) i++;
              while (i < 21) nm[i++] = ' ';
              nm[22] = '\0';
             }
            pstr(nm);
            }
          break;

	 case 5:
           rprt(0);
           break;
         case 8:            // ignore it
           break;
         default:
           pstr("%c",*c);
           break;
        }
       c++;
      }

    if (!getcmnt(&cmntpc, &cmbank, &cmtt)) break;
    }
 }



// print indent line for extra psuedo code lines


void p_indl (void)
{
  if (gcol) rprt(0);
  p_pad(OPSSTART);

}

 /******* calc jumps and calls *******************
  * destination is relative to current pc and
  * can be +ve or -ve offset. extract to 'ofst'
  * and sign extend according to length
  * eg. 'ofst |= ~0x3ff;'  if mask 0x400 and equiv
  ************************************************/

short jumpd (ushort ofst, ushort mask, ushort pc, short cnt)
{
  if (ofst & mask) ofst |= ~(mask - 1);   // negate
  ofst += pc + cnt;
  return ofst;
}

long decode_addr(CADT *a, long ofst)
  {
  ushort rb,off,pc, d;
  long val;
  pc = 0;
  d = 0;

  val = g_val (ofst, a->f.esize, a->f.sign);
  rb  = val;
 // off = val & 0xfff;

  if (a->f.foff)
    {
     // foff fixed offset (as address)
     val+=a->divisor;
     val &= 0xFFFF;        // for addresses
     return val;
    }


  switch (a->f.enc)
     {
      case 1:    // A9L types, only if top bit set
      case 3:
        if (! (rb & 0x8000)) break;
        off = val & 0xfff;
        d = 1;
        rb >>= 12;     // top nibble
        if (a->f.enc == 3) rb &= 7;
        rb *=2;
        pc = find_rbase(a->divisor+rb);
        break;

   /*   case 3:   // A9L type, only if top bit set

        if (! (rb & 0x8000)) break;
        d = 1;
        rb >>= 12;     // top nibble
        rb &= 7;
        rb *=2;
        pc = find_rbase(a->divisor+rb);
        break; */

      case 2:       // func lookup type (EARS etc)
        d = 1;
        off = val & 0xfff;
        rb >>= 12;     // top nibble
        rb &= 0xf;
        pc = find_rbase(a->divisor+rb);
        break;

      case 4:
        d = 1;
        off = val & 0x1fff;
        rb >>= 12;     // top nibble
        rb &= 0xe;
        pc = find_rbase(a->divisor+rb);
        break;







      default:
        break;
     }


  if (pc)
   {
    val = off + pc;        // reset op
    val &= 0xFFFF;
  }
  else if (d)  dprt("No rbase for address decode! %x (at %lx)\n", a->divisor+rb, ofst);

  return val;

}


CADT *pp_lev (long ofst, void *z, short pad, short size)
{
 short i,lev,tot;
 int pfw;
 long val, end;
 ushort bank;
 float fval;
 SYT* sym;
 CADT *a;

 a = (CADT*) z;
 tot = 0;
 end = ofst + 64;      /* safety stop 64 bytes */

 lev = 0;
 while (a && lev < MAXLEVS) {

   for (i = 0; i < a->f.cnt; i++)      // count within each level
     {
     if (i) pstr(",");
     sym = NULL;
     pfw = 1;                               // min field width
     if (ofst > end) break;                  // safety - force exit
     if (pad)
       {
        pfw = a->f.pfw;
        if (a->f.dp)   pfw+=3;                     // 3 extra for ".00"
        if (a->f.sign) pfw ++;
       }

     val = pcof(ofst, &bank);                  // just to get bank out
     val = decode_addr(a, ofst);               // val with decode if nec.

     if (a->f.name) sym = get_sym(&symtab,val,bank,-1);    // syname AFTER any decodes


     if (sym) pstr("%s",sym->symnam);
     else
     if (a->f.hex) pstr("%*x", pfw, val);
     else
       {
       if (a->f.dp)
         {
          char *tx;
          int cs;
          val *=100;           // divisor is *100 = 2 dps
          fval = (float) val/a->divisor;
          cs = sprintf(nm,"%*.2f", pfw, fval);
          tx = nm+cs-1;
          while (*tx == '0') *tx-- = ' ';
          if (*tx == '.') *tx = ' ';
          pstr("%s", nm);
         }
       else pstr("%*d", pfw, val);
       }

      ofst += a->f.esize;
      tot  += a->f.esize;
     }
   lev++;
   a = a->next;
   if (a) pstr(",");
   if (size && tot >= size) return a;
  }
return 0;

}

//*********************************

ushort pp_text (long *ofs, LBK *x)
{
  ushort cnt, i, v;
  long xofst, ofst;
  ofst = (*ofs);
  pp_comment (ofst-1);

  xofst = ofpc(x->end,x->bank);
  cnt = xofst-ofst+1;

  if (cnt > 32) cnt = 32;
  if (cnt < 1)  cnt = 1;

  pp_hdr (ofst, dirs[x->fcom].com, cnt);

  xofst = ofst;
  pstr("\n\"");
  for (i = cnt; i > 0; i--)
     {
      v = g_val (xofst++, 1, 0);
      if isalnum(v) pstr ("%c",v ); else  pstr(".");
     }
  pstr("\"");
  pp_comment (ofst);
  *ofs = xofst;
  return cnt;
}

//***********************************

ushort pp_data (long *ofs, LBK *x)
{
  ushort size;
  long ofst;
  ofst = *ofs;
  size = x->fcom == C_BYTE ? 1 : 2;
  pp_comment (ofst-1);
  pp_hdr (ofst, dirs[x->fcom].com, size);
  pp_lev(ofst,x->addnl,1,0);
  pp_comment (ofst);
  (*ofs) += size;
  return size;
}

//***********************************

ushort pp_vect(long *ofs, LBK *x)
{
  long val, ofst;
  ushort bank;
  char *n;
  CADT *a;

  ofst = *ofs;
  a = (CADT*) x->addnl;
  bank = x->bank;

  if (ofst & 1)
      {
      pp_hdr (ofst, dirs[C_BYTE].com, 1);
      (*ofs) +=1;
      return 1;
      }

  pp_hdr (ofst, dirs[x->fcom].com, 2);
  val = g_val (ofst, 2, 0);

  pstr ("%lx,", val);

  if (a && a->f.foff &&  findbank(a->divisor) >= 0 ) bank = a->divisor;

  n = get_sym_name (&symtab,val, bank, -1);   // bank may be diff to vect bank
  if (n)
     {
     p_pad(OPSSTART);
     pstr ("%s", n);
     }
  (*ofs) +=2;
  return 2;
}

//  print a line as default

ushort pp_dft (long *ofs, LBK *x)
{
  long i, cnt;       // for big blocks of fill.....
  long xofst, ofst;
  ofst = *ofs;
  pp_comment (ofst-1);

  xofst = ofpc(x->end,x->bank);
  cnt = xofst-ofst+1;
  for (i = 0; i < cnt; ++i)
    {
      if (get_byte (i+ofst) != 0xff)	break;
    }


  if (i > 32)   // more than 2 rows of fill
     {
      ushort pc, bank;
      pc = pcof(ofst, &bank);
      pstr("\n\n #### fill (=0xff) from %lx to %lx  ####\n\n", pc,pc+i-1 );
      (*ofs) += i;
      return i;
    }

  if (cnt <= 0 ) cnt = 1;
  if (cnt > 16) cnt = 16;    // fill up to 16
  // if (ofst & 1)   cnt = cnt-1;
  xofst = obend(x->bank);
  if (ofst + cnt > xofst)
    cnt = xofst- ofst +1;


  if (i >= cnt)
     {
      pp_hdr (ofst, "fill", cnt);
      (*ofs) += cnt;
      return cnt;
    }				/* end of filler check */

  if (cnt > 8) cnt = 8;        // data upto 8
  pp_hdr (ofst, "??", cnt);

  xofst = ofst;
  for (i = cnt; i > 1; i--)
     {
      pstr ("%3d,", get_byte (xofst));
      xofst++;
     }
   pstr ("%3d", get_byte (xofst));
   //gnxt--;
   pstr(" ");

   xofst = ofst;
   for (i = cnt; i > 0; i--)
     {
      if (!(xofst & 1) && cnt > 1)
        { // not an odd address, and more than one byte
         pstr ("%6d,",g_val (xofst, 2, 1));
        }
      xofst++;
    }

  pp_comment (ofst);
  (*ofs) += cnt;
  return cnt;
}

// this work for actual structure - need to sort up/down etc

ushort pp_timer(long *ofs, LBK *x)
{
  long val, xofst,ofst;
  SYT *sym;
  short cnt, bit, i;
  CADT *a;

  a = add_ext(x);        // just in case
  xofst = *ofs;
  ofst = xofst;

  pp_comment (ofst-1);

  val = g_val (xofst++, 1, 0);  // first byte
  if (!val)
    {
      pp_hdr (ofst,dirs[C_BYTE].com,1);    // end of list
      pp_comment (ofst);
      (*ofs)++;
      return 1;
     }

  cnt = (val & 1) ? 3 : 1;     // long or short entry
  pp_hdr (ofst, dirs[C_STCT].com, cnt+a->f.esize);
  pstr("%2x, ", val);
  val = g_val (xofst, a->f.esize, 0);
  xofst+= a->f.esize;
  sym = get_sym(&symtab,val,x->bank,-1);    // syname AFTER any decodes
  if (sym) pstr("%s, ",sym->symnam);
  else pstr("%4x, ",val);

  if (cnt == 3)
   {                // long entry
    i = g_val (xofst++, 1, 0);
    bit = 0;
    while (!(i&1)) {i /= 2; bit++;}
    val = g_val (xofst++, 1, 0);
    sym = get_sym(&symtab,val,x->bank,bit);
    if (sym) pstr("%s, ",sym->symnam);
    else  pstr(" B%d_%x",bit, val);
   }

  pp_comment (ofst);
  (*ofs) += cnt;
  (*ofs) += a->f.esize;
  return cnt+a->f.esize;
}

//  print a line as default
// print struct, tab or func



ushort pp_stct (long *ofs, LBK *x)
{
 long ofst;
 short size, indent;
 CADT *a;

 indent = x->size1*3+7;
 if (x->size2 > x->size1) indent = x->size2*3+8;

 size = x->size1;
 ofst = *ofs;
 pp_comment (ofst-1);
 pp_hdrp (ofst, dirs[x->fcom].com, size,indent);
 a = pp_lev(ofst,x->addnl,1, size);
 pp_comment (ofst);
 ofst += size;
 (*ofs) = ofst;

 size = x->size2;
 if (size) {

 pp_comment (ofst-1);
 pp_hdrp (ofst, dirs[x->fcom].com, size, indent);
 pp_lev(ofst,a,1, size);
 pp_comment (ofst);
 ofst += size;
 }

 if (x->term && ofst == x->end - PCORG)     // terminator byte(s)
  {
   pp_comment (ofst-1);
   pp_hdrp (ofst, "byte", x->term, indent);
   pstr("##  terminator");
   pp_comment (ofst);
   ofst += x->term;
  }


 (*ofs) = ofst;
  return x->size1+x->size2;
}


void p_op (short ix, short name, short prt)
{

/* base must be set zero for registers and jumps */
/* prt inhibits name print if not true */

 OPS *op;

 op = opstab+ix;
  if (name && op->name && prt) pstr (op->name);
  else
    {
     if (op->xpc && op->f.reg) pstr ("R%x", op->xpc);       // reg
     else
     if (op->f.bit)
        {
         pstr ("B%d", op->xpc);       // bit (follwed by word/byte)
         if (name) pstr("_");
        }
     else
      {
       if (!PHEX && name && !op->f.indr && !op->f.hex) pstr ("%u", op->xpc);
       else pstr ("%x", (op->f.byte) ? op->xpc & 0xFF : op->xpc & 0xFFFF);
      }
    }
  if (op->f.autoinc)  pstr ("++");                                   // autoinc

}


short p_oper (short ix, short name)
{
  OPS *j, *op;

  op = opstab+(ix & 0xf);
  if (op->f.ign && name) return 1;
  if (op->f.indr)  pstr ("[");

  if (op->f.indx)
    {
      if (op->xpc)
	{
          p_op (ix,name, 1);
          j = op-1;
          if (j->xpc)
            {
            pstr ("+");
	    p_op (ix-1, name, 0);
            }
	}
      else
	p_op (ix-1,name, 1);
    }
  else p_op (ix, name,1);
  if (op->f.indr) pstr ("]");
  return 0;
}



// print subroutine params

short pp_subpars (ushort pc, ushort bank, long ofst, short cnt)
{
  SXT  *xsub;
  CADT *add;
  LBK  *sblk;
  short size;

  add = NULL;

  xsub = (SXT*) find(&subtab,pc,bank,-1);

  if (xsub)
   {
    add = xsub->addnl;
    size = xsub->size;
   }

  sblk = (LBK *) find(&cmdch,ofst,bank,C_ARGS);
  if (sblk)
     {
     add = (CADT*) sblk->addnl;      // command overrides proc settings
     size = sblk->size1;
     }

  if (!add)
     {                 // no additional params
       pstr("();");
       return 0;
     }
     // so 'addnl' must be set from here

     pstr("(");
     if (size)
       {
        pp_lev(ofst+cnt,add,0,0);     // do params at min width, drop trail comma */
       }
     pstr(");");
     if (size)
       {
        pp_comment (ofst);             // do any comment after main subr call
        pp_hdr (ofst+cnt, "#args ", size);  /* do params as sep line */
        pp_comment (ofst+cnt);         // and for data pars too
       }
return size;
}


// sort out pointers and values for indirect addressing via rbase

short check_rbptr(short numops, OPC *ope)
{
  OPS *a, *b;
  long xpc;
  short inx;
  if (numops < 1) return 0;

  inx = (opstab[1].f.indx) ? 0 : numops-2;
  a = opstab + inx;
  b = a + 1;

  inx = 0;
  xpc = find_rbase (b->xpc);
  if (xpc)
   {     // rbase found
    if (a->f.imd)   // immediate
     {
      a->xpc += xpc;
      op_vnam (a->xpc, a->bank, a, 0);
      a->f.reg = 0;
      a->f.hex = 1;
      b->xpc = 0;
      b->name = 0;
      b->flags = 0;
      if (ope) inx = ope->rpx;
     }

    if (b->f.indx)   // indexed
     {
      b->xpc = xpc + a->xpc;
      if (op_vnam (b->xpc, b->bank, b, 0)) b->f.indr = 0;
      b->f.indx = 0;
      b->f.reg = 0;
      a->xpc = 0;
      a->name = 0;
      a->flags = 0;
     }
   }
  else
   {        // rbase NOT found
    if (b->f.indx && !b->xpc)   // indexed, not zero
     {
      *b = *a; ;  // move operand
      a->xpc = 0;
      a->name = 0;
      a->flags = 0;
      if (b->name)
       {
        b->f.indr = 0;
        b->f.indx = 0; // clear pointer if named
       }
     }
   }

return inx;

}

short get_bitsyms (ushort pc, ushort bank, short byte)
 {

 // for mask bit conversion to multiple sym names
 // ans no of syms found for given address and mask
 // this search assumes syms are in strictly correct order, bits then -1 (0->7)
  // size = 1 for word values, 0 otherwise

   short i, ix,hsym,size;
   SYT *xsym;

   if (pc < PCORG) bank = 8;   // temp fiddle for RAM, KAM regs

   size = (byte) ? 0 : 1;

   hsym = -1;  // highest bit number found
   for (i = 0; i < 16; i++) snam[i] = -1;   // clear names

   ix= bfindix(&symtab, pc, bank, -1);    // 'base' entry
   if (ix >=symtab.num) return 0;

   // now at first xsym which matches pc (probably whole sym)

   while (1)
     {
      xsym = (SYT *) symtab.ptrs[ix];    // could be NULL
      if (!xsym) break;
      if (xsym->pc > pc+size) break;
      i = xsym->f.bitno;
      if (i >= 0)
       {
        if (xsym->pc > pc) i += 8;   // for word (2nd byte)
        snam[i] = ix;                // index xsym->symnam;
        if (i > hsym)  hsym =  i;   // keep highest bitno
       }
      ix++; 
     }
  return hsym;
}

char *check_bitwise(OPC *ope, char *tx)

/* check for bitwise operations - not for 3 operand instructions or where no symname ?*/
{

  short lg, i, k, size;
  ushort mask;
  char eq;
  SYT *xsym;

  if ( (ope->numops & 0xf) > 2)  return tx;     // not 3 op instructions
  if (!opstab[1].f.imd)  return tx;    // only allow immediate vals  CLRB ?

  lg = -1;
  if (ope->opt & A) lg = 0;
  if (ope->opt & O) lg = 1;


  if (lg < 0) return tx;

  *nm = 0;
  size = (ope->opt & B) ? 8 : 16;
  mask = opstab[1].xpc;


  if (get_bitsyms (opstab[2].xpc, cbank(), ope->opt & B) < 0) return tx;        // no bit names found

  // names are in bit order (1 << offset);


  k = 0;		                    // first output flag
  opstab[1].f.hex = 1;
  eq = (ope->opt & X) ? '^' : '=' ;    // xor or standard
  if (ope->opt & A) mask = ~mask;

  for (i = 0; i < size;  i++)
   {
    if (lg == 2 || (mask & 1))
      {
       if (k++)  p_indl ();    // new line and indent if not first
       if (snam[i] >= 0)
          {
           xsym = (SYT *) symtab.ptrs[snam[i]];
           pstr (xsym->symnam);  // name match
           xsym->f.prtd = 1;
          }
       else
         {
          pstr ("B%d_", i);         //no name match
          p_oper (2,1);
         }
       pstr (" %c %d;",eq, lg);
      }
    mask  = mask >> 1;
   }
  return nm;          // at least one name substituted  so return a ptr to null
 }



char *check_shiftr(short ix, OPC *ope)
 {
  /*  do shift replace here - must be arith shift and not register */
  short i,j;
  char *s;
  OPC *opr;
  OPS *ops;

  ops = opstab+ix;
  s = ope->sce;

  if (ope->opt & S && ops->f.imd)
   {
    i = opcind[ope->rpx];	/* find mult or div */
    if (i && ope->rpx)
      {
       opr = opctbl + i;
       s = opr->sce;	        /* replace sce */
       j = ops->xpc;
       ops->xpc = 1 << j;	/* correct math op */
      }
   }
  return s;
}

void chk_sshift(ushort pc, short indx, OPS *ops, LBK *blk)
 {                       // check stack shift procs for params
  short i;



 // NEED TO REWORK THIS this for 8065 with R20 used e.g.
 // 2f93: a3,20,02,36       ldw   R36,[R20+2]    R36 = [STACK+2];
 // 2f97: a3,20,04,3a       ldw   R3a,[R20+4]    R3a = [STACK+4];
 // as well as POP and push for 8061





  if (anlpass >= ANLPRT) return;

  if (indx == 62 )
    {
    // this is a Pushw instruction
    dprt("PUSHW R%x = %lx at %d|%lx\n", ops->xpc, get_watch(depth,ops->xpc),blk->bank, pc);
    i = get_watch(depth,rpopped[depth]);
    if (i > 0 && rpopped[depth] ==  ops->xpc && i < 64)   // numops
      {
       SXT *sub;
       CADT *adnl;
       dprt( "PROC at %d|%lx probably has +%d args\n", blk->bank, blk->start, i);
       sub = get_subr(blk->start, blk->bank);
       if (sub && !sub->addnl && !sub->ptype && !sub->cmd)
         {
          sub->addnl = (CADT *) mem (0,0,ADSZ);
          adnl = sub->addnl;
          adnl->divisor  = 0;
          adnl->next     = NULL;
          adnl->flags    = 0x402;     // cnt =1 and esize = 1 rest = 0  zflgs(adnl);
          adnl->f.cnt   = i;
          sub->cmd = 0;              // guess = 1;
          adnl->f.hex = PHEX;
          sub->size = i;
          dprt("ADDED to PROC at %lx\n",blk->start);
         }
      }
    stklev[depth]++;
    }

  if (indx == 63)
    {
      // this is a POPW instruction
     dprt("POPW to R%x at %lx\n", ops->xpc, pc);
     upd_watch(depth,ops->xpc, 0);
     if (ops->xpc > 0 && ops->xpc < 256)
       {
        rpopped[depth] = ops->xpc;
        stklev[depth]--;                       // ignore for throwaway pops
       }
     if (stklev[depth] < 0) dprt("POPW BEFORE PUSHW at %lx\n", pc);
    }
 }


void saveops(void)
{
 short i;
 depth++;
 for (i =0; i < 8; i++) savop[jdepth][i] = opstab[i];
 jdepth++;
}

void restops(void)
{
 short i;
 depth--;
 jdepth--;
 for (i =0; i < 8; i++) opstab[i] = savop[jdepth][i];
}


ushort pp_code (long *ofs, LBK *blk)
{
/* analyse next code statement from ofst and print operands  */
// need curbank and nextbank here for calls...

  long ofst;       //, jofst;
  short j, prt, cnt, ans, indx, numops;
  ushort opcsub, autolng, wdflg, i;
  ushort pc, bank;
  char  *tx ;
  OPC *opl;
 // JLT *jp;

  ofst = *ofs;
 // jofst = 0;
  pp_comment (ofst-1);
  pc = pcof(ofst,&bank);

  codbank = bank;  // default is current code bank

  if (bank != blk->bank) dprt("----BANK MISMATcH ----");

  if (chk_data (ofst))
     { // assume this is a data block and so is a faulty reference
     add_endblk (blk, pc, 0);
     wprt ("Scanned address is probably data, at %d|%lx\n", bank,pc);
     return 0;
     }

  if (invcaddr(pc))
    {
     add_endblk (blk, pc, 0);
     wprt ("Invalid address (scan) at %d|%lx\n", bank,pc);
     return 0;
    }

  prt = (anlpass >= ANLPRT) ? 1 : 0;
  prt += PLCOD;   /* print if reqd */

   /***************************************************************
  * one instruction at a time.
  * this is code/stament analysis first, then print is later
  * was separate proc, but now merged so can recursively track subr calls....
  ***************************************************************/

  i = get_byte (ofst);
  indx = opcind[i];
  cnt = 1;

  if (indx == 93)
     {  // this is the prefix code, get alt opcode is exists
      i = get_byte (++ofst);
      indx = opcind[i];
      opl = opctbl + indx;
      indx = opl->ppx;     // prefix link
      cnt++ ;
     }

  opl = opctbl + indx;
  numops = opl->numops & 0xf;
  cnt += numops;

  if ((opl->opt & H) && !P8065) indx = 0;

  if (!indx && anlpass < ANLPRT)
     {                                 // invalid opcode
      cnt = 1;                         // skip this byte
      add_endblk (blk, pc, 1);	       // end block WAS 0
  //    blk->err = 1;                    // mark for rescan later
      if (prt) pp_hdr (ofst, opctbl->name, cnt);
      wprt ("Invalid opcode (%x) at %d|%lx\n", i, cbank(),pc);
      return 0;
     }


  wdflg = opl->opt & B ? 0 : 1;	        // word op if wdflag set
  opcsub = i & 3;	                // direct,indexed subtypes


    /********************************************
    * adjust num of bytes for opcodes 'M'
    * opcsub 3 - +1 byte if long index flag set
    * Word op - opcsub 1 and 3 - +1 byte
    * Byte op - opcsub 3 - +1 byte
    ******************************************************/

  if (opl->opt & M)
    {
      autolng = get_byte (ofst + 1) & 1;	        // M - auto inc, long index
      if (opcsub == 1 && wdflg)  cnt += 1;
      if (opcsub == 3)           cnt += autolng + 1;
    }

  if (anlpass < ANLPRT)  set_opxstart (ofst);		// Mark start of each opcode
  if (prt)                                              // ignore if user code cmd
     {
      long xofst;
      if (!get_opxstart (ofst))
         dprt ("Opcode not set at %lx\n", ofst);

      for (xofst = ofst + 1; xofst < ofst + cnt; xofst++)
      if (get_opxstart (xofst))
          dprt ("Opcode set for %lx (%lx)\n", xofst, ofst);
     }

  for (i = 0; i < 4; i++)
    {
      opstab[i].xpc = 0;
      opstab[i].name = 0;
      opstab[i].bank = cbank();
      opstab[i].flags = 0;

    }
  j = (opl->numops >> 4)& 0xf;   // write op index
  if (j) opstab[j].f.wrt = 1;      // set flag

  for (i = numops; i > 0; i--)      // do this later ??
    {
      opstab[i].f.reg = 1;
      op_vnam (get_byte (ofst + i), cbank(), opstab+i, 0);
    }



   /* now analyse operands */

    /****** shifts (2 op) *********************
    * immediate if < 16 or 31 if DW or from register otherwise
    * NB can be 31 for longs !!
    *******************************************/
  if (opl->opt & S)
    {
      i = get_byte (ofst + 1);
      opcsub = (opl->opt & X) ? 32 : 16;

      if (i < opcsub)
	{
	  opstab[1].f.imd = 1;
          opstab[1].f.reg = 0;
	  opstab[1].name = 0;
	}
    }

  else if (opl->opt & R)
      {
      // bank swoppers
      if (opl->opt & B) i = get_byte(ofst+1);
      else i =  indx - 95;
      opstab[1].f.bnk = 1;    // mark new bank for next instruction
      opstab[1].f.imd = 1;
      opstab[1].f.reg = 0;    // mark as immediate
    }

    /******* jumps and calls ******************/
    // not sure which jumps honour bnk commands, but subr symbols should..
  else if (opl->opt & J)
    {
      switch (opl->opt & (B|C|T|D|K))
	{
	case B:     //short
	  i = jumpd (((get_byte (ofst) & 7) << 8) + get_byte (ofst + 1), 0x400, pc, 2);
	  break;
	case K:     // skip, = pc+2 forwards
	  i = jumpd (0,0,pc,2);
	  numops++;
	  break;
	case C:   //short, conditional
	  i = jumpd (get_byte (ofst + 1), 0x80, pc, 2);
	  break;
	case D:    //  djnz
	  op_vnam (get_byte (ofst + 1), cbank(), opstab+2, 0);
	  i = jumpd (get_byte (ofst + 2), 0x80, pc, 3);
	  break;
	case T:   // bit conditional jump JB, JNB
	  opstab[3].xpc = get_byte (ofst) & 7;
	  opstab[3].f.bit = 1;
          opstab[3].f.reg = 0;
	  numops++;
	  op_vnam (get_byte (ofst + 1), cbank(), opstab+2, opstab+3);
	  i = jumpd (get_byte (ofst + 2), 0x80, pc, 3);
	  break;
	default:                   // long
	  i = jumpd (g_val (ofst + 1, 2, 0), 0x8000, pc, 3);
	  numops--;
          break;
	}
      opstab[1].flags = 0;
      opstab[1].f.imd = 1;
      op_vnam (i, cbank(), opstab+1, NULL);
      opstab[1].f.hex = 1;                  /* print adresses in hex */

      //jp =
      add_jump (pc, bank, cnt, opstab[1].xpc, cbank(), opl->opt);  // keep jumps AND calls

      if (opl->opt & X)
         {                              // this is a subroutine call
          opstab[2].xpc = 0;             // to stop odd values if JLT/JLE etc
          do_subr(blk,pc,cbank(),opstab[1].xpc,&cnt);
         }
      else
        {                               // This is a jump (but could be a sneaky subr call)
         if (anlpass < ANLPRT && depth > 0 && (opl->opt & E) )
          {
           saveops();            // save opcodes for this level
           dprt ("SUBX Code scan from %d:%lx, depth %d %d\n", cbank(),opstab[1].xpc, depth, jdepth);
           scan_blk(blk,opstab[1].xpc, cbank());   //fix_subjmp(jp,blk,&cnt);
           dprt("SUBX END Scan\n");
           restops();
          }
         add_endblk(blk, pc+cnt-1,0);
         add_scan (opstab[1].xpc, cbank(), pc, bank); // add scan for new address
         add_symn (1, opstab[1].xpc, cbank(), -1);
        }

    }

  else if (opl->opt & M)
    {
    /******************* instructions M *****************
    * multiple address multiple op opcodes
    * opcsub values   0 direct  1 immediate  2 indirect  3 indexed
    * order of ops    3 ops       2 ops      1 op
    *                 dest reg    dest reg   sce reg
    *                 sce  reg    sce  reg
    *                 sce2 reg
    * NB looks like indexed mode has SIGNED offset
    *****************************************************/
      switch (opcsub)
	{
	case 1:
	  opstab[1].f.imd = 1;
          opstab[1].f.reg = 0;

	  /* AND and OR - par to be split is always [1] name is [2]*/
     //	  if (opl->opt & O)  opstab[2].f.or = 1;
      //    if (opl->opt & A)  opstab[2].f.and = 1;

          opstab[1].name = 0;  //can't always do this

	  if (wdflg)
	    {
	      i = g_val (ofst + 1, 2, 0);
	      op_vnam (i, dbank(1), opstab+1, 0);

	    for (i = numops; i > 1; i--)
		op_vnam (get_byte (ofst + i + wdflg), dbank(1), opstab+i, 0);
	    }

          if (opl->opt & P) pushw (1, pc, cbank());
          else add_dat (1, pc, opl->opt,numops);

	  break;

	case 2:
	  opstab[1].f.indr = 1;
	  op_vnam (get_byte (ofst + 1) & 0xFE, dbank(1), opstab+1, 0);	/* drop autoinc flag */
	  if (autolng)
	    {
	      opstab[1].f.autoinc = 1;
              inc_watch(opstab[1].xpc,wdflg, pc);
	    }

	  if (opl->opt & P) pushw (1, pc, cbank());
          else add_dat (1, pc, opl->opt,numops);
	  break;

	case 3:
	  for (i = numops; i > 1; i--)
	    op_vnam (get_byte (ofst + i + autolng + 1), dbank(1), opstab+i, 0);
	  opstab[1].f.indx = 1;
          opstab[1].f.indr = 1;
	  op_vnam (get_byte (ofst + 1) & 0xFE, dbank(1), opstab+1, 0);	/* drop long ix flag */

          if (autolng)
	    i = g_val (ofst + 2,2,1);    // indexes are signed
          else
            {i = g_val(ofst + 2,1,1);    // short indexes
            opstab[0].f.byte = 1;
            }
          opstab[0].f.indx = 1;
          opstab[0].f.indr = 1;
          opstab[0].f.hex  = 1;   // mark zero as indexed too */
          op_vnam (i, dbank(1), opstab, 0);
          j = opstab[0].xpc ? 0 : 1 ;

	  if (opl->opt & P) pushw (j, pc, cbank());
          else  add_dat (j, pc, opl->opt,numops);
	  break;

	default:
          upd_watch(depth,opstab[2].xpc, opstab[1].xpc);
          //if (opl->opt & C) updr_watch(opstab, pc, opl);  // register tfr ??

          break;
	}


    }

  if (anlpass < ANLPRT && P8065 && indx == 56 && opstab[2].xpc == 0x11)
    {  // Bank swop via LDB , BANK_SELECT
      if (opcsub == 1)  datbank = opstab[1].xpc & 0xf;  // if immediate
      else datbank = blk->bank;   // assume current bank for any register
      dprt("DATA BANK = %d\n", datbank);
    }

  chk_sshift(pc, indx, opstab+numops,blk);

  ans = cnt;
  if (anlpass < ANLPRT && opl->opt & E)
    {
     if (!(opl->opt & J)) add_jump (pc, cbank(), cnt, pc, blk->bank, opl->opt);  // track RETURNS
     add_endblk (blk, pc + cnt - 1, 1);	/* end block and STOP for E */
     ans = 0;
    }


/**************************************************************************
* now do the printout part
***************************************************************************/

 if (prt)
   {
    if (indx > 99) ofst--;         // put prefix back for printing
    pp_hdr (ofst, opl->name, cnt);
    i = numops;
    while (i)
     {
      p_oper (i,0);
      if (--i) pstr (",");
     }

/**********************************************
* source code generation from here
* check and do substitutes and cleanups, name resolution etc.
*********************************************/



    if (opl->sce)
      {     /* don't add if no pseudo sce */
       p_pad(OPSSTART);
       check_rbptr(numops,opl);
       tx = check_shiftr(1,opl);
       tx = check_bitwise(opl, tx);

       j = find_fjump (pc, cbank());

       if (j==1 && (opl->opt & J))
         {
         if (opl->rpx) tx = opctbl[opcind[opl->rpx]].sce;  // this seems to work correctly !
         else j = 0;
         }

       //*** do psuedo source output

       while (*tx)
	{
	 switch (*tx)        // & 0xf)
	  {
	   case 1:
	   case 2:
	   case 3:
     	   case 4:
	   case 5:
	   case 6:
	    p_oper (*tx,1);
    	    break;

           case 8:
            pstr ("if (");
	    break;

	   case 9:
  	    switch (j)  //jump handling
             {
              case 1 :
	        pstr (" {");   // [if] with sce flipped
                break;
              case 2 :
                pstr ("return;");
                break;
              default:
                pstr ("goto ");
	        p_oper (1,1);
	        pstr (";");
                break;

             }
	    break;

	   case 10:
	    pstr ("= ");
            if ((opl->opt & Z) && !opstab[*(tx+1)].xpc)
             {
              while (*tx != '+' && *tx != '-') tx++;   // skip zero operand and op
              tx++;
              }
	    break;

	   case 11:
	    p_indl();
	    break;

           case 12:
	    ans += pp_subpars(opstab[1].xpc, cbank(),ofst, cnt);
            break;

	   default:
            pstr ("%c", *tx);
	  }
	 tx++;
	}
      }

     find_tjump (pc + cnt, cbank());	 // add closing brace(s) if reqd
     pp_comment (ofst);
     if (opl->opt & E) rprt(0);
     if (ans < 0)      rprt (0);
    }

  for (i = 0; i < 4 && !(opl->opt & N); i++) opstab[i+4] = opstab[i]; // save to last op

  (*ofs) += ans;
  return ans;
}



void set_opts (CPS *c)
{

/**************** a lot more options to add *********************
NOW autonaming, autolabels, 8061/8065,
NEW autofuncs,  autosubroutines
*******************************************************************/

  cmdopts |= c->cmdflgs;
  cmdopts |= screenopts;
 // dbg = PDBGM ? 1 : 0;
  wprt("\nOpts = ");
  prtflgs(1,cmdopts);
  wprt("\n\n");

}

RBT *add_rbase(long reg, long val)
{
  RBT *x, *z;

  x = (RBT *) cmem(&rbase);       //.size);           //sizeof(RBT));
  if (!x) return 0;

  x->bank = 8;
  x->reg =  reg;
  x->addr = val;
  z = (RBT*) chain(&rbase, x);/* now chain it in */

  if (z)
    {
     dprt("ignore add rbase, reg %lx val %lx \n", reg, val);
     x = 0;
    }
  else
    {
     dprt("add rbase %lx = %lx\n", reg, val);
    }
  return x;
}

void set_rbas (CPS *c)
{
 add_rbase(c->start, c->end);
}


void set_adnl(CPS *cmnd, void *b)
{
  CADT *l, *c;
  short i;

  LBK * z;
  z = (LBK*) b;
  if (!z) return;
  if (!cmnd->levels) return;  // may have addnl block (e.g. WORD)

  // OK, now can replace all levels
  freeaddl(z);   // clear any additional
  c = NULL;
  z->size1 = 0;
  z->size2 = 0;

  i = 0;
  while (i < cmnd->levels)
    {
     l = c;
     c = add_ext(0);      // new struct for saved command
     *c = cmnd->cmad[i];  // copy cmd for this level
     if (i <= cmnd->slev) z->size1 += c->f.esize * c->f.cnt;    /* cum. size * cnt for each level */
     else  z->size2 += c->f.esize * c->f.cnt;
     if (l)
        l->next = c;    // chain new block
     else
         z->addnl = c;      // link first block
     i++;
    }

      if (PDBGM)                      //dbg)
       {
       wprt("      with addnl params");
       prt_ex(z->addnl, z->fcom, NULL);

       wprt("\n");
       }

}


void set_data_vect(LBK *blk)
{
 long ofst;
 ushort pc;
 short i;
 CADT *addnl;

 if (blk && blk->fcom == C_STCT)
  {
   ofst = ofpc(blk->start,blk->bank);
   while (ofst < ofpc(blk->end,blk->bank))
     {
      i = 0;
      addnl = (CADT *) blk->addnl;
      while (addnl && i < 32 )
       {
        if (addnl->f.vect && !PMANL)
         {
          pc = g_val(ofst,2,0);
          add_subr (ofst, pc, blk->bank);
          add_symn(0,pc,blk->bank,-1);
          add_scan (pc, blk->bank, ofst, blk->bank);
         }
        ofst += addnl->f.esize * addnl->f.cnt;
        i++;
        addnl = addnl->next;
       }
     }
  }

}

void set_prm (CPS *cmnd)
{
  LBK *blk;
  blk = add_cmd (cmnd->start,cmnd->bank, 0,0, cmnd->end, cmnd->fcom,1);  // with cmd flag
  set_adnl(cmnd,blk);
  if (blk) blk->term = cmnd->addreg;
  if (cmnd->symname) add_sym(cmnd->symname,cmnd->start, cmnd->bank, -1);
  set_data_vect(blk);
}


void set_sym (CPS * cmnd)
{
  SYT *x;
  if (cmnd->levels)
   {
    if (cmnd->cmad[0].f.sign) x = add_sym(cmnd->symname, cmnd->start, cmnd->bank, cmnd->cmad[0].divisor);
   }
  else x = add_sym(cmnd->symname, cmnd->start, cmnd->bank, -1);
  if (x && cmnd->cmad[0].f.nods)  x->f.flags = 1;
}


void set_subr (CPS *cmnd)
{
  SXT *xsub;
  add_subr(0, cmnd->start, cmnd->bank);
  if (cmnd->symname) add_sym(cmnd->symname,cmnd->start, cmnd->bank, -1);
  else add_symn(0,cmnd->start, cmnd->bank,-1); // auto name
  add_scan (cmnd->start, cmnd->bank, 0, 0);
  xsub = get_subr(cmnd->start, cmnd->bank);
  if (xsub)
    {
    set_adnl(cmnd,xsub);
    xsub->cmd = 1;
    xsub->ptype = cmnd->type;
    xsub->szreg = cmnd->colreg;
    xsub->adreg = cmnd->addreg;
    xsub->size = cmnd->csize;
    dprt ("type=%d, Szr=%x, Adr=%x\n",xsub->ptype,xsub->szreg, xsub->adreg);
    }

 }



void set_time(CPS *cmnd)
 {
  LBK *blk;
  long val, xofst;
  short x, b, m;
  SYT *s;
  CADT *a;

  blk = add_cmd (cmnd->start,cmnd->bank, 0,0, cmnd->end, cmnd->fcom, 1); // with cmd flag
  set_adnl(cmnd,blk);
  if (cmnd->symname) add_sym(cmnd->symname,cmnd->start, cmnd->bank, -1);
  // up to here is same as set_prm...now add names

  if (!blk) return;          // command didn't stick
  a = (CADT*) blk->addnl;
  if (!a) return;                     //  nothing extra to do
  if (!a->f.name && !a->f.sign) return;       // nothing extra to do

  if (a->f.esize < 1) a->f.esize = 1;  // safety

  xofst = ofpc(cmnd->start, cmnd->bank);

  while (xofst < fillen)
   {
    val = g_val (xofst++, 1, 0);  // first byte
    x = val & 1;                  // long or short entry
    if (!val) break;             // end of list;
    val = g_val (xofst, a->f.esize, 0);
    if (a->f.name) s = add_symn(4, val, cmnd->bank, -1);
    xofst+= a->f.esize;        // jump over address (word or byte)

    if (x)      // long entry
     {
      if (s && a->f.sign)
        {                      // add flags word name too
        m = g_val (xofst++, 1, 0); // bit mask
        b = 0;
        while (!(m&1)) {m /= 2; b++;}    // bit number
        val = g_val (xofst++, 1, 0);    // address of bit mask
        sprintf(nm,"Go_");
        sprintf(nm+3,s->symnam);
        add_sym(nm, val, cmnd->bank, b);
        }
      else     xofst+=2;                // jump over extras
     }
   }

 }


void set_bnk (CPS *cmnd)
{
 short i;

 if( !banks[0].cmd)
    {  // new banks command, clear auto ones
    for (i = 0; i < 4; i++) banks[i].used = 0;
    }

 i = 0;
 while (banks[i].used) i++;

 if (i > 3)
  {
   dprt("Banks Definition FULL (4 banks) \n");
  }

 banks[i].start = cmnd->start;           // not PCORG, these are OFFSETS !;
 banks[i].end   = cmnd->end;
 banks[i].bank  = cmnd->bank;
 banks[i].cmd = 1;
 banks[i].used = 1;
 dprt("Bank Set %lx %lx %d (%d)\n",banks[i].start, banks[i].end,banks[i].bank, i);
 }


void set_vect (CPS *cmnd)
{
  long i, ofst;
  LBK *blk;
  short bank;

  blk = add_cmd (cmnd->start, cmnd->bank, 0, 0, cmnd->end, C_VECT,1); // with cmd flag
  if (PMANL) return;
  set_adnl(cmnd,blk);
  bank = cmnd->bank;
  if (cmnd->cmad[0].f.foff && findbank(cmnd->cmad[0].divisor) >=0 ) bank = cmnd->cmad[0].divisor;

  for (i = cmnd->start; i < cmnd->end; i += 2)
    {
      ofst = g_val (i, cmnd->bank, 2, 0);
      add_subr (i, ofst,bank);
      add_symn(0,ofst,bank,-1); // auto name
      add_scan (ofst, bank, i, cmnd->bank);
    }
}

void set_code (CPS *cmnd)
{
  add_cmd (cmnd->start, cmnd->bank, 0, 0, cmnd->end, cmnd->fcom, 1); // with blk->cmd = 1;
}

void set_scan (CPS *cmnd)
{
  LBK *blk;
  blk = add_scan (cmnd->start, cmnd->bank, 0, 0);
  if (blk) blk->cmd = 1;
}


void set_xcode (long start, long end, short bank, short cmd)
{
   LBK *b;
   b = (LBK *) cmem(&inhb);
   b->start = start;
   b->end   = end;
   b->bank = bank;
   b->fcom = C_XCODE;
   b->addnl = NULL;
   b->cmd = cmd;
 //  b->guess = !b->cmd;
   dprt("set XCODE = %lx %lx\n", start, end);

   chain(&inhb,b);

}


void set_cdih (CPS *cmnd)
{
   set_xcode(cmnd->start,cmnd->end, cmnd->bank,1);
}

/**********************************************
* verify checksum = zero, must be a 0xn000 address to be valid
* also suspect buf [6]  (12) is hardware ROm end
* ints need to be shorts for Linux ...do this with long to make sure
************************************************/

void verify_chk (void)
{
  long pcx;
  ushort chks;
  ushort *lbuf;

  // NO IDEA how this works on multibanks !!


  chks = 0;
  lbuf = (ushort *) ibuf;

  for (pcx = 0; pcx < fillen / 2; pcx++)
    {
      chks += lbuf[pcx];
      if (!chks && (pcx & 0xfff) == 0xfff)
	{
	  ckend = pcx * 2 + PCORG + 1;
	  wprt ("Correct checksum (= 0) found at %lx\n", ckend);
          rprt ("\n## Correct checksum at %lx", ckend);
          pcx = fillen;		/* force exit */
	}
    }

  if (chks)
    {
     wprt ("No Correct checksum found\n");
     if (lbuf[6] && !(lbuf[6] & 0xfff))
      {
	hwend = lbuf[6];
	hwend--;
	wprt ("# Probable hardware ROM end at %x\n", hwend);
      }
    }
}



/***************************************************************
 *  do last phase listing
 *
 *  loop within loop for faster speed
 ***************************************************************/
void do_listing (void)
{
  long ofst,end,cnt;
  short i, ix;
  LBK *x ;   //*nxt;
  LBK d;                    /* used for default prints */
  ushort pc, bank;

  anlpass = ANLPRT;
  getcmnt(&cmntpc, &cmbank, &cmtt);          // initialise comments
  d.fcom = C_DFLT;
  d.addnl = NULL;

  //d.flags = 0;
 for (i = 0; i < NC(banks); i++)
    {
     if (!banks[i].used) continue;

     bank = banks[i].bank ;
     if (P8065)
      {
       rprt ("\n\n ########################################################################");
       rprt (" #    Bank %d  file %lx-%lx, (PC = 0x2000 - %lx)", bank, banks[i].start, banks[i].end, pcbend(bank));
       rprt (" ########################################################################\n\n");
      }

     for (ofst = banks[i].start; ofst <= banks[i].end; )
      {
      /* find command for this offset */

      x = NULL;
      pc = pcof(ofst, &bank);
      ix = bfindix(&cmdch, pc,bank, 0);            // index for command block
      x = (LBK*) cmdch.ptrs[ix];

      if (eq(&cmdch,ix,pc,bank,0))         // if found
        {
         //pbk (x,NULL,"found list blk for %lx", ofst);
        // if (ix+1 < cmdch.num) nxt = (LBK*) cmdch.ptrs[ix+1];
        }
      else
       {
        d.start = pc;
        d.bank = bank;
        d.end = pcbend(bank);

        if (ix < cmdch.num && x->bank == bank && x->start <= pcbend(bank)) d.end = x->start -1;

       // nxt = x;          // not found, build default
       // if (nxt && nxt->bank == bank && nxt->start <= pcbend(bank)) d.end = nxt->start -1;
       // else d.end = pcbend(bank);

        x = &d;
  //      pbk (x,NULL,NULL,"default for %lx", ofst);
       }

      rprt ("\n");		/* whenever a new command, a new block */

      if (x->start > x->end)
       {
        pbk(x, 0,0,"INCORRECT command or order - skip");
        x->end = x->start+1;
        ofst++;
        continue;
       }

   /*   if (ofst < ofpc(x->start, x->bank))
       {
        wprt("PANIC");
        }   */
      end = ofpc(x->end, x->bank);

  //    pbk (x,NULL,NULL,"printing for %lx", ofst);
      cnt = 1;
      while (cnt && ofst <= end)
       {
        show_prog (ofst, anlpass, fillen);
        cnt = dirs[x->fcom].prtz (&ofst, x);
        pp_comment (ofst-1);	      /* comments after last dft don't work without this */
       }

      if (ofst <=end)
       {       // this should never be true.....
        wprt("xxx");
       }

      }
    }
}



void scan_all (void)
{
  LBK *s;

  if (PDBGM)                    //dbg)
   {
    dprt ("*** commands - before scan ****\n");
    prt_commands ();
   }

  strtch(&scanch);

  while (s = (LBK*) gnxtch(&scanch))
   {
    if (!s->scanned)
    {
     if (PLCOD || anlpass >= ANLPRT) rprt (0);
     scan_code(s);
     strtch(&scanch);    // restart at front in case of new scans
    }
   }

 /* strtch(&scanch);        // now scan for any error marked blocks

  while (s = (LBK*) gnxtch(&scanch))
   {
    if (s->err && s->scanned < 5)
    {
     s->err = 0;
     if (cmdopts & PPDBG || anlpass > 2) rprt (0);
     scan_code(s);
     strtch(&scanch);    // restart at front in case of new scans
    }
   } */

 }

/* find functions */

void incpc (long *ofst, short inc)
{
  *ofst += inc;
  if (*ofst < 0 || *ofst >= fillen)
    {
      dprt ("increment outside ROM [%lx] ignored\n", *ofst);
    }
}




void fix_tab(short ix)
{
 // extend table to next entry as default.
 // doesnt work if table abuts large FILL area !!

  LBK *blk,*n,*n2;
  CADT *adnl;
  short size;

  blk = (LBK*) cmdch.ptrs[ix];  // this table

  adnl = (CADT*) blk->addnl;        // THIS block
  n  =   (LBK*) cmdch.ptrs[ix+1];   // Next block
  n2 =   (LBK*) cmdch.ptrs[ix+2];   // next but one

  pbk(blk,0,0,"Inspect table");

  // check if a single word, which can be ignored...
  // while ??
  if (n && n->fcom <= C_WORD && n->end - n->start < 2)
    {
     if (n2->start - blk->end > 3)
        { // single word or byte with gap after it
         pbk (n, 0, 0,"Drop guessed word/byte");
         release(&cmdch,ix+1,1);
         n = (LBK*) cmdch.ptrs[ix+1]; // remap
        }
      }

  if (n)          //adnl && n)
       {
       size = n->start - blk->start;
       if (size > 256) size = adnl->f.cnt * 16;
       if (size > adnl->f.cnt) size = (size/adnl->f.cnt) * adnl->f.cnt;
       blk->end = blk->start+size-1;
       pbk(blk,0,0,"Update to");
       }

  }

void fix_func(short ix)
{
 // extend functions to true 'end' funcs should be
 //  unsigned  - start IN 0xffff,  end 0       (0xff for byte)
 //  signed    - start IN 0x7fff,  end 0x8000  (0x80 for byte)
 //  OUTPUTS cross zero if signed...but either way...

  long val, val2;
  long ofst, end, maxend;
  CADT *adnl;
  short size, row;
  LBK *blk, *n, *n2;

  blk = (LBK*) cmdch.ptrs[ix];  // this func
  adnl = (CADT*) blk->addnl;
  n =   (LBK*) cmdch.ptrs[ix+1];
  n2 =  (LBK*) cmdch.ptrs[ix+2];   // next but one
  pbk(blk,0,0,"Inspect func");

  ofst = ofpc(blk->start, blk->bank);
  size = adnl->f.esize;        // entry size
  row  = size*2;              // row size;
  if (n) maxend = ofpc(n->start,n->bank);
  else maxend = pcbend(blk->bank);
  end = ofst;

  val = g_val(ofst+size-1,1,0);   // top byte

  if (val != tvals[0].start &&  val != tvals[1].start)
     {
      pbk(blk,0,0,"Invalid start value %lx for func", val);
      return;
     }

  if (val != tvals[adnl->f.sign].start)
    {
     adnl->f.sign = ~adnl->f.sign;         // swop sign
     pbk(blk,0,0,"Swop sign to %d for func", adnl->f.sign);
    }

  while (ofst+=row)
    {
     if (ofst > fillen) break;
     val = g_val(ofst, size, 0);
     if (val == tvals[adnl->f.sign].end[size-1])
        {
         end = ofst+row-1;
         break;
        }
     }


     // can continue if both values the same in table (2 or 4 bytes)
     // MUST CHECK NEXT block for next->start to stop any overlap !!

     if (end < maxend)  blk->end = pcof(ofst+row-1,0);
     else
      {
               // check if a single word, which can be ignored...
        if (n && n->fcom <= C_WORD && n->end - n->start < 2)
        //if (n && n->end - n->start < 2)
         {
          if (n2->start - blk->end > 3)
           {
            pbk (n, 0, 0,"Drop guessed word/byte");
            release(&cmdch,ix+1,1);
            n = (LBK*) cmdch.ptrs[ix+1];      // remap next
            maxend = ofpc(n->start,n->bank); // and new end addr
           }
          }

       /*dprt ("FIXFUTAB ignore single word/byte = %lx\n", n->start);
            n = (LBK*) cmdch.ptrs[ix+3];
            }}

     /*  if (n->end - n->start < 2 && n->next && n->next->start - n->end > 1)
           { // single word or byte with gap after it
            dprt ("FIXFUNC ignore single word/byte = %lx\n", n->start);
            maxend = ofpc(n->next->start,n->next->bank);
            // need extra check here to decide if table/func continues or not -
            // could try checking gap between each row ?
            }    */
       else
         {
          pbk(blk,0,0,"Addr abandon end = %lx", end);
          return;
         }
      }
     // check continuation of func
     val = g_val(ofst, row, 0);        // last valid whole row

     while (ofst < maxend)
       {
       val2 = g_val(ofst, row, 0);   // whole ROW must match
       if (val != val2) break;
       ofst+=row;
       }

  end = pcof(ofst-1, 0);
  if (end > blk->end) blk->end = end;
  pbk(blk,0,0,"Update func to");

 }

 void fix_tabfuncs(void)
{
  short ix;
  LBK *b;

  if (PMANL) return;

  for (ix =0; ix < cmdch.num; ix++)
   {
    b = (LBK*) cmdch.ptrs[ix];  // this func

    if (b->fcom == C_FUNC  && b->addnl && !b->cmd ) fix_func(ix);       // was guess
    if (b->fcom == C_TABLE && b->addnl && !b->cmd ) fix_tab (ix);

    // and here could check any other possibilities...
   }


}


/********** command processing section **************/

 void clrlev(char *z, short *w)
  {
  *z = '\0';
  *w = 0;
  }

 void newlevel(short lev)
  {
  spl.clv = lev;
  spl.cwd = 0;
  }


 void strconvert(char *orig)
  {
  /******************************************************************
  Convert string to individual words and levels for command parsing
  *******************************************************************/

 short i,w;
 long o,n;          // for reallocs
 char *z;
 WDS* d;

 z = orig;			/* read pointer */
 w = 0;                         /* in word */
 spl.twds = 0;
 spl.slv = 0;
 newlevel(0);                   /* set curlevel */

 while (*z)         // && spl.twds < spl.nptrs30)
     {
     i = spchar(z);

     switch (i) {

     case 0:
       	if (!w) {   // ordinary char
          d = spl.wds + spl.twds;
          d->st = z;
          d->no = spl.cwd;
          d->lv = spl.clv;
          spl.cwd++;
          spl.twds++;
          if (spl.twds >= spl.nptrs)
            {
              o = spl.nptrs*sizeof(WDS);
              spl.nptrs  += 30;
              n = spl.nptrs*sizeof(WDS);
              spl.wds = (WDS*) mem(spl.wds, o, n);
              //spl.wds = (WDS*) realloc(spl.wds, spl.nptrs*sizeof(WDS)); // HERE for realloc....
            }
          w = 1;
          }
        break;

     case 1:             // delimiter
       clrlev(z,&w);
       break;

     case 5:             // a newline reqd
     spl.slv = spl.clv;  // and drop through

     case 2:           // option start
       clrlev(z,&w);
       if (spl.clv < 2) newlevel(2);
       else newlevel(++spl.clv);
       break;

     case 3:          // name start
       clrlev(z,&w);
       if (spl.clv != 1) newlevel(1);
       else newlevel(0);
       break;

     default:       // anything else marks a comment start (4 onwards)
       *z = '\0';  // safety
       return;
       }
     z++;
  }

 if(!spl.cwd) spl.clv--;
 }


long get_num(char *st, short *err, short dp )
{
  char *ch;
  long val;
  short base, neg, dot;

  ch   = st;
  *err = 0;
  val  = 0;
  dot  = 0;  // dp multiplier
  neg  = 0;
  base = 16;

 switch (*ch) {

      case '-':
	  neg = 1;   /* and fall through */
      case '+':
	  base = 10;
	  ch++;
      default:
	  break;
      }

 if (dp) base = 10;       // force base 10 with dp (V option)

 while (*ch && !(*err)) {

   if (*ch == '.')
      if (dp) {dot = 1; *ch++; continue;} else {*err = 8 ;}

   if (!isxdigit(*ch) && base == 16)  {*err = 2; }
   if (!isdigit(*ch)  && base == 10)  {*err = 2; }

      if (!*err) {
	 val *= base;
         dot *= base;                         // keep dp place
         if (dot > 100) *err = 11;                // strictly 2 decimals
         if (isdigit(*ch))  val += *ch -'0';
         else               val += toupper(*ch) -'A'+ 10;
	}

       ch++;
  }

 if (neg) { val = -val;}
 if (base == 16)
    {
     if (val < 0 || val > 0xFFFFF) *err = 3;   // allow 5 hex digits for multibank
    }

    if (dp)
      {          // number scaling for decimals

      if (dot < 2 ) val *=100;
      else if (dot == 10) val *=10;
      }
 return val;     // val is always val*100 if dp set
}


char *errors[] = {
"",                         // dummy entry 0
"invalid command",
"invalid number value",
"number out of range",
"too many params for level",
"symname not expected",            // 5
"invalid option",
"extra chars or command garbled",
"decimal point not allowed here",
"too many params for command",
"end addr must be greater than start",  //10
"2 decimal places maximum"
"error out of range!"

};

short do_error(short err, char *st)
{
 short i;
 WDS *w;
 
 if (err)
  {
   if (err > 11) err = 12;
   for ( i = 0; i < spl.twds; i++)
     {
      w = spl.wds + i;
      wprt("%s ",w->st);
      }
   wprt("\n\t%s - %s\n", st, errors[err]);
  }
 return err;
}



/************************************************/


long parse_com(char *flbuf)
{
/* use word struct and parse (and check) it */

 short i,j, err, adlv, tsize, nums;
 char s, *z;
 long ans[3];
 WDS *w,*wn;
 DIRS* crdir;
 CPS  cmnd;		   /* for parse command */
 CADT *cadd;

 strconvert(flbuf);
 // need flbuf for error printout....
 if (spl.twds < 1) return PCORG;

 err = 0;
 adlv = 0;
 cmnd.symname = '\0';
 cmnd.levels = 0;
 cmnd.fcom   = 0;
 cmnd.csize  = 0;        /* total command size */
 cmnd.type   = 0;
 cmnd.colreg = 0;
 cmnd.addreg = 0;       // for func and tab procs
 cmnd.bank   = 8;       // default is 8
 tsize = 0;             /* addnl level command size */
 cmnd.cmdflgs = 0;
 crdir = NULL;

 cadd = &cmnd.cmad[adlv];
 cadd->divisor  = 0;
 cadd->next     = NULL;
 cadd->flags    = 0x402;     // cnt =1 and esize = 1 rest = 0, clear addnl struct lev 0

 i = 0;
 while (i < spl.twds && !err )
  {
  w = spl.wds+i;
 // wn = &spl.wds[i+1];
  if (crdir && w->lv > crdir->maxlv) err = do_error(9,flbuf);

  if (crdir)
    { j = P8065 ? 3 : 2 ;              // remove bank option for 8061
      if (crdir->flgs) j = 1;                      // not for flags type funcs
      if (!w->lv && w->no > j) {err = do_error(4,flbuf); continue;}
    }

  switch (w->lv) {

   case 0:
    switch (w->no) {

      case 0:   // command
         for (j = 0; j < NC(dirs); j++)
         {
	 if (!strncmpi (dirs[j].com, w->st, dirs[j].minc) )
            {
             cmnd.fcom = j;
             crdir = dirs+j;            /* keep ptr to command */
             break;
	    }
	}
	if (j >= NC(dirs)) err = do_error(1,w->st);
        break;

      case 1:     // start addr
            cmnd.start = get_num(w->st, &err, 0);
            do_error(err,w->st);
	    cmnd.end  = cmnd.start;                   // default
      	    break;
      case 2:     // end, if present */
            cmnd.end   = get_num(w->st, &err, 0);
	    do_error(err,w->st);
            if (cmnd.end < cmnd.start)
              {
               err = 10;
               if (P8065 && cmnd.end <= 15)
                 {                // 8065 bank, no end addr
                  cmnd.bank = cmnd.end;
                  cmnd.end = cmnd.start;
                  err = 0;
                 }
              }
            do_error(err,w->st);
            cmnd.csize = cmnd.end - cmnd.start +1;
            if (crdir->word && (cmnd.csize & 1))
               {
                cmnd.end++;
                cmnd.csize++;
               }
           break;

      case 3:
           cmnd.bank = get_num(w->st, &err, 0);
	   do_error(err,w->st);
           if (cmnd.bank > 15)  err = do_error(10,w->st);
           break;
      default:
           err = 4;     /* too many params */
      }
    break;

 case 1:             // name level
     if (w->no) {err = do_error( 7,w->st); break; }
     if (crdir->namee) cmnd.symname = w->st;
     else err = do_error(5,w->st);
     break;

 // case 2:   // line split for structs

 case 2:         // options level = 2 and greater
 default:
     s = toupper(*w->st);
   //  if (s < 'A' || s > 'Z' ) { err = do_error(6,w->st); break; }   redundant
     z = crdir->opts;          // command option letters

     while (*z) {
     if (s == toupper(*z)) {err = 0; break; }
     z++;
     }
     if (!(*z)) { err = do_error(6,w->st); break;}
     // else option letter is valid

     if ( islower(*z++) )
       {
        nums = 1;                                  // at least one following number expected
        if (isdigit(*z)) {nums = *z - '0'; z++;}   // if digit in string, specifies more values
        z = w->st+1;                               // skip command letter
        if (*z == 0) w = spl.wds + (++i);          // move to next word if single char
        else w->st++;                              // try immediately after option letter

        j = 0;
        wn = w;
        for (j = 0; j < nums && wn->lv == w->lv; j++)
          {
           ans[j] = get_num(wn->st, &err, (s == 'V'));
           if (err) {do_error(err,w->st); break;}
           wn++;  /* next word */
          }
        i+=j-1;
        if (j != nums) {do_error(9,w->st); break;}
      }
     else
      {
       nums = 0;
       ans[0] = 0;           // no number param
       z = w->st+1;       // skip command char
       }
     if (crdir->flgs)
        cmnd.cmdflgs |= 1 << (s - 'A') ;   // mark opts in flagword
     else
       {

       switch(s)
        {
 // case 'A':                    // AD voltage ??
 //    cadd->volt = 1;
 //    break;

 // case 'B' :
 //    cadd->f.foff = 1;
 //    cadd->divisor  = ans;    // Byte + fixed address offset (funcs)
 //    break;

 // case 'C' :
 //    break;

  case 'D' :
     cadd->f.foff = 1;
     cadd->divisor  = ans[0];    // Word + fixed address offset (funcs) - bank swop vect
     break;

  case 'E' :
     cadd->f.enc = ans[0];
     cadd->divisor = ans[1];
     cadd->f.esize = 2;   // encoded, implies word
     break;

  case 'F' :
     cmnd.type   = ans[0];    // special subr type (funcs/tabs etc.)
     cmnd.addreg = ans[1];    // (register) address for table/func
     cmnd.colreg = ans[2];    // (register) columns for table
     cadd->f.nods = 1;
     break;

  // G H I J K

  case 'L':                // Long
     cadd->f.esize = 4;
     break;

 // case 'M':                // mask pair, use esize to decide word or byte
 //    cadd->mask = 1;
 //    break;

  case 'N':
     cadd->f.name = 1;       /* Name lookup */
     break;

  case 'O':                /* Cols or count*/
     cadd->f.cnt = ans[0];
     break;

  case 'P':               /* Print fieldwidth */
     cadd->f.pfw = ans[0];
     break;

  case 'Q' :              // terminator byte
     cmnd.addreg++;
     break;

  case 'R':               /* indirect pointer to subroutine */
     cadd->f.esize = 2;   // safety, lock to WORD
     cadd->f.vect = 1;
     cadd->f.name = 1;     /* with name by default */
      break;

  case 'S':              /* Signed */
     cadd->f.sign = 1;
     break;

  case 'T':                /* biT - for symbols only !*/
     cadd->f.sign = 1;
     cadd->divisor = ans[0];
     break;                // temp use divisor for bit number....

     // U

  case 'V':                  // diVisor
     cadd->divisor = ans[0];   // ans is always *100 for this option
     cadd->f.dp = 1;
     break;

  case 'W':                 /* Word*/
     cadd->f.esize = 2;
     break;

  case 'X':                 /* Print in hex */
     cadd->f.hex = 1;
     break;

  case 'Y':                /* bYte*/
     cadd->f.esize = 1;
     break;

     // Z

  default:
      err = do_error(7,w->st);
     break;

}

     wn = spl.wds + i+1; //  wn = w+i+1;  /* next word */

     if (cadd->f.nods)
        {  // no extra level for this option
         cadd->divisor  = 0;
         cadd->next     = NULL;
         cadd->flags    = 0x402;     // cnt =1 and esize = 1 rest = 0  zflgs(cadd);
         cadd->f.nods = 1;      // but keep flag
         break;
        }

     if (w->lv > 1 && wn->lv > w->lv || i >= spl.twds -1)
	 {
         // new level for options

         if (!cadd->f.esize) cadd->f.esize = 1;   // safety
         tsize += cadd->f.esize * cadd->f.cnt;    // total size for each level
         if (cmnd.fcom == C_WORD) cadd->f.esize = 2;
         if (!cadd->f.pfw)
           {           // no print width specified
            cadd->f.pfw = 3;
            if (cadd->f.esize >1) cadd->f.pfw = cadd->f.esize+3;
            if (cadd->f.sign) cadd->f.pfw++;  // add space for sign
           }
	 cmnd.levels = w->lv-1;
         adlv++;
         cadd = &cmnd.cmad[adlv];
         cadd->divisor  = 0;
         cadd->next     = NULL;
         cadd->flags = 0x402;     // cnt =1 and esize = 1 rest = 0  zflgs(cadd);        // clear for next lev
	 }
     break;
   }
  }
i++;
}

/* do extra checks here .... */
cmnd.slev = cmnd.levels+1;
if (spl.slv) cmnd.slev = spl.slv-2;
cmnd.csize = tsize;

if (cmnd.fcom == C_FUNC &&  cmnd.levels  < 2)
   { cmnd.cmad[1] = cmnd.cmad[0];
     cmnd.levels ++;
     cmnd.csize = tsize*2;
   }

if (!err) dirs[cmnd.fcom].setz (&cmnd);

show_prog(0,0, fillen);
return cmnd.end;
}


char *pname(short ix, ushort pc, ushort bank)
{
short i, size;
long ofst;
NAMES *x;
char *y, *z;
SIG *p;          // temp for debug check

 x    = (P8065) ? inames5     : inames1;
 size = (P8065) ? NC(inames5) : NC(inames1);
 ix -= 0x10;
 ix /= 2;          // get correct index
 y = NULL;

 ofst = ofpc(pc,bank);

 /*val = 0;           replaced with signature....
 if (!iaddr(pc,bank))  val = g_val (pc,bank, 1, 0);    // get first instruction
 i = 0;
 while (val == 0xff &&  i < 10) val = g_val (pc+i++, 1, 0); // skip nops
 // also need to skip pushp and popp instructions in 8065
 if (val == 0xf0 || val == 0xf1) return x->name;
 */

 p = do_sig(&ign, ofst);
 if (p) return x->name;         // ignore interrupt matches


 for (i = 1; i < size; i++)
    {
    if (ix <= x[i].end && ix >= x[i].start)
       {
       y = x[i].name;
       z = nm;
       while (*y)          // do number substition if reqd
        {
        if (*y != '\1') sprintf(z++,"%c", *y);
        else
          {
           sprintf(z++, "%d", ix-x[i].start);
           while (isdigit(*z)) z++;
          }
        y++;
        }
       break;
       }
    }
return nm;
 }


/***************************************************************
 *  read directives file
 *  read directives OR do a full default scan
 ***************************************************************/
void getudir (void)
{
  long ofst;
  short i;
  long  j, k;

  cmdopts |= PDEFLT;
  cmdopts |= screenopts;
 // dbg = PDBGM? 1 : 0;
 
  if (fdir == NULL)
    {
      wprt ("No directive file - default options\n");
    }
  else
    {
     while (1)
	{
	  if (!fgets (flbuf, TXTSZE, fdir)) break;
          ofst = parse_com(flbuf);
          show_prog(ofst,0,fillen);
	}
    }

  // do prefixed symbols and  standard analysis additions, if not already specified
  // alternate options 8061 and 8065, and assume bank 8.

  if (P8065)
   {
    for (j = 0; j < 5; j++) incols[j] +=2;     // add space for bank
   }

  j = (P8065)? 2:1;

  for (i = 0; i < NC(defrsyms); i++)
    {
     if (defrsyms[i].O65 & j)
       add_sym (defrsyms[i].symn, defrsyms[i].addr, 8, defrsyms[i].bit1);
    }

  for (i = 0; i < NC(defwsyms); i++)
    {
     if (defwsyms[i].O65 & j)
       add_wsym (defwsyms[i].symn, defwsyms[i].addr, 8, defwsyms[i].bit1);
    }

  if (PMANL) return;

  for (i = 0; i < NC(banks); i++)
    {
     if (banks[i].used)
       {

        j = (P8065) ? 0x5f : 0x1f;
        k = banks[i].bank;
        dprt("--- auto setup for bank %d ---\n",k);
        add_scan (PCORG, k, 0, 0);
        add_cmd (PCORG+0xa, k, 0, 0, PCORG+0xe, C_WORD,1);   // cal pars and cmd
        add_cmd (PCORG+0x10, k, 0, 0, PCORG+j, C_VECT,1);    // interrupt vecs, by cmd

        depth = 1;              // interrupt calls are subrs...
        for (j -=1; j >= 0xf; j-=2)
	{
	 ofst = g_val (PCORG+j, k, 2, 0);
         if (PINTF && !get_subr(ofst, k))
          {
	   add_subr (PCORG+j, ofst, k);
           add_sym(pname(j,ofst,k),ofst,k, -1);
           add_scan (ofst, k, PCORG+j, k);
          }
        }
       depth = 0;
       }
    }
  }



short readbin(short msg)
{     // called BEFORE directives - do banks for summary option anyway
     // msg to write messages - not for summary
  long bytes, end;
  short ans, i;

  fillen = fseek (fin, 0, SEEK_END);    // should be zero...
  fillen = ftell (fin);
  i = fseek (fin, 0, SEEK_SET);	/* get file size & restore to start */

  // check i !!

  if (msg) wprt ("Input file '%s' is %ld (%lx) bytes\n",FNin, fillen, fillen);



  ibuf = (uchar *) mem (0,0,fillen);
  if (!ibuf && msg) {wprt ("Can't allocate file input buffer"); return -1;}

  opst = (short *) mem (0,0,fillen / 8);
  if (!opst && msg) {wprt ("Can't allocate file input buffer"); return -1;}

  bytes = fread (ibuf, 1, fillen, fin);
  if (msg) wprt ("Read input file OK (%ld bytes)\n", bytes);



  for (i = 0; i < NC(banks); i++) banks[i].used = 0;   // clear all banks

  // first jump starts at 0 or 2000 within fillen for each bank...
  // could do rbase sig to decide if bin is 8061 or 8065


  end = 0;       // file offset
  i = 0;         // bank ix

  while (end < fillen)
    {
     // for each bank
     bytes = end;
     banks[i].used = scan_start(&end);
     banks[i].start = end;           // these are TRUE offsets,  PCORG starts HERE !;
     end += 0xdfff;                  // end of this bank
     banks[i].end = (end < fillen) ? end : fillen-1;
     banks[i].tend = banks[i].end;                     // true end (fill)
     if (!banks[i].used)
       {
        if (msg) wprt ("No bank start at %lx\n", bytes);
        if (msg) wprt ("No bank start at %lx\n", bytes + PCORG);
       }
     else i++;
     end++;
    }


  numbanks = i;

  // now do the checks.....

  if (numbanks > 1)  cmdopts |= H;        // multibank

  codbank = 0;   // code start depends upon jumps found
  datbank = 1;   // data default to 8 upon start

  ans = numbanks;
  switch (numbanks)
    {

     default:
       if (msg) wprt ("Can't find start jump or file format incorrect\n");
       ans = -2;
       break;

     case 1:                      // single bank;
       banks[0].bank = 8;
       datbank = 8;
       break;

     case 2:                      // 2 bank;
       banks[0].bank = 1;
       banks[1].bank = 8;
       break;

     case 4:

       banks[0].bank = 0;
       banks[1].bank = 1;
       banks[2].bank = 8;
       banks[3].bank = 9;
       break;
     }



    for (end = 0; end < numbanks; end++)
      {
       if (banks[end].used == 1)
         {         //  not loopback jump, so this is code start
          if (codbank)
            {
             if (msg) wprt ("Bank %d should start with loopback jump\n", banks[end].bank);
             ans = -4;
            }
          else codbank = banks[end].bank;
         }
       }

    // NOT EVER A BANK 9 - USE ALTERNATE ORDER 0,1,9,8 if reqd.

    if (codbank == 9)
        {
         // swop 8 and 9 over
          banks[2].bank = 9;
          banks[3].bank = 8;
          codbank = 8;
        }


    if(codbank != 8)
     {
      if (msg) wprt ("Can't find start jump or file format incorrect\n");
      ans = -2;
     }

 
  // do trailing 0xff  should allow for a non 0xff char or two ??
  // but KCA3 has a single end not ffff


 for (i = 0; i < NC(banks); i++)
     {
      if (banks[i].used)
       {
        bytes = 0;
        for (end = banks[i].end; end > banks[i].start; end--)
            {
             if (ibuf[end] != 0xff) bytes++;
             if (bytes > 2) break;
            }
      if (end < banks[i].end)
         {
         banks[i].tend = end+bytes;

 if (msg) {
         add_cmd (pcof(banks[i].tend+1,0), banks[i].bank, 0, 0, pcbend(banks[i].bank), C_DFLT, 1);
         set_xcode (pcof(banks[i].tend+1,0), pcbend(banks[i].bank), banks[i].bank,1);
         }
         }
     }

     }

     i = g_val (0x2060,8,2,0);
 if  (i == 0x108 && ans == 1)
       {
        ans = 3;  // single bank 8065, rbase at 2060
        cmdopts |= H;
       }
 return ans;
}

short init_structs(void)
 {
  short i;

  for (i = 0; i < 5; i++) anames[i].nval = 1;
  for (i = 0; i < NC(banks); i++) {banks[i].used = 0; banks[i].cmd = 0;}

  for (i =0; i < 8; i++)
   {
    opstab[i].xpc = 0;	     //current and last operands
    opstab[i].name = 0;
    opstab[i].flags = 0;
   }   

  anlpass = 1;			// number of passes done so far
  progmkr = 0;
  phmarker = 0;
  hwend = PCORG;
  ckend = PCORG;
  gcol  = 0;
  depth = 0;
  jdepth = 0;
  tabreg = 0;
  funcreg = 0;
  sizereg = 0;
  cmdopts = 0;             


 // nall = 0;
  maxalloc   = 0;          // malloc tracing
  curalloc   = 0;
  mcalls = 0;
  mrels = 0;
  pcalls = 0;
  ocalls = 0;
  xcn =0;

  cmntpc = 0;

  initch(&mblocks);        // malloc tracker
  initch(&cmdch);          // command chain
  initch(&scanch);         // scan chain
  initch(&inhb);           // inhibit code/scan chain
  initch(&jpftab);         // jump table (from)
  initch(&jpttab);         // jump table (to)
  initch(&symtab);         // symbol table
  initch(&subtab);         // subroutine table
  initch(&sigtab);         // signs
  initch(&tsigtab);        // aux signs
  initch(&rbase);          // BASE displacement regs
  initch(&symwtab);         // write symbol table


  spl.wds = (WDS*) mem(0,0,sizeof(WDS)*50);
  if (!spl.wds) {wprt ("Can't allocate cmd buffer"); return 1;}
  spl.nptrs = 50;
  watch = (ushort *) mem (0,0,7680*2);
  if (!watch) {wprt ("Can't allocate watch buffer"); return 1;}

  return 0;
}




/***************************************************************
 *  disassemble EEC Binary
 ***************************************************************/
short dissas (void)
{
  long i;
  ptime(1);

  i = init_structs();
  if (i) return 0;

  ptime(2);
  wprt ("\n\n------------ START Disassembly ------------\n");
  if (readbin(1) < 0)
    {
     tidy_exit(1);
     return 0;
    }

  dprt ("\n\n---------evaluate checksum ------------\n");
  verify_chk ();
  prt_bnks();

  dprt("\n\n----- Read commands from .dir file ---------\n");
  getudir();
  ptime(3);

  dprt("\n\n----- Scan for initial signatures ---------\n");
  scan_init();

  ptime(4);
  dprt ("\n\n------------Code and data scan ------------\n");
  prt_opts(PDBGM);              //dbg);
  anlpass ++;
  show_prog (0, anlpass,fillen);
  scan_all ();   // Ok all by block....

  ptime(5);
  prt_dirs ();  // temp

  // ----------------------------------------------------------------------
  fix_tabfuncs();
  ptime(6);
  do_jumps ();
  ptime(7);
  // ----------------------------------------------------------------------
  show_prog (0, anlpass,fillen);
  if (PDBGM) prt_commands ();                // dbg

  dprt ("\n\n------------ Outputting code to %s------------\n",FNin);
  rprt ("\n## ------------ disassembly listing (806%c) ------------\n", (P8065) ? '5' : '1' );

  do_listing ();
  rprt (0);     //output file

  // must remember to drop subs with no name ...
  prt_dirs ();

  prt_jumps (&jpftab);
  prt_sigs(&sigtab,1);
  ptime(8);
  tidy_exit(1);

  return 1;
}


short openfiles(void)
{

  fin = fopen(FNin, "rb");

  if(fin == NULL)
    {  wprt ("Can't open input file %s\n", FNin);
       return 1;
    }

  fout = fopen(FNout, "w");
  if (fout == NULL)
   {   wprt ("Can't open output file %s\n", FNout);
	return 2;
   }
   
  fwrn = fopen(FNwrn, "w");
  if(fwrn == NULL)
     {   wprt ("Can't open warnings file %s\n", FNwrn);
	 return 3;
     }

  fdir = fopen(FNdir, "r");        /* don't stop if can't open dir file */
  fcmt = fopen(FNcmt, "r");        /* don't stop if can't open comment file */

  return 0;
}

char *filedets(void)
 {
 short nb, i;
 char *t;
 fin = fopen(FNin, "rb");

 if(fin == NULL) return NULL;

 if (init_structs())
    {
      tidy_exit(0);
      return NULL;
    }

 t = flbuf;
 nb = readbin(0);         // no warning msgs
 if (nb < 0)
    {
     t += sprintf(t,"File is Corrupted or not an EEC binary");
     tidy_exit(0);
     return flbuf;
    }

 t += sprintf(t,"File is a ");
 if (nb == 1 ) t += sprintf(t,"single Bank 8061");
 if (nb == 2 ) t += sprintf(t,"2 Bank 8065");
 if (nb == 3 ) t += sprintf(t,"Single Bank 8065");
 if (nb == 4 ) t += sprintf(t,"4 Bank 8065");

 t += sprintf(t,"\nFile Map - ");
 t += sprintf(t,"\nFileaddr     progaddr   bank");

 for (i = 0; i < NC(banks); i++)
   {
    if (banks[i].used)
      {
       t += sprintf(t,"\n%05lx-%05lx  2000-%4lx  %d",
       banks[i].start, banks[i].end,  banks[i].tend- banks[i].start + 0x2000, banks[i].bank);
      }
   }

  tidy_exit(0);
  return flbuf;
}
