

/******************************************************
 *  8061 advanced disassembler for EEC-IV
 *
 * This program is for private use only.
 * No liability of any kind accepted or offered.
 *
 *******************************************************

 Signature matching code

 *****************************************************
 *  Declarations and includes
 ******************************************************/

#include "core.h"

//extern ushort *watch;         // TEMP
extern long  fillen;
extern ushort dbank(short);
extern short anlpass;
extern long  cmdopts;
extern short depth;
extern short tabreg;
extern short funcreg;
extern short sizereg;             // for tracking over jumps (tables & funcs)

extern CHAIN sigtab;
extern CHAIN tsigtab;       //temp holder
extern CHAIN scanch;
extern CHAIN cmdch;
extern CHAIN jpttab;

extern BKS banks[5];              // index [4] for bank copying, swopping order

extern void clearch (CHAIN *);
extern void *gnxtch(CHAIN *);
extern void strtch(CHAIN *);
extern void *find (CHAIN *, ulong, ushort, short);
extern void *chain(CHAIN *, void *);
extern void* cmem (CHAIN *);

extern SXT*  get_subr(ushort, ushort);
extern CADT* add_ext (void *);
extern void  zeroflgs(CADT *);
extern long  g_val (long , short, short);
extern long  g_val (ushort, ushort, short, short);
extern void  dprt (char *, ...);
extern void  wprt (char *, ...);
extern uchar get_byte (long);
extern long  get_watch(short,short);
extern long  decode_addr(CADT *, long);
extern LBK*  add_cmd  (ushort, ushort, ushort, ushort, ushort, char, ushort);
extern LBK*  add_scan (ushort, ushort, ushort, ushort);
extern SXT*  add_subr (long, ushort, ushort);
extern void  upd_sym(char *, ushort, ushort, short);
extern void  scan_code (LBK *);             //, short);
extern RBT*  add_rbase(long , long);
//extern void  set_xcode (long, long, short);


extern SYT*  get_sym(ushort, ushort, short);
extern SYT * add_symn (short, ushort,ushort, short);
extern SYT * add_sym (char *, ushort,ushort, short);
extern void  do_subname(SXT *);
extern long  ofpc(ushort, ushort);
extern ushort pcof(long, ushort *);
extern short iaddr(ushort, ushort);

extern void show_prog(long, short,long );         /* links out to graphic modules */



/* Signature index for like instructions
 0  other 1  clr  2  neg  3  shift   4  dec/inc 5  and 6  add  7  sub 8  mult 9  or 10 cmp
11 div 12 load  13 sto 14 push 15 pop 16 sjump 17 scall 18 jb/jnb 19 cjmp (conditional) 20 ret
21 set/clear carry

40 are always optional (Di, Ei, NOP, popp,pushp, smul)
56, 57 are long versions of sjump, scall - 58 is skip

8065 extras
41 optional 8065 only
42  rbnk


NB - set rambanks as ignore for now..
*/

// ---------------- add 8061/8065 cleverness

uchar sigix[256] =
{
// 0   1   2   3   4   5   6   7   8   9   a   b   c   d   e   f
  58,  1,  1,  2,  0,  4,  0,  4,  3,  3,  3,  0,  3,  3,  3,  0,    // 00 - 0f
  42,  1,  2,  2,  0,  4,  0,  4,  3,  3,  3,  0,  0,  0,  0,  0,    // 10 - 1f
  16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 17, 17, 17, 17,    // 20 - 2f
  18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18,    // 30 - 3f
   5,  5,  5,  5,  6,  6,  6,  6,  7,  7,  7,  7,  8,  8,  8,  8,    // 40 - 4f
   5,  5,  5,  5,  6,  6,  6,  6,  7,  7,  7,  7,  8,  8,  8,  8,    // 50 - 5f
   5,  5,  5,  5,  6,  6,  6,  6,  7,  7,  7,  7,  8,  8,  8,  8,    // 60 - 6f
   5,  5,  5,  5,  6,  6,  6,  6,  7,  7,  7,  7,  8,  8,  8,  8,    // 70 - 7f
   9,  9,  9,  9,  9,  9,  9,  9, 10, 10, 10, 10, 11, 11, 11, 11,    // 80 - 8f
   9,  9,  9,  9,  9,  9,  9,  9, 10, 10, 10, 10, 11, 11, 11, 11,    // 90 - 9f
  12, 12, 12, 12,  6,  6,  6,  6,  7,  7,  7,  7, 12, 12, 12, 12,    // a0 - af
  12, 12, 12, 12,  6,  6,  6,  6,  7,  7,  7,  7, 12, 12, 12, 12,    // b0 - bf
  13,  0, 13, 13, 13,  0, 13, 13, 14, 14, 14, 14, 15,  0, 15, 15,    // c0 - cf
  19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19,    // d0 - df
  19,  0,  0,  0,  0,  0,  0, 56,  0,  0,  0,  0,  0,  0,  0, 57,    // e0 - ef
  20, 20, 40, 40, 40, 41, 41, 41, 21, 21, 40, 40, 40, 41, 40, 40     // f0 - ff

};





// check each bank start jump

SIGN initial[] = {16,  0xA0, 0x06, 0x20};             // treat as single sjmp
PAT hdr = {initial, "INIT", 2, 1, 0, 0, 0, 0, 1, 1, 0 };  // type zero

// rbase (cal pointer) signature

SIGN rbsg [] = {       // rbase array code
12, 0x80, 0xf0, 1,    0, 0,     0x18, 2,               //ldw   R18,f0
42, 0xc0, 0x8,  15,                                    // opt rbnk for 8065
12, 0x80, 0x1,  0,    0x20, 3,  0x20, 4, 0x1a, 5,      // ldb   R1a,[2020];
42, 0xc0, 0x8,  15,                                    // opt rbnk for 8065, save bank in 15
12, 0x80, 0x15, 0x16, 0x1c, 7,                         // ldw   R1c,[R14++]
13, 0x80, 0x19, 0x12, 0x1c, 7,                         // stw   R1c,[R18++]
19, 0x80, 0x1a, 5,    0xf7, 0x20                       // djnz  R1a,d477
};



// ignore int signature

SIGN ignint[] = {20,  0x80};             // reti or retei  - for ignore int

PAT ign = {ignint, "IGNINT", 1, 1, 0, 0, 0, 0, 1, 1, 0};    // type zero

//  timer signature  - this works for aa through to A9L to C3P2

 // may need opcodes sooner to confirm bits for word/byte/sec/msec etc etc   ??
//  save contents of R30 for timer list start

SIGN timer [] = {
12, 0x80, 0x31, 0x11, 0x3c, 0x2,        //ldb   R3c,[R30++]
10, 0x80, 0,    0,    0x3c, 0x2,        //cmpb  R3c,0
19, 0x80, 0x55, 0x20,                   // je    +55      # end of list, return
12, 0x8e, 0x31, 0x11, 0x32, 0x23,        // ldzbw R32,[R30++] ** here is 2nd byte for a9l
18, 0x80, 0x3c, 0x2,  0x12, 0,          // jnb   B0,R3c,3e93    # 2/3 word entry, skip mask check
12, 0x80, 0x31, 0x11, 0x3d, 0x3,        // ldb   R3d,[R30++]    # 4/5 word entry, get flags mask
12, 0x80, 0x31, 0x11, 0x34, 0x4,        // ldzbw R34,[R30++]    # get actual flags/register
5,  0x80, 0x34, 0x4,  0x3d, 0x3,        // an2b  R3d,[R34]      # and mask them
18, 0x80, 0x3c, 0x2,  0x4,  0,          // jnb   B3,R3c,3e91    # Result <> 0 to count
19, 0x80, 0x4,  0,                      // je    +4             # Result == 0 to count
16, 0x80, 0xe2, 0x20,                      // sjmp  (back to start)
19, 0x80, 0xe0, 0x20,                      // je    (back to start)
5,  0x80, 0x3c, 0x2,  0x3e, 0x5, 0, 0,  // an3b  0,R3e,R3c      # mask for time bits.
19, 0x80, 0xda, 0x20,                      // je    (back to start) # No time bits overlap - skip count
18, 0x80, 0x3c, 0x2,  0x5,  0,          // jnb   B1,R3c
12, 0x80, 0x32, 0x3,  0x36, 0x6,        // ldw   R36,[R32]   # Count size is word
16, 0x80, 0x3,  0,                      // sjmp  +3
12, 0x80, 0x32, 0x3,  0x36, 0x6,        // ldsbw R36,[R32]   # Count size is byte
18, 0x80, 0x3c, 0x2,  0x4,  0,          // jnb  B2,R3c,+4  # up or down
2,  0x80, 0x36, 0x6,                    // negw  R36       # Negate if counting DOWN
};
//function and table lookup sub signature prefix

SIGN sbpre1[] = {

9 , 0x80, 0x02, 0xd,  0xf6, 3,     // orb   Rf6,n
9 , 0xc0, 0x02, 0xe,  0xf6, 3,     // orb   Rf6,n
16, 0xa0, 0x06, 0x20               // sjmp, x - must hit master
};

SIGN sbpre2 [] = {     // alternate bit sets for signed/unsigned

12, 0x80, 1,   14,  0x22, 3,     // ldb   R22,1
16, 0xa0, 0x0c, 0x20            // sjmp  x - to master

};

SIGN fnlu[] = {      //  byte AND WORD function lookup signature

10 ,0x80 ,0x32, 1    ,0x02, 2 , 0x34,8 ,   // cmpb/w  R34,[R32+2] or 4
18 ,0x9d ,0xf6, 3    ,0x04, 0 ,            // jnb   B1,Rf6,x  - Signed IN ?
19 ,0x80 ,0x0a, 0    ,                     // jc    x
16 ,0x80 ,0x02, 0    ,                     // sjmp  x
19 ,0x80 ,0x06, 0    ,                     // jge   x
6  ,0x80 ,0x02, 2   ,0x00, 0 , 0x32,1 ,   // ad2w  R32,2 (or 4)
16 ,0x80 ,0xed, 0x20 ,                     // sjmp  x
5  ,0xc0 ,0xdf, 0x20 ,0xf6, 0x3,          // optional  an2b RF6
12 ,0x80 ,0x33, 0x11 ,0x36, 6 ,            // ldb   R36,[R32++]
12 ,0x80 ,0x33, 0x11 ,0x38, 7 ,            // ldb   R38,[R32++]
7  ,0x80 ,0x32, 1    ,0x36, 6 ,            // sb2b  R36,[R32]
7  ,0x80 ,0x33, 0x11 ,0x34, 8 ,            // sb2b  R34,[R32++]
7  ,0x80 ,0x32, 1    ,0x38, 7 ,            // sb2b  R38,[R32]
18 ,0x9e ,0xf6, 3    ,0x04, 0 ,            // jnb   B1,Rf6,x   THIS is signed OUT
19 ,0x80 ,0x09, 0    ,                     // jc, x
16 ,0x80 ,0x02, 0    ,                     // sjmp, x
19 ,0x80 ,0x05, 0    ,                     // jge. x
9  ,0x80 ,0x01, 0x20 ,0xf6, 3 ,            // orb, f6, 1
2  ,0x80 ,0x38, 7    ,                     // negb R38
8  ,0x80 ,0x34, 8    ,0x38, 7 ,            // ml2b  R38,R34
11 ,0x80 ,0x36, 6    ,0x38, 7 ,            // divb  R38,R36
18 ,0x80 ,0xf6, 3    ,0x02, 0x20,          // jnb B0,Rf6, x
2  ,0x80 ,0x38, 7                         // negb R38
};


// table signatures

SIGN subtb2 [] = {    // scaled table lookup (prefix)

1, 0x80, 0x31, 0,                 //clrb R31       scaled
3, 0x80, 0x04, 0, 0x30, 0,        //shlw R30,4
1, 0x80, 0x33, 0,                 //clrb R33
3, 0x80, 0x04, 0, 0x32, 0,        //shlw R32,4
16,0xa0, 0x03, 0x20              // sjmp to master
};


SIGN  tblu [] = { // table lookup signed & unsigned

5 , 0xc0 ,0xfe,0x20 ,0xf7, 3,            // an2b rf7, fe    optional signed
8 , 0x80 ,0x33,3 ,0x34,2 ,0x36,4 ,     // ml3b  R36,R34,R33
6 , 0x80 ,0x31,8 ,0x36,4 ,             // ad2b  R36,R31
6 , 0xC0 ,0x00,0 ,0x37,5 ,              // adcb  R37,0  OPT   Late LU
19, 0xC0 ,0x02,0 ,                      // jnc carry   OPT   Early LU
4 , 0xC0 ,0x37,5 ,                      // incb R37    OPT   Early LU
6 , 0x80 ,0x36,4 ,0x38,1 ,             // ad2w  R38,R36
12, 0x80 ,0x39,0x11 ,0x31,8 ,             // ldb   R31,[R38++]
12, 0x80 ,0x38,1 ,0x33,3 ,             // ldb   R33,[R38]
17, 0x80 ,0x1c, 0x20 ,                 // interpolate
6 , 0x80 ,0x34,2 ,0x38,1 ,             //   ad2w  R38,R34
12, 0x80 ,0x38,1 ,0x33,3 ,             //   ldb   R33,[R38]
4 , 0x80 ,0x38,1 ,                     //   decw  R38
12, 0x80 ,0x38,1 ,0x31,8 ,             //   ldb   R31,[R38]
12, 0x80 ,0x3a,7 ,0x34,3 ,             //   ldw   R34,R3a
17, 0x80 ,0x0c,0x20                     // interpolate
};

SIGN tblu2 [] = {  // later table lookup

8 , 0x80 ,0x37,6 ,0x38,2 ,0x3a,3 ,         // ml3b R3a, R38, R37
6 , 0x80 ,0x35,4 ,0x3a,3 ,                 // ad2b R3a, R35
6 , 0x80 ,0x00,0 ,0x3b,9 ,                 // adcb R3b, 0
6 , 0x80 ,0x3a,3 ,0x3c,1 ,                 // ad2w R3c, R3a
12, 0x80 ,0x3c,0x11 ,0x35,4 ,                 // ldb  R35, [R3c++]
12, 0x80 ,0x3c,1 ,0x37,6 ,                 // ldb  R37, [R3c]
6 , 0x80 ,0x38,2 ,0x3c,1 ,                 // ad2w R3c, R38
12, 0x80, 0x34,7 ,0x39,8 ,                 // ldb  R39, R34
12, 0x80, 0x36,10 ,0x3b, 9,                // ldb  R3b, R36
17, 0x80 ,0x1c, 0x20 ,                     // interpolate();
12, 0x80 ,0x3c,1 ,0x37,6 ,                 // ldb R37, [R3c]
12, 0x80, 0x3c,1 ,0xff, 0, 0x35, 4,        // ldb R35, [R3c+ff]
12, 0x80 ,0x3e,11 ,0x3c,1 ,                // ldb R3c, R3e
17, 0x80 ,0x0c,0x20 ,                      // interpolate
12, 0x80 ,0x3e,11 ,0x36,10,                // ldw R36, R3e
12, 0x80 ,0x3c,1 ,0x34,7 ,                 // R34 = R3c
12, 0x80 ,0x3b,9 ,0x39,8                   // R39 = R3b
};







SIGN sshift [] = {   // stack arguments version of func lookups - SINGLE LEVEL

15, 0x80, 0x36, 6,                      //popw  R36
12, 0x80, 0x37, 0x16,  0x32, 1,        // ldb   R32,[R36++]
12, 0x80, 0x37, 0x16,  0x33, 9,        // ldb   R33,[R36++]
12, 0x80, 0x33, 9,     0x34, 2,        // ldzbw R34,R33
5,  0x80, 0xf, 0,      0x33, 9,        // an2b  R33,f
3 , 0x80, 4,   0,      0x34, 2,        // shrw  R34,4
6 , 0x80, 0x35, 0x12,  0xf0, 3, 0, 0, 0x32, 1,       // ad2w  R32,[R34+f0]
12, 0x80, 0x37, 0x16,  0x34, 2,        // ldb   R34,[R36++]
12, 0x80, 0x37, 0x16,  0x35, 10,       // ldb   R35,[R36++]
14, 0x80, 0x36, 6,                     // pushw R36
12, 0x80, 0x34, 2,     0x34, 2         // ldw   R34,[R34]

};

SIGN sub1 [] = {  // separate subr for stack params and others ?

17, 0xA0, 0 , 0x20,            // scall - keep address
12, 0x80, 38, 1 ,38, 1,        // ldb   R38,[R38]
16, 0xA0, 0, 0x20,             // skip (jump) - keep address
};

// multibanks do a SUBR call with direct stack access (R20)

SIGN sts3 [] = {  // multibank stack params 8065 - this is a GRANDCALLER extract....

12, 0x80, 0x20, 0, 2, 0, 0x36 , 1,        // ldw   R36,[R20+2]
12, 0x80, 0x20, 0, 4, 0, 0x3a , 2,        // ldw   R3a,[R20+4]
             //2f9b: f2                      pushp
             //2f9c: fa                      di
3,  0x80, 2, 0, 37, 0x11,                 // shrb  R37,2
12, 0x80, 0x37, 0x11, 0x11, 0,            // ldb   R11,R37
12, 0x8e, 0x3a, 0x12, 0x36, 0x20,         // ldb   R36,[R3a++] with  repeat
12, 0x80, 0x11, 0, 0x11, 0,               // ldb   R11,11  bank_sel register
              // 2fb2: f3                    popp
13, 0x80, 0x20, 0, 4, 0, 0x3a, 2         // stw   R3a,[R20+4]

};


/* enc2 encode is - (EARS)

 6b46: ac,33,34          ldzbw R34,R33        R34 = (uns)R33;
6b49: 71,0f,33          an2b  R33,f          R33 &= f;
6b4c: 08,04,34          shrw  R34,4          R34 = R34 / 10;
6b4f: 67,35,f0,00,32    ad2w  R32,[R34+f0]   R32 += [R34+f0];

*/






SIGN encd4 [] = { // encoded addresses type 4 and 2
12, 0x80, 0x37, 0x11, 0x3a, 2,             // ldzbw R3a,R37;
5, 0x80, 0x1f, 3, 0x37, 0x11,              // an2b  R37,0x1f (4) or 0xf (2)
3, 0x80, 0x04, 0, 0x3a, 2,                 // shrw  R3a,4
5, 0xC0, 0x0e, 0, 0x3a, 2,                 // an2b  R3a,e     not in type 2
6, 0x80, 0x3b, 0x12, 0xf0, 5, 0,0, 0x36,1 // R36 += [R3a+f0];
};

SIGN encd3 [] = { // encoded addresses type 3 (A9L etc)

12, 0x80, 0x3e, 1,  0x42, 2,            // ldw   R42,[R3e]
18, 0x80, 0x43, 3,  0x14, 0x20,         // jnb   B7,R43,3cda
12, 0x80, 0x43, 3,  0x3a, 4,            // ldzbw R3a,R43
5,  0xc0, 0xf , 0,  0x43, 3,            // an2b  R43,f    optional  here
5,  0x80, 0x70, 0,  0x3a, 4,            // an2b  R3a,70
3,  0x80, 0x3,  0,  0x3a, 4,            // shrw  R3a,3
5,  0xc0, 0xf , 0,  0x43, 3,            // an2b  R43,f    or can be here
6,  0x80, 0x3b, 0x14, 0xf0, 5,  0, 0, 0x42, 2,      // ad2w  R42,[R3a+f0]
13, 0x80, 0x3e, 1,  0x42, 2             // stw   R42,[R3e]
};

SIGN encd1 [] = { // encoded addresses type 1 (A9L etc)

18, 0x80, 0x43, 3,  0x14, 0x20,         // jnb   B7,R43,3cda
12, 0x80, 0x43, 3,  0x3a, 4,            // ldzbw R3a,R43
5,  0xc0, 0xf , 0,  0x43, 3,            // an2b  R43,f    optional  here
3,  0x80, 0x3,  0,  0x3a, 4,            // shrw  R3a,3
5,  0x80, 0xfe, 0,  0x3a, 4,            // an2b  R3a,fe
5,  0xc0, 0xf , 0,  0x43, 3,            // an2b  R43,f    or can be here
6,  0x80, 0x3b, 0x14, 0xe0, 5,  0, 0, 0x42, 2,      // ad2w  R42,[R3a+f0]
};


SIGN gfm [] = {         // grandfather call modifier
15, 0x8d, 0x1e, 0x21,    // popw  R1e           back up stack by one call
17, 0xA0, 0x17, 0x20,    // [s]call <addr>      call subr
 4, 0x22,                // pars                bytes to copy
14, 0x8e, 0x1e, 0x21     // pushw R1e           push modded return addr
};

//  multiple FIXED word param extract from stack (multiple levels)

SIGN sklc [] = {
15,0x8d, 0x3a, 0x21,                  // popw R3a             with repeat (= level)
12,0x8e, 0x3a, 0x12, 0x3c, 0x20,      // ldb rxx, [R3a++]     with repeat (= params)
14,0xCf, 0x3a, 0x22,                  // pushw                optional with repeat
16,0xD0, 0x03, 0x20                   // sjmp                 optional
} ;

SIGN skmp [] = {
// sklc can occur here as a prefix

15, 0x8d, 0x42, 0x23,                  //popw  R42
12, 0x8e, 0x43, 0x13, 0x3b, 4,         //ldb   R3b,[R42++]
13, 0x80, 0x17, 0x15, 0x3b, 4,         //stb   R3b,[R16++]
19, 0x80, 0x3a, 2,    0xf7, 0,         //djnz  R3a, <to ldb>
14, 0x80, 0x42, 3,                     //pushw R42
//14, 0x80, 0x3c, 1                      //pushw R3c
};



SIGN carry [] = {   // for set/carry type funcs (various)
21, 0x80,                          // clear carry
16, 0xa0, 0x06, 0x20,             // sjmp, x
21, 0x80                          // set carry
};

// add 8061 /8065 intelligence and opcode skip
//flags - m or p, subr match, jump match, end match, sub reqd, 8061/8065, ptype

PAT patterns[] = {
{rbsg,   "RBASE", NC(rbsg),    1, 0, 0, 0, 0, 0, 1, 1, 5 },  // master rbase lookup
{fnlu,   "FnLU",  NC(fnlu),    1, 0, 0, 0, 0, 1, 1, 1, 1 },  // master byte or word lookup
{tblu2,  "TBL2",  NC(tblu2),   1, 0, 0, 0, 0, 1, 1, 1, 2 },  // master table lookup B , later multibank
{tblu,   "TBLU",  NC(tblu),    1, 0, 0, 0, 0, 1, 1, 1, 2 },  // master table lookup A
{sbpre2, "LUP3",  NC(sbpre2),  0, 0, 1, 0, 0, 1, 1, 1, 1 },  // jump linkd unsigned prefixes
{sbpre1, "LUP2",  NC(sbpre1),  0, 0, 1, 0, 0, 1, 1, 1, 1 },
{sbpre1, "LUP1",  6,           0, 0, 0, 1, 0, 1, 1, 1, 1 },
{carry,  "STC",   NC(carry),   0, 0, 1, 0, 0, 1, 1, 1, 4 },  // carry flag as signed/unsigned
{subtb2, "FLUSC", NC(subtb2),  0, 0, 1, 0, 0, 1, 1, 1, 2 },  // scaled lookup
{sshift, "STS1",  NC(sshift),  0, 0, 0, 1, 0, 1, 1, 1, 6 },  // func params via stack shift
{sub1,   "SUBR" , NC(sub1),    0, 1, 1, 0, 0, 1, 1, 1, 3 },  // params via stack_shift and/or encode via proc
{sts3,   "STS3" , NC(sts3),    0, 0, 0, 0, 0, 1, 1, 1, 7 },  // cross bank param getter and stack fix
{encd1,  "ENC1",  NC(encd1),   1, 0, 0, 0, 0, 1, 1, 1, 11},  // encoded address type 1,
{encd3,  "ENC3",  NC(encd3),   1, 0, 0, 0, 0, 1, 1, 1, 13},  // encoded address type 3,
{encd4,  "ENC42", NC(encd4),   1, 0, 0, 0, 0, 1, 1, 1, 14},  // encoded address type 4 and 2,
{gfm ,   "GRNF",  NC(gfm),     1, 0, 0, 0, 0, 1, 1, 1, 10},  // grandfather params (extra pop)
{skmp,   "VPar",  NC(skmp),    1, 0, 0, 0, 0, 1, 1, 1, 9 },  // remote and local variable par POPper
{sklc,   "FPar",  NC(sklc),    1, 0, 0, 0, 0, 1, 1, 1, 8 },  // fixed params, variable level
{timer,  "TIMER", NC(timer),   1, 0, 0, 0, 0, 1, 1, 1, 20}
};


void prt_sigs(CHAIN *x, short prd)
{
 short i;
 ushort pc, bank;
 SIG *y;
 dprt("-----------Signatures----------\n");

 strtch(x);
 if (x->num > 0 && prd) dprt("ofset    start   end  jump  subr m  p d  name\n");


 while (y = (SIG*) gnxtch(x))
    {
      if (prd || (y && !y->f.O61P))
        {
         pc = pcof(y->ofst, &bank);
         //dprt("%5lx (%d|%4lx) e %5lx j %5lx s %5lx  m %d p %2x prcd %d %s  ",
         dprt("%5lx (%d|%4lx) %5lx %5lx %5lx %d %2x %d %5s  ",
         y->ofst, bank, pc, y->end, y->jump, y->subr, y->f.mtype, y->f.ptype, y->f.O61P, y->name);
         for (i = 0; i < 16; i++) dprt("%2x," , y->v[i]);
         dprt("\n");
        }
    }
}

void copysigs(SIG *master)
 {
  // copy temp sigs to real sigs....
  short i;
  SIG  *z, *x;
  // copy master FIRST and then assign links !!

  master->f.O61P = 0;
  z = (SIG *) cmem(&sigtab);
  *z = *master;
  master = z;
  z->master = master;
  z = (SIG*) chain(&sigtab,z);
  if (z) master = z;

  // now do the pre sigs
  for (i = 0; i < tsigtab.num; i++)
    {
     x = (SIG*) tsigtab.ptrs[i];
     if (x == master) continue;
     x->f.O61P = 0;
     z = (SIG *) cmem(&sigtab);
     *z = *x;
     z->master = master;
     chain(&sigtab,z);
    }
}

SIG *add_sign (long ofst, PAT *ptn, char *sgv, long *adds)
{             // saves to asigtab
  SIG x, *z, *ans;
  short j;

  if (anlpass >= ANLPRT) return 0;

   x.ofst = ofst ;
   x.end  = adds[0];
   x.jump = adds[1];
   x.subr = adds[2];



   strncpy(x.name, ptn->name, 15);
   x.name[15] = 0;
   x.f = ptn->f;
   x.f.O61P = 0;        // mark as unprocessed
   for (j = 0; j < 16; j++) x.v[j] = sgv[j];

  // chain sig into tempchain

  z = (SIG *) cmem(&tsigtab);
  *z = x;  // copy sig
  ans = (SIG*) chain(&tsigtab,z);

  if (ans) return ans;    // duplicate
  return z;
 }

// equiv of prt_lev, for data access marking, pass 1 only...

long chk_pars(SXT* sub, ushort pc, short bank, int cnt, short pno)
{
 short i,lev,p,lcnt, size;
 long end, val, ofst, ans;
 CADT *addnl;

 if (!sub) return 0;

 addnl = sub->addnl;

 ofst = ofpc(pc+cnt, bank);
 end = ofst + 32;   // safety stop

 lev = 0;
 p = 0;    // param number
 ans = 0;
 while (addnl && lev < MAXLEVS ) {

   lcnt = addnl->f.cnt;

   for (i = 0; i < lcnt; i++)
     {

     if (ofst > end) break;     // safety - force exit
     val = decode_addr(addnl, ofst);   // val with decode if nec.
     p++;
     if (p == pno) ans = val;
     if (!pno && val > 0xFF )
        {    // not a register or param request

         size = 1;
         if (addnl->f.foff) size = addnl->f.foff;  // offset size always overrides
         else size = addnl->f.esize;

         if (size == 1)
           add_cmd (val, dbank(0), pc, bank, val, C_BYTE, 0);  // with guess
         else
           add_cmd (val, dbank(0), pc, bank, val + 1, C_WORD, 0);

         }

     ofst += addnl->f.esize;
     }
   lev++;
   addnl = addnl->next;
  }

  return ans;
}





        // params from blk
void do_substructs(SXT *sub, LBK *blk, ushort pc, short *cnt)
{
 ushort adr, szr ;
 LBK *lblk;
 CADT *adnl;
 LSCN *ln;
 SXT *xsub;    // remote or target subr
 if (!sub) return;
 if (anlpass >= ANLPRT) return;

 lblk = blk;
 adnl = NULL;
 xsub = NULL;

 dprt("SUBR type %d (%d|%lx) levs % d from %d|%lx\n", sub->ptype, sub->bank,sub->pc,sub->levels, blk->bank,pc);

 // generic level decoder for ALL subrs

 szr = sub->levels;  // no of levels for grandcaller stuff

 switch (szr)
   {
    case 0:           // level 0 - no args
    case 1:           // level 1 - local args, at end of this subr code
       xsub = sub;
       break;

    default:          // level 2 or higher remote args, {grand} caller subr
       while (lblk && szr-- > 2)
         {
          ln = (LSCN*) lblk->addnl;
          if (!ln) lblk = 0;
          lblk = ln->tprev;
         }
       // fall through
    case 2:
       if (lblk) xsub = get_subr(lblk->start, lblk->bank);      // this is caller subr at right level
       break;
   }

 if (!xsub || xsub->cmd) //     break;    //  no changes allowed or not exist, etc
  {
   chk_pars(sub,pc,blk->bank,*cnt,0); // chk_pars(sub,pc,dbank(0),*cnt,0);
  *cnt+=sub->size;
  return;
  }



 switch (sub->ptype & 0x3f)    // sub is subr called
   {
   case 8:    // fixed pars of multiple level

     adnl = xsub->addnl;
     if (!adnl)
        {
         adnl = add_ext(xsub);
         adnl->f.esize = 1;
         adnl->f.cnt   = sub->adreg;          // no of args
         xsub->cmd = 0;                       // set guess
         adnl->f.hex = (PHEX)? 1: 0;
         xsub->size = adnl->f.esize * adnl->f.cnt;
         if (sub->addnl)
           {
            adnl->f.enc = sub->addnl->f.enc;    // could be an encoded proc
            adnl->divisor = sub->addnl->divisor;
            adnl->f.name = sub->addnl->f.name;
           }
        }
     else
        {                   // this doesn't work if different calls, add extra level instead ?
         if (!sub->cmd && szr > 1)         // guess
           {      // not if local caller
            if (adnl->f.esize > 1)
             {
             adnl->f.cnt *= adnl->f.esize;
             adnl->f.esize = 1;
             }                     // set bytes for addition
           adnl->f.cnt+=sub->adreg;
           }
        }
     xsub->size = adnl->f.cnt*adnl->f.esize;     // Always keep main sub entry in sync, always bytes

     if (!(xsub->size&1))
       { // even count, expect WORDS
        adnl->f.esize = 2;
        adnl->f.cnt = xsub->size/2;
       }

     dprt ("adjust subr %lx (via GF 8 %lx) to %d\n", xsub->pc,sub->pc,xsub->size);
     break;


    case 9 :               // get grandcaller stack params
     if (sub->cmd)  break;        // no changes if by command

     adr = g_val (pc+*cnt,blk->bank,1,0);  // get no of arguments (local)

     if (xsub->ptype == 10)
      {
      dprt ("SKIP adjust subr %lx (type 10 calls type 9)\n", xsub->pc);
      break;
      }

     adnl = add_ext(xsub);
     adnl->f.esize = 1;
     adnl->f.cnt   = adr;            // no of args
     xsub->cmd = 0;                 // guess = 1;
     adnl->f.hex = (PHEX)? 1: 0;
     xsub->size = adnl->f.cnt;

     if (sub->addnl)
            {
            adnl->f.enc = sub->addnl->f.enc;   // could be an encoded proc
            adnl->divisor = sub->addnl->divisor;
            }

     if (!(adr&1))
      { // even count, expect WORDS
        adnl->f.esize = 2;
        adnl->f.cnt /= 2;
      }

     dprt ("adjust subr %lx (calls type 9) to %d\n", xsub->pc,xsub->size);

     break;   // end case 9



   case 10:    // grandcaller sig, number in pattern

     adnl = add_ext(xsub);
     adnl->f.esize = sub->szreg;
     adnl->f.cnt   = sub->adreg;
     adnl->f.hex = 1;
     xsub->cmd = 0;              //guess = 1;
     adnl->f.hex = (PHEX)? 1: 0;
     xsub->size = adnl->f.esize * adnl->f.cnt;
     dprt ("adjust GF subr %lx (10) to %d\n", xsub->pc,xsub->size);
     break;


   case 3:               // variable pars from register - rewrite each time

   // need a PARS command here to keep printout straight....

     adr = get_watch(depth,sub->adreg);
     lblk = add_cmd (pc, 0, pc, 0, pc, C_ARGS,0);
     if (lblk)
       {
       adnl  = add_ext(lblk);
       adnl->f.esize = sub->szreg;
       adnl->f.cnt   = adr;
       adnl->f.hex = (PHEX)? 1: 0;
       lblk->size1 = adnl->f.esize * adnl->f.cnt;
       dprt ("Subr %lx type 3 - set ARGS cmd at %d\n", sub->pc,sub->size);
       }
   break;

   case 2:    // table lookup

     adr = get_watch(depth,sub->adreg);
     if (sub->adreg < 16) adr = chk_pars(sub,pc,blk->bank,*cnt,sub->adreg); // stack par
     if (adr == 0)
      {
       dprt("TABLE - Invalid addr = 0 - ignored\n");
       break;
      }

     if (depth > 0 && adr < 255)          // this works on AA ....
       {
        adr = get_watch(depth-1, adr);
        dprt ("TABLE Test Lev %d, uplv = %lx\n", depth, adr);
       }








     // get extended block for tab or func commands

     if (sub->szreg > 0) szr = get_watch(depth,sub->szreg); // only for tables
     if (sub->szreg < 0) szr = -sub->szreg;          // fixed size

     if (szr <= 0 || szr > 64)
       {
       dprt("TABLE invalid col size. default (11) set\n");
       szr = 11;
       }
      // tables always BYTE
     lblk = add_cmd (adr, dbank(0), pc, blk->bank, adr, C_TABLE,0);  //  adr+(szr*2)-1
     if (lblk && !lblk->cmd)
       {
        dprt("WPARS TABLE add=%d|%lx, size=%lx\n", dbank(0), adr, szr);
        add_symn(3,adr, dbank(0), -1);      // auto table name, can fail
        adnl = add_ext(lblk);               // if not duplicate
        lblk->size1 = szr;
        adnl->f.cnt = szr;
        adnl->f.hex = 0;
        adnl->f.nods = 0;
        adnl->f.esize = 1;
        if (sub->ptype & 0x80) adnl->f.sign = 1;
        adnl->f.pfw = 3;
       }
   break;



   case 1:   // func lookups -  funcs have two levels

    adr = get_watch(depth,sub->adreg);
    if (sub->adreg < 16) adr = chk_pars(sub,pc,blk->bank,*cnt,sub->adreg);

    if (adr == 0)
       {
         dprt( "FUNC Invalid address = 0 - ignored\n");
         break;
       }
    if (sub->szreg < 1 || sub->szreg > 4)
       {
       dprt("FUNC invalid size - default (1) set\n");
       sub->szreg = 1;
       }



    lblk = add_cmd (adr, dbank(0), pc, blk->bank, adr, C_FUNC,0);           // adr+7
    if (lblk && !lblk->cmd)
      {
       dprt("WPARS FUNC add=%d|%lx size=%d \n", dbank(0),adr, sub->szreg);
       add_symn(2,adr, dbank(0), -1);     // auto func name, can fail
       lblk->size1 = 2*sub->szreg;        // size is direct, not via watch
       adnl  = add_ext(lblk);
       if (!adnl->next) adnl->next = add_ext(0);
       adnl->f.cnt = 1;
       adnl->f.esize = sub->szreg;
       adnl->f.pfw = (sub->szreg == 1) ? 3 : 5;
       adnl->f.hex = 0;
       adnl->f.nods = 0;
       adnl->next->f.cnt = 1;
       adnl->next->f.esize = sub->szreg;
       adnl->next->f.pfw = adnl->f.pfw;
       adnl->next->f.hex = 0;
       if (sub->ptype & 0x80) adnl->f.sign = 1;        // signed IN
       if (sub->ptype & 0x40) adnl->next->f.sign = 1;  // signed out
      }
    break;

  default:
    chk_pars(sub,pc,blk->bank,*cnt,0);
    break;

 }
   // chk_pars(sub,pc,dbank(0),*cnt,0);
 // do_subname(sub);
  *cnt+=sub->size;
}

//allow for an all data signature ??
/***************************
signature pattern detection
*************************

allow for an all dta

OPCODES
0x80 is opcode, use index lookup if indx non zero, allow repeat.
0x40 is optional instruction(s) - skip to next opcode if no match - 41 and 42 only with 8065
0x20 is keep jump destination
0x10 keep bits from instruction in [lower nibble]
if lower nibble set then that is a repeat allowed, with repeat kept in reg
Cannot repeat on first opcode (?).

DATA
0x40 is merge value (i.e. bit masks ?)
0x20 is value don't care
0x10 is autoinc reg value or byte/word assembly - allow val-1 (i.e. even) to match
if lower nibble set this is index to register. (vals[x]  array)

*/

long jumpl (long ofst, ushort mask, short cnt)
{
  if (ofst & mask) ofst |= ~(mask - 1);   // negate
  ofst += cnt;
  return ofst;
}


short datsig(long *foff, SIGN **sx, SIGN *end, uchar* sgv)
{

// match the DATA after an opcode

// foff for file offset
// sx for where data pattern starts - stop at next opcode (0x80)
// end is end of pattern (safety)
// sgv for array of vals

// return true or false, always increment sx to next opcode,
// set end,  and sgv as reqd

short ans;
uchar sval,tval;  // for register vals

ans = 1;

while ((*sx) < end)
   {
    if (*foff >= fillen) return 0;   // hit end of file
    if ((*sx)->indx & 0x80) return ans;   // stop at next opcode;
    sval = get_byte (*foff);         // code file value
    tval = (*sx)->indx & 0xf;          //index value, if set


    if (tval && ans && !sgv[tval])
        {
         sgv[tval] = sval;          // save register index if first time and matches /
         if ((*sx)->indx & 0x10) sgv[tval] &= 0xfe;
        }
    if (sval != (*sx)->val)
     {
      if (tval && sval == sgv[tval]) ;  // OK
      //else if ((*sx)->indx & 0x40) sgv[tval] |= sval;
      else if ((*sx)->indx & 0x20) ;    // OK, ignore set
      else if ((*sx)->indx & 0x10)      // autoinc or long index register
       {
        if (!(sval & 1)) ans = 0;  // flag must be set !!  WHY ?
        sgv[tval] &= 0xfe;  // drop autoinc marker from value
        if ((sval & 0xfe) != sgv[tval])  ans = 0;
       }
      else ans = 0;
     }
    (*sx)++;
    (*foff)++;
    }
 return ans;  //  hit end of pattern
 }




SIG * do_sig (PAT *ptn, long ofst)
{
  short lng, ans, dans, skp;
  long foff, doff, joff;
  uchar sval,tval,opc;  // for register vals
  SIGN *sg, *sx , *end;
  uchar sgv[16];
  long adds[3];

  if (ptn->size < 1) return 0;   // auto FAIL if zero sig

  if (ofst > fillen)
    {
    //  wprt (1,"SIG beyond end of ROM %lx\n", ofst);
      return 0;
    }

   for (lng = 0; lng < 16; lng++) sgv[lng] = 0;   // clear any remembered values
   for (lng = 0; lng < 3; lng++) adds[lng] = 0;   // and addresses
  ans  = 1;      // 1 is match
  foff = ofst;   //  file binary offset
  lng  = 0;      // long calls and jumps, extra param to skip
  skp  = 0;
  sg = ptn->sig;                  // signature entry
  sx = sg;                        // safety
  end = ptn->sig+ptn->size;       // end of sig (+1)

  while (ans && sg < end)
   {
    if (foff >= fillen-1) return 0;   // extra byte space for jump getbytes below
    if (!(sg->indx & 0x80))
        {
    //    allow if all data ??
     //    dprt("opc sign error\n");
         return 0;
        }

    sval = get_byte (foff);         // code file value
    tval = sg->indx & 0xf;          //index value, if set

    // opcode index - one entry

    if (sg->indx & 0x10 && tval)
      {    // put option in here for word or byte ?
       sgv[tval] = (1 << (sval & 0x7)); // | (sval & 0x10);  // keep bit and state from jb or jnb
       tval = 0;
      }

    opc = sval;
    sval = sigix[sval];

    if (sval == 40 || (sval == 41 && P8065))
      if(skp != opc)
      {   // permanent optional SINGLE opcodes - only skip one
          // MUST BE SINGLE OPERAND WITH NO PARS !!
       foff++;
       skp=opc;
       continue;
      }

    lng = 0;
    skp = 0;

    if (sval == 58)
        {
         lng = 2;     // skip - treat as jump, but have to skip BACK a data byte
         sval = 16;
        }
       else  if (sval > 50)
        {
         lng = 1;       // long jumpers
         sval -= 40;
        }

    if ((sg->val & 0xfe) == 16 && (sg->indx & 0x20))
         {
         // save jumps and calls to signature

         switch(lng)
           {
           default:    // short
              joff = jumpl (((get_byte (foff) & 7) << 8) + get_byte (foff + 1), 0x400, 2);
              break;
           case 1 :    // long
              joff = jumpl (g_val(foff + 1, 2, 0), 0x8000, 3);
              break;
           case 2:     // skip
              joff = 2;
             //sg++;   // skip next data byte in pattern   can't do here...
              break;
           }
           joff+=foff;
           if (joff < 0 || joff >= fillen) joff = 0;
           adds[sg->val-15] = joff; // 16 (jump) = [1], 17 (subr) = [2]
          }

    // check data params
         // else ?  no need to be able to check jump sizes - just skip to sort out
    sx = sg+1;
    doff = foff+1;
    dans =datsig(&doff, &sx, end, sgv);  // do data params match

    if (sval != sg->val || !dans)   // opcode or data not match
        {
         if (sg->indx & 0x40)
          {  // optional pattern instruction(s) - skip to next opcode pattern
          sg = sx;
          continue;  // go back to top
          }
         if (tval && sgv[tval] > 0)
          {            // end of repeat pattern, if matched at least once
           sg = sx;
           continue;  // go back to top
          }

        ans = 0; // data or opcode does not match
       }

    if (tval && ans) sgv[tval]++;  // repeat opcode count
    else sg = sx;  // else skip to next opcode

    foff = doff;                 // next file offset

    switch(lng)
      {
       default:    // short
        break;
       case 1 :    // long
         foff++;            // extra data param in a long jump
         break;
       case 2:     // skip
         foff--;            // 1 less data byte if a skip
         break;
      }
   }

  if (ans)
    {
     adds[0] = foff;  // save end offset
     return add_sign(ofst, ptn, sgv, adds);  // saves to asigtab
    }

  return 0;
 }






void scan_subr(ushort pc, ushort bank, LBK* blk, LBK* sblk, SXT* sub)
 {            // sblk can be null if invalid address (i.e. calcon d006 etc.)

  LSCN *a, *b;
  if (!sub) return;
  if (sub->scanned) return;

  if (!sblk) sblk = (LBK *) find(&scanch,pc,bank,0); // find correct blk if reqd
  if (!sblk)
     {
      wprt ("NO SUBR SCAN BLOCK !!");
      sblk = add_scan (pc, bank, pc, bank); // try adding block
      return;
      }
 // if (sblk == blk) return;                      // don't loop on current block !!
 // if (!sblk) sblk = add_scan (pc, bank, pc, bank); // try adding block

  if (depth >=30)
     {
      dprt("# # # # Abandon !! DEPTH >= 30 !!\n");
      return;
     }




  a = (LSCN*) blk->addnl;
  b = (LSCN*) sblk->addnl;

  a->tnext  = sblk;
  b->tprev = blk;
  depth++;
  scan_code(sblk);        // 0, scan NEW block
  depth--;
  if (depth < 0) depth = 0;  // safety
  sub->scanned = 1;         // mark subroutine as scanned
  a->tnext = NULL;
  b->tprev = NULL;          // unchain subr call
 }


// response to subroutine call - pars must come from blk->bank (i.e. call)

void do_subr(LBK *blk, ushort pc, ushort newbank, ushort newpc, short *cnt)
{
  SXT *sub;
  LBK *sblk;

  if (anlpass >= ANLPRT || PMANL) return;


  sblk = NULL;

  if (iaddr(newpc, newbank))
      {
        dprt("INVALID subr call address %d|%lx - ignored\n", newbank, newpc);
        return;
      }
  sub = get_subr(newpc, newbank);
  sblk = (LBK *) find(&cmdch,pc,newbank,C_ARGS);

  if (sblk)
    {
     // local ARGS command at this PC address, no changes
     do_substructs(sub,sblk,pc,cnt);
     dprt("Resume with %s cnt %d (->%lx)\n", "(args)",*cnt, pc+*cnt);
     return;
    }

   if (sub && sub->cmd)
    {
     // sub specified by user command, no changes
     do_substructs(sub,blk,pc,cnt);
     dprt("Resume with %s cnt %d (->%lx)\n", "(cmd)",*cnt, pc+*cnt);
     return;
    }

  if (!sub)
   {
    sub = add_subr(pc,newpc,newbank);
    do_subname(sub);
    add_scan (newpc, newbank, pc, newbank);
    scan_subr(newpc, newbank, blk, sblk, sub);
   }
  do_substructs(sub,blk,pc,cnt);
  dprt("Resume with %s cnt %d (->%lx)\n", "",*cnt, pc+*cnt);
  return;
}


//*********************************************************************************

void do_rbase(SIG *sx)
{                     //add rbase entries from signature match
  long x, y, cnt, low, high;
  short reg;
  LBK *b;
  CADT *a;
  ushort pc, bank;

  pc = pcof(sx->ofst, &bank);
  // bank from rbnk is stored in v[15], not used (yet)
  // if (sx->v[15]) bank = sx->v[15];
  reg = sx->v[1];
  x = sx->v[4] << 8;
  x += sx->v[3];
  cnt = g_val(x,bank,1,0);
  dprt("Rbase begins at reg %x for address %d|%lx, cnt %d\n", reg,bank,x,cnt);
  add_cmd (x, bank, 0, 0, x+1,C_BYTE,0);
  b = add_cmd (x+2, bank, 0, 0, x+cnt*2, C_WORD,0);
  if (b)
   {
    a = add_ext(b);
    a->f.hex = 1;
    a->f.nods = 0;
   }
  pc= x+2;
  low = 0xffff;
  high = 0;

  reg -= 2;
  while (cnt--)
   {
    x = g_val(pc,bank,2,0);    // register pointer
    b = add_cmd(x, bank, 0, 0, x+1, C_WORD,0);
    if (b)
     {
      a = add_ext(b);
      a->f.hex = 1;
      a->f.nods = 0;
     }
    add_rbase(reg+=2,x);
    y = g_val(x,bank,2,0); // next pointer for end
    if (y > high) high = y;
    if (x < low) low = x;    // first reg start
    pc+=2;
   }
 // if (low < high && !fdir)  set_xcode(low,high);
}


SXT* get_xsubr (long ofst)
{
  SXT *s;
  ushort pc, bank;

  pc = pcof(ofst, &bank);
  s = get_subr(pc, bank);

  if (s && s->cmd) s = NULL;
  return s;
}


void proc_sig(SIG *x, SXT *s)
{
 CADT *a;

  // process single signature

  switch (x->f.ptype)
    {
     case 1:           // function lookups - done in initial phase
        //---------------------------------------------------------------------------

        // assumes v[14]&[15] have saved state from JNB for signed/unsigned ID

        if (!s->ptype)
         {
          SIG *m;
          m = x->master;
          // process sig only ONCE per subr
          s->ptype = m->f.ptype;                            // this is func lookup
          if (!x->f.mtype && x->v[3] == m->v[3])            // not master and flagreg matches
           {
            if (x->v[13] == m->v[13]) s->ptype |= 0x80;      // signed IN
            if (x->v[14] == m->v[14]) s->ptype |= 0x40;      // signed OUT
            else if (x->v[13] == m->v[14]) s->ptype |= 0x40;
           }

          if (!x->v[0]) x->v[0] = s->ptype;                  // keep final sig type in saved sig
          s->adreg = m->v[1];                                // size and add from MASTER sig
          s->szreg = m->v[2]/2;
          do_subname(s);
          dprt( "UPD proc FUNCLU %x at %d|%lx, psize %d, szr %d, adr %x\n",
          s->ptype, s->bank, s->pc, s->size, s->szreg, s->adreg);
          x->f.O61P = 1;
         }
        else
          dprt( "Ignore T1 proc FUNCLU\n");



        break;

       //---------------------------------------------------------------------------
       case 2:           // table lookups

        if (!s->ptype)
          {
           SIG *m;
           m = x->master;
           // process only ONCE per subr
           s->ptype = m->f.ptype;

           if (!x->f.mtype)
            {
             if (x->v[14] == m->v[13]) s->ptype |= 0x80;
             // if (x->v[14] == m->v[14]) s->ptype |= 0x40;
            }

           if (!x->v[0]) x->v[0] = s->ptype;  // keep sig type in saved sig
           s->adreg = m->v[1];
           s->szreg = m->v[2];
           do_subname(s);
           dprt( "ADD T%x TABLU proc %d|%lx, psize %x, szr %x, adr %x\n",
              s->ptype, s->bank, s->pc, s->size, s->szreg, s->adreg);
           x->f.O61P = 1;
          }
         else  dprt( "Ignore T2 proc TABLU\n");

         break;

         //---------------------------------------------------------------------------


       case 4:           // 4 carry as flags
         // just a pass through really....



         if (!s->ptype) {


         dprt( "T4 ADD CLC proc %lx (%d), psize %d, szr %d, adr %x\n",
            s->pc, s->ptype, s->size, s->szreg, s->adreg);
                              }
         else  dprt( "Ignore T4 %x at %d|%lx\n", s->ptype, s->bank, s->pc );
         break;

        //---------------------------------------------------------------------------

       case 5:
         do_rbase(x);
         x->f.O61P = 1;
         break;









         //---------------------------------------------------------------------------
       case 6:          // stack shift (subr arguments)

                        // stack params for funcs, encoded too....
                        // name opt (=N) Ok for these
                        // although master, continue if more chain

          dprt ("DO T6\n");

          a = add_ext(s);  // add stack params for callers
          a->f.enc = 2;     // type 2 encoded
          a->divisor =  x->v[3];
          a->f.esize = 2;
          a->f.hex = 1;
          a->f.name = 1;
          if (!a->next) a->next = add_ext(0);
          a->next->f.esize = 2;
          a->next->f.hex = 1;    // 2 word params
          a->next->f.name = 1;
          s->adreg = 1;
          s->size = 4;
          x->f.O61P = 1;
          dprt( "T6 UPD proc %d|%lx, ARGS(stack), ENC 2, psize %d\n",
          s->bank,s->pc, s->size );

         break;
        //---------------------------------------------------------------------------
       case 7:          // cross bank param getter and grf stack fix
                      // multibank stack params 2 levels

           x->v[13] = 2;     //no of levels fixed at 2
           dprt("type 7 -> 8\n");
      /*

           if (!s->ptype) {    // can be used more than once ??
           if (!x->v[0]) x->v[0] = x->ptype;
           s->ptype = 8;       // it's just a multibank 8
           s->levels = 2;               //dest->v[13];     //no of levels
           s->szreg = 0;
           s->adreg  = x->v[14];     // no of params (byte)
           chainsig(x,&sigtab);
           dprt( "T7 ADD proc %d|%lx (t %d), psize %d, levs %d, adr %x\n",
           s->bank, s->pc, s->ptype, s->size, s->levels, s->adreg);
         }
          else
             dprt( "T7 Ignore ADD proc\n");

         break;    */
        //---------------------------------------------------------------------------
       case 8:   // fixed embedded args various levels

         if (!s->ptype)
           {    // can be used more than once ??
            if (!x->v[0]) x->v[0] = x->f.ptype;
            s->ptype = 8;              //x->ptype;
            s->levels += x->v[13];     //no of levels
            s->szreg = 0;
            s->adreg  = x->v[14];     // no of params (byte)
            //  s->cmd = 0;                //guess = 1;
            dprt( "UPD proc (stack) at %d|%lx (t%d), levs %d, args %x\n",
              s->bank, s->pc, s->ptype, s->levels, s->adreg);
            x->f.O61P = 1;                 //chainsig(x,&msigtab);
           }
         else  dprt( "Ignore UPD proc at %d|%lx\n", s->bank, s->pc );
//should really check that v[13] = v[15] .... but this may stop stuff working in A9L

         break;

        //---------------------------------------------------------------------------

       case 9:    // variable args at various levels

         if (!s->ptype || (s->ptype == 8 && s->adreg == 1))
           {    // can be used more than once ??
            if (!x->v[0]) x->v[0] = x->f.ptype;
            s->ptype = x->f.ptype;          // local and remote caller
            //dest->ptype = d->ptype;       // change type to VPAR.
            s->levels += x->v[13];       // no of levels (fpar + n)
            s->szreg = 0;
            s->adreg = x->v[14];         // 1 no of params (fpar)
            if (s->adreg < 1) s->adreg = 1; // safety
            add_ext(s); // new struct for saved command
            //s->cmd = 0;                           //s->guess = 1;
            s->addnl->f.cnt = x->v[14];   // local pars
            if (s->addnl->f.cnt < 1) s->addnl->f.cnt = 1; // safety
            s->size = 1;
            dprt( "UPD proc at %d|%lx (%d), psize %d, levs %d, args %x\n",
              s->bank, s->pc, s->ptype, s->size, s->levels, s->adreg);
            x->f.O61P = 1;                 //chainsig(x,&msigtab);
           }
         else   dprt( "Ignore T9 ADD proc\n");
         break;
      //---------------------------------------------------------------------------

      case 10:
         // remote params - NO local params - calls a rempar so all shuffled down by one.

         if (!s->ptype)
           {
            s->ptype = x->f.ptype;             // local and remote caller
            s->szreg = 1;
            s->levels = x->v[13]+1;           // extra level (push, call)
            s->adreg =  x->v[2];              // no of pars
            //s->cmd = 0;                        //guess = 1;

            dprt( "T10 UPD (GrandF) proc %lx (%d), psize %d, levs %d, adr %x\n",
              s->pc, s->ptype, s->size, s->levels, s->adreg);
            x->f.O61P = 1;                 //chainsig(x,&msigtab);
           }
         else   dprt( "Ignore T10 ADD proc\n");
         break;
     //---------------------------------------------------------------------------
       case 11:
       case 13:
       case 14:
         // encoder can be within subr .... add encode bits
         // this does NOT include stack params, so need to rejig the params....
         // this works for 3695 filters in A9L...

         add_ext(s);          // safe if exists already...
         a = s->addnl;

         // already has params
         if (a->f.enc)
           {   // already has encode marked
            dprt( "T%d Ignore UPD proc at %d|%lx\n",x->f.ptype,s->bank,s->pc);
            break;
           }
         if (a->f.cnt > 1)
           {              // more than one argument
            if (a->f.esize > 1) a->f.esize--;     // drop off a word argument
            else                a->f.esize -= 2;            // or 2 bytes
            s->addnl = add_ext(0);  // add encoder level at front
            s->addnl->next = a;    // rechain rest
           }

         a = s->addnl;        // reset to first block

         a->f.enc = x->f.ptype - 10;       // 11 is type 1 encoded etc
         if (a->f.enc == 4 && x->v[3] == 0xf)
            {                      // type 2, not 4
             a->f.enc = 2;
            }
         x->v[0] = a->f.enc;           // remember type
         a->divisor =  x->v[5];          // encode base register (eg. f0)
         a->f.esize = 2;                  // word based
         a->f.hex = 1;
         a->f.name = 1;
         a->f.cnt = 1;                     // probably redundant
          //dest->v[3] = d->v[3];  // for encoded base
         x->f.O61P = 1;                 //chainsig(x,&msigtab);
         dprt( "UPD subr t%d at %d|%lx to ENC %d, reg %lx\n",
            x->f.ptype, s->bank, s->pc, a->f.enc, a->divisor);

         break;
       case 20:

           // Timer list
 
         if (x->v[14] == 2)
         dprt("WORD Timer struct\n");
         else
            dprt("BYTE Timer struct\n");
         x->f.O61P = 1;   
         break;

       default:
        dprt("Pat type %d (%lx) ignored\n", x->f.ptype, x->ofst);
        break;

      }

  // now traverse any  links

  if (x->f.mtype) return;

  if (x->f.smatch)
    {
      x = (SIG*) find(&sigtab,x->subr, 0,0);       // subroutine link
      // safe without x check ?
      proc_sig(x,s);
    }
  if (x->f.jmatch)
     {
      x = (SIG*) find(&sigtab,x->jump, 0,0);    // jump link
      proc_sig(x,s);
     }
  if (x->f.ematch)
     {
      x = (SIG*) find(&sigtab,x->end, 0,0);     // end (abutt) link
      proc_sig(x,s);
     }

  dprt ("END XSIG\n");

 }


void preproc_sig(SIG *m)
{
 // for preprocess of sigs as reqd (manily func and tab addrs)

  switch (m->f.ptype)               // & 0x3f)
      {
       case 1:           // function lookups

         if (!funcreg)
            {
             funcreg = m->v[1];     // keep register for address tracking
             dprt("XSIG --- FUNC ADDR reg = %x\n", funcreg);
            }
         break;

       case 2:           // table lookups

         if (!tabreg)
            {
             tabreg   = m->v[1];   // address tracking
             sizereg =  m->v[2];   // table size
             dprt("XSIG --- TABLE ADDR reg = %x\n", tabreg);
             dprt("XSIG --- TABLE SIZE reg = %x\n", sizereg);
            }
          break;

        default:
          break;
       }
  }




SIG *scan_sig (long ofst)
{
  short j;
  PAT  *ptn;
  SIG  *fnd, *x;

 // This proc calls itself to traverse chain of sigs, stop at master sig.

  for (j = 0; j < NC(patterns); j++)
   {
    ptn = patterns + j;
    fnd = do_sig (ptn, ofst);

   if (!fnd) continue;      // next sig to try
   if (fnd->f.mtype)
        {
         preproc_sig(fnd);  // master sig, STOP
         return fnd;
        }

   // found a subtype signature - check for links

   if (ptn->f.smatch)             // pattern calls via subroutine(s)
       {
        x = (SIG*) find(&tsigtab,fnd->subr, 0,0);     // check if sig already caught
        if (x) return x;
        scan_sig(fnd->subr);
       }

   if (ptn->f.jmatch)             // pattern jumps to another
       {
        x = (SIG*) find(&tsigtab,fnd->jump, 0,0);     // check if sig already caught
        if (x) return x;
        return scan_sig(fnd->jump);
       }

    if (ptn->f.ematch)            // pattern abutts another
       {
        x = (SIG*) find(&tsigtab,fnd->end, 0,0);     // check if sig already caught
        if (x) return x;
        return scan_sig(fnd->end);
       }
    return fnd;                                     // pattern OK to return if no link bits set
   }
  return 0;                                    // nothing found
}

void process_sigs(LBK *sblk, long ofst)
 {
  // split so that proc_sig can call itself to traverse chain.

  SIG *x;
  SXT *s;

  x = (SIG*) find(&sigtab,ofst, 0,0);          // x is matching SIG for this ofst
  if (!x) return;

  dprt("--------- PROCESS XSIGS at %lx\n", ofst);

  if (x->f.subr)
    {            // must have subr
     s = get_xsubr(ofst);                      // current subr (if there is one)
     if (!s && sblk) s = get_subr(sblk->start, sblk->bank);
     if (!s || s->cmd ) return;   // must have subr and not via command
    }

  proc_sig(x,s);
 }



 void lst_reject(long ofst)
 {
  short j, prt;
  SIG *x;

  prt = 0;
 // if (tsigtab.num > 0) prt = 1;         
  for (j = 0; j < tsigtab.num; j++)
   {
    x = (SIG*) tsigtab.ptrs[j];
    if (x->f.mtype) prt = 1;
    if (x->f.ptype > 1) prt = 1;
   }
   if (!prt) return;

  dprt("---XSIG REJECT---%lx\n", ofst);
  prt_sigs(&tsigtab,1);
  dprt("---XSIG REJECT END ---\n");
 }

void scan_init (void)
{
 // scan whole binary file for signatures as reqd.

  long ofst;
  SIG *ans;
  short i;

  if (PMANL) return;

  for (i = 0; i < NC(banks); i++)
   {
    if (banks[i].used)
      for (ofst = banks[i].start; ofst < banks[i].end && ofst < fillen; ofst++)
       {
        show_prog (ofst, 4, fillen);
        ans = scan_sig(ofst);
        if (ans) copysigs(ans);
        else lst_reject(ofst);

        clearch(&tsigtab);
       }
   }
  prt_sigs(&sigtab,1);
}



short scan_start (long *ofst)
{       // check for start jump in each bank and add 0x2000 and retry
    SIG* ans;
    short z;

    z = 0;
    ans = do_sig(&hdr,*ofst);

    if (!ans)
      {
      *ofst+=PCORG;
      ans = do_sig(&hdr,*ofst); // try at +2000 offset
      }

    if (ans)
      {
       if (ans->jump > ans->end) z = 1;   // not loopstop jump
       else z = 2;
      }

    clearch(&tsigtab);   // clear all after check
    return z;

}




